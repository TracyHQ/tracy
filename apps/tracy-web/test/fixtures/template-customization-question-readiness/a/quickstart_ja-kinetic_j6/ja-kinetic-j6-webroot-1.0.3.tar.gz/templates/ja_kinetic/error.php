<?php
/**
 * @package   ja_kinetic
 * Kinetic 404/error page — full chrome (header + body + footer), dark/light aware.
 *
 * Dark resolution mirrors index.php exactly:
 *   local/etc/site/<profile>.json  (where admin GUI saves edits, LOCAL-FIRST)
 *   → base etc/site/<profile>.json (shipped defaults)
 * This prevents [DARK-STANDALONE-LOCK-DESYNC]: a locked-light site must NOT show a
 * permanently-dark 404 page. The toggle is gated by other_darkmode just like index.php.
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

$app  = Factory::getApplication();
$code = (int) ($this->error ? $this->error->getCode() : 404);
if ($code < 400) { $code = 404; }
$home = Uri::root();                // absolute, trailing slash
$b    = rtrim(Uri::root(true), '/'); // relative base, e.g. '' or '/subfolder'
$tplDir = JPATH_SITE . '/templates/ja_kinetic';

// --- LOCAL-FIRST dark resolver (same logic as index.php) ---
$darkEnabled  = true;
$defaultTheme = 'auto';
$direction    = 'terminal';

$prof     = $app->getTemplate(true)->params->get('typelist-site', 'default');
$localCfg = $tplDir . '/local/etc/site/' . basename($prof) . '.json';
$baseCfg  = $tplDir . '/etc/site/' . basename($prof) . '.json';
$cfgFile  = is_file($localCfg) ? $localCfg : $baseCfg;
if (is_file($cfgFile)) {
    $cfg = json_decode(file_get_contents($cfgFile), true);
    if (is_array($cfg)) {
        if (isset($cfg['other_darkmode']))       { $darkEnabled  = filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN); }
        if (!empty($cfg['other_default_theme'])) { $defaultTheme = $cfg['other_default_theme']; }
        if (!empty($cfg['kinetic_direction']))     { $direction    = $cfg['kinetic_direction']; }
    }
}
if ($defaultTheme === 'dark-active')  { $defaultTheme = 'dark'; }
if ($defaultTheme === 'light-active') { $defaultTheme = 'light'; }

$cookieChoice = $app->input->cookie->get('ja_kinetic-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') { $cookieChoice = ''; }

if ($darkEnabled && $cookieChoice !== '') {
    $resolved = $cookieChoice;
} elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') {
    $resolved = $defaultTheme;
} else {
    $resolved = ''; // auto (OS-follow)
}

// --- Pre-paint script: set data-style (direction) + data-theme (no FOUC) ---
$dirJs = "document.documentElement.setAttribute('data-style'," . json_encode($direction) . ");";
if ($resolved !== '') {
    $preScript = '(function(){' . $dirJs . 'var t=' . json_encode($resolved) . ';'
        . "document.documentElement.setAttribute('data-theme',t);"
        . "document.documentElement.setAttribute('data-bs-theme',t);"
        . "if(t==='dark'){document.documentElement.classList.add('t4-dark');}})();";
} else {
    $preScript = '(function(){' . $dirJs . 'try{'
        . "var d=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;"
        . "var t=d?'dark':'light';document.documentElement.setAttribute('data-theme',t);"
        . "document.documentElement.setAttribute('data-bs-theme',t);"
        . "if(d){document.documentElement.classList.add('t4-dark');}}"
        . "catch(e){document.documentElement.setAttribute('data-theme','light');}})();";
}
$themeInfo = 'window.jaKineticTheme={def:' . json_encode($defaultTheme) . ',enabled:' . ($darkEnabled ? 'true' : 'false') . ',dir:' . json_encode($direction) . '};';

// Cache-bust helpers
function _hxMtime($path) { return is_file($path) ? filemtime($path) : 1; }
$tcssV  = _hxMtime($tplDir . '/css/template.css');
$dcssV  = _hxMtime($tplDir . '/css/darkmode.css');
$ecssV  = _hxMtime($tplDir . '/css/error.css');
$djsV   = _hxMtime($tplDir . '/js/darkmode.js');
$tplUrl = $b . '/templates/ja_kinetic';
?><!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title><?php echo $code; ?> &mdash; Kinetic</title>
  <link rel="icon" type="image/vnd.microsoft.icon" href="<?php echo $tplUrl; ?>/favicon.ico">
  <!-- Pre-paint theme resolver: runs synchronously before first paint — no FOUC -->
  <script><?php echo $preScript; ?></script>
  <script><?php echo $themeInfo; ?></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo $tplUrl; ?>/css/template.css?<?php echo $tcssV; ?>">
<?php if ($darkEnabled || $defaultTheme === 'dark' || $defaultTheme === 'auto'): ?>
  <link rel="stylesheet" href="<?php echo $tplUrl; ?>/css/darkmode.css?<?php echo $dcssV; ?>">
<?php endif; ?>
<?php if (is_file($tplDir . '/css/error.css')): ?>
  <link rel="stylesheet" href="<?php echo $tplUrl; ?>/css/error.css?<?php echo $ecssV; ?>">
<?php endif; ?>
<?php
$acmSocialCss = $tplDir . '/acm/social/css/style.css';
if (is_file($acmSocialCss)):
    $acmSocialV = filemtime($acmSocialCss);
?>
  <link rel="stylesheet" href="<?php echo $tplUrl; ?>/acm/social/css/style.css?<?php echo $acmSocialV; ?>">
<?php endif; ?>
</head>
<body class="site body-error-page">

<!-- KINETIC HEADER — identical structure to T4-rendered chrome (template.css handles all styles) -->
<div id="t4-header" class="t4-section t4-header t4-sticky">
<header class="kinetic-header">
  <div class="hx-pad kinetic-header-inner">

    <div class="hx-left">
      <!-- Logo -->
      <div class="navbar-brand kinetic-brand logo-text">
        <a href="<?php echo $home; ?>" title="Kinetic">
          <span class="kinetic-logo">
            <svg class="kinetic-logo-glyph" width="26" height="26" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <path d="M8 4 Q16 12 8 20 Q16 28 24 20" stroke="var(--chrome-primary)" stroke-width="2.4" stroke-linecap="round"/>
              <path d="M24 12 Q16 20 24 28 Q16 4 8 12" stroke="var(--chrome-primary)" stroke-width="2.4" stroke-linecap="round" opacity="0.5"/>
            </svg>
            <span class="kinetic-logo-text">Kinetic</span>
          </span>
        </a>
      </div>
      <!-- Desktop megamenu (CSS renders; hover dropdowns need T4 JS but links work) -->
      <div class="hx-desknav t4-navbar collapse-static">
        <nav class="navbar navbar-expand-lg">
          <div id="t4-megamenu-mainmenu" class="t4-megamenu collapse navbar-collapse">
            <ul class="nav navbar-nav level0" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
              <li class="nav-item dropdown mega parent" data-id="213" data-level="1" data-align="left">
                <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">
                  <span itemprop="name"><span class="menu-item-title">Home</span></span><i class="item-caret"></i></a>
                <div class="dropdown-menu mega-dropdown-menu" style="width:420px;"><div class="mega-dropdown-inner"><div class="row">
                  <div class="mega-sub-1 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Home Styles</span></h3>
                    <ul class="mega-nav level11">
                      <li class="nav-item" data-id="214"><a href="<?php echo $b; ?>/index.php" class="nav-link"><span itemprop="name"><span class="menu-item-title">Terminal</span></span></a></li>
                      <li class="nav-item" data-id="215"><a href="<?php echo $b; ?>/index.php/home-menu/home-blueprint" class="nav-link"><span itemprop="name"><span class="menu-item-title">Blueprint</span></span></a></li>
                      <li class="nav-item" data-id="216"><a href="<?php echo $b; ?>/index.php/home-menu/home-signal" class="nav-link"><span itemprop="name"><span class="menu-item-title">Signal</span></span></a></li>
                    </ul>
                  </div></div></div>
                </div></div></div>
              </li>
              <li class="nav-item dropdown mega parent" data-id="217" data-level="1" data-align="left">
                <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">
                  <span itemprop="name"><span class="menu-item-title">Product</span></span><i class="item-caret"></i></a>
                <div class="dropdown-menu mega-dropdown-menu" style="width:560px;"><div class="mega-dropdown-inner"><div class="row">
                  <div class="mega-sub-1 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Platform</span></h3>
                    <ul class="mega-nav level11">
                      <li class="nav-item" data-id="218"><a href="<?php echo $b; ?>/index.php/product/features" class="nav-link"><span itemprop="name"><span class="menu-item-title">Features</span></span></a></li>
                      <li class="nav-item" data-id="219"><a href="<?php echo $b; ?>/index.php/product/integrations" class="nav-link"><span itemprop="name"><span class="menu-item-title">Integrations</span></span></a></li>
                      <li class="nav-item" data-id="220"><a href="<?php echo $b; ?>/index.php/product/changelog" class="nav-link"><span itemprop="name"><span class="menu-item-title">Changelog</span></span></a></li>
                    </ul>
                  </div></div></div>
                  <div class="mega-sub-2 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Resources</span></h3>
                    <ul class="mega-nav level11">
                      <li class="nav-item" data-id="221"><a href="<?php echo $b; ?>/index.php/product/blog" class="nav-link"><span itemprop="name"><span class="menu-item-title">Blog</span></span></a></li>
                      <li class="nav-item" data-id="222"><a href="<?php echo $b; ?>/index.php/product/faq" class="nav-link"><span itemprop="name"><span class="menu-item-title">FAQ</span></span></a></li>
                    </ul>
                  </div></div></div>
                </div></div></div>
              </li>
              <li class="nav-item" data-id="223" data-level="1">
                <a href="<?php echo $b; ?>/index.php/pricing" class="nav-link"><span itemprop="name"><span class="menu-item-title">Pricing</span></span></a>
              </li>
              <li class="nav-item dropdown mega parent" data-id="224" data-level="1" data-align="left">
                <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">
                  <span itemprop="name"><span class="menu-item-title">Company</span></span><i class="item-caret"></i></a>
                <div class="dropdown-menu mega-dropdown-menu" style="width:300px;"><div class="mega-dropdown-inner"><div class="row">
                  <div class="mega-sub-1 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Company</span></h3>
                    <ul class="mega-nav level11">
                      <li class="nav-item" data-id="225"><a href="<?php echo $b; ?>/index.php/company/about" class="nav-link"><span itemprop="name"><span class="menu-item-title">About</span></span></a></li>
                      <li class="nav-item" data-id="226"><a href="<?php echo $b; ?>/index.php/company/team" class="nav-link"><span itemprop="name"><span class="menu-item-title">Team</span></span></a></li>
                      <li class="nav-item" data-id="227"><a href="<?php echo $b; ?>/index.php/company/contact" class="nav-link"><span itemprop="name"><span class="menu-item-title">Contact</span></span></a></li>
                    </ul>
                  </div></div></div>
                </div></div></div>
              </li>
              <li class="nav-item dropdown mega parent" data-id="228" data-level="1" data-align="left">
                <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">
                  <span itemprop="name"><span class="menu-item-title">Pages</span></span><i class="item-caret"></i></a>
                <div class="dropdown-menu mega-dropdown-menu" style="width:640px;"><div class="mega-dropdown-inner"><div class="row">
                  <div class="mega-sub-1 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Content</span></h3>
                    <ul class="mega-nav level12">
                      <li class="nav-item" data-id="229"><a href="<?php echo $b; ?>/index.php/pages/landing" class="nav-link"><span itemprop="name"><span class="menu-item-title">Landing</span></span></a></li>
                      <li class="nav-item" data-id="230"><a href="<?php echo $b; ?>/index.php/pages/kineticql" class="nav-link"><span itemprop="name"><span class="menu-item-title">Single Article</span></span></a></li>
                      <li class="nav-item" data-id="232"><a href="<?php echo $b; ?>/index.php/pages/search" class="nav-link"><span itemprop="name"><span class="menu-item-title">Search</span></span></a></li>
                      <li class="nav-item" data-id="231"><a href="<?php echo $b; ?>/index.php/pages/tags" class="nav-link"><span itemprop="name"><span class="menu-item-title">All Tags</span></span></a></li>
                    </ul>
                  </div></div></div>
                  <div class="mega-sub-2 col-12 col-md"><div class="mega-col-nav"><div class="mega-inner">
                    <h3 class="mega-col-title"><span>Account &amp; System</span></h3>
                    <ul class="mega-nav level12">
                      <li class="nav-item" data-id="233"><a href="<?php echo $b; ?>/index.php/pages/login" class="nav-link"><span itemprop="name"><span class="menu-item-title">Login</span></span></a></li>
                      <li class="nav-item" data-id="234"><a href="<?php echo $b; ?>/index.php/pages/register" class="nav-link"><span itemprop="name"><span class="menu-item-title">Register</span></span></a></li>
                    </ul>
                  </div></div></div>
                </div></div></div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>

    <div class="hx-right">
      <div class="hx-right-links">
        <a class="hx-signin" href="<?php echo $b; ?>/index.php/pages/login">Sign in</a>
        <a class="hx-btn hx-btn--primary hx-cta-pill" href="<?php echo $b; ?>/index.php/pages/register">Start free</a>
      </div>
      <?php if ($darkEnabled): ?>
      <button type="button" class="kinetic-theme-toggle" aria-label="Toggle dark mode" aria-pressed="false" title="Toggle light / dark">
        <svg class="hx-sun" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
        <svg class="hx-moon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
      </button>
      <?php endif; ?>
      <button type="button" class="t4-offcanvas-toggle" aria-label="Open menu" aria-controls="kinetic-drawer" aria-expanded="false">
        <span class="toggle-bars" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </span>
      </button>
    </div>

  </div>
</header>

<!-- MOBILE OFF-CANVAS DRAWER -->
<div class="kinetic-oc-overlay" hidden></div>
<aside id="kinetic-drawer" class="kinetic-offcanvas t4-offcanvas" aria-hidden="true" tabindex="-1">
  <div class="t4-off-canvas-header">
    <a href="<?php echo $home; ?>" class="kinetic-logo" aria-label="Kinetic home">
      <svg class="kinetic-logo-glyph" width="22" height="22" viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M8 4 Q16 12 8 20 Q16 28 24 20" stroke="var(--chrome-primary)" stroke-width="2.6" stroke-linecap="round"/>
        <path d="M24 12 Q16 20 24 28 Q16 4 8 12" stroke="var(--chrome-primary)" stroke-width="2.6" stroke-linecap="round" opacity="0.5"/>
      </svg>
      <span class="kinetic-logo-text">Kinetic</span>
    </a>
    <button type="button" class="close js-offcanvas-close" aria-label="Close menu">&times;</button>
  </div>
  <div class="t4-off-canvas-body">
    <nav class="navbar">
      <ul class="nav navbar-nav">
        <li class="nav-item deeper dropdown parent" data-level="1">
          <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false" data-bs-toggle="dropdown">
            <span itemprop="name"><span class="menu-item-title">Home</span></span></a>
          <ul class="dropdown-menu" data-bs-popper="static">
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Terminal</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/home-menu/home-blueprint" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Blueprint</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/home-menu/home-signal" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Signal</span></span></a></li>
          </ul>
        </li>
        <li class="nav-item deeper dropdown parent" data-level="1">
          <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false" data-bs-toggle="dropdown">
            <span itemprop="name"><span class="menu-item-title">Product</span></span></a>
          <ul class="dropdown-menu" data-bs-popper="static">
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/features" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Features</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/integrations" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Integrations</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/changelog" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Changelog</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/blog" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Blog</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/faq" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">FAQ</span></span></a></li>
          </ul>
        </li>
        <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pricing" class="nav-link"><span itemprop="name"><span class="menu-item-title">Pricing</span></span></a></li>
        <li class="nav-item deeper dropdown parent" data-level="1">
          <a href="javascript:;" class="nav-header nav-link dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false" data-bs-toggle="dropdown">
            <span itemprop="name"><span class="menu-item-title">Company</span></span></a>
          <ul class="dropdown-menu" data-bs-popper="static">
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/about" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">About</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/team" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Team</span></span></a></li>
            <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/contact" class="dropdown-item"><span itemprop="name"><span class="menu-item-title">Contact</span></span></a></li>
          </ul>
        </li>
        <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pages/search" class="nav-link"><span itemprop="name"><span class="menu-item-title">Search</span></span></a></li>
      </ul>
    </nav>
    <div class="kinetic-oc-cta">
      <a class="hx-signin" href="<?php echo $b; ?>/index.php/pages/login">Sign in</a>
      <a class="hx-btn hx-btn--primary hx-cta-pill" href="<?php echo $b; ?>/index.php/pages/register">Start free</a>
    </div>
  </div>
</aside>
</div>
<!-- // KINETIC HEADER BLOCK -->

<!-- ============================================================
     404 BODY
     ============================================================ -->
<main class="hx-error-body" role="main">
  <div class="hx-error-inner">
    <p class="hx-error-eyebrow">// 404 &middot; TRACE NOT FOUND</p>
    <div class="hx-error-code" aria-hidden="true">404</div>
    <h1 class="hx-error-h1">This span dropped off the timeline</h1>
    <p class="hx-error-sub">The page you&#8217;re after doesn&#8217;t exist or was moved. Let&#8217;s get you back to a known-good state.</p>
    <div class="hx-error-btns">
      <a class="hx-btn hx-btn--primary hx-btn--error-p" href="<?php echo $home; ?>">
        Back home
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
      </a>
      <a class="hx-btn hx-btn--error-s" href="<?php echo $b; ?>/index.php/company/contact">
        Contact support
      </a>
    </div>
    <div class="hx-error-quick">
      <a href="<?php echo $b; ?>/index.php/product/features">Features</a>
      <a href="<?php echo $b; ?>/index.php/pricing">Pricing</a>
      <a href="<?php echo $b; ?>/index.php/product/faq">FAQ</a>
      <a href="<?php echo $b; ?>/index.php/company/about">About</a>
    </div>
  </div>
</main>

<!-- KINETIC FOOTER — identical structure to T4-rendered chrome -->
<div id="t4-footer" class="t4-section t4-footer">
<footer class="kinetic-footer">
  <div class="hx-pad kinetic-footer-inner">
    <div class="hx-foot-cols">
      <div class="hx-foot-brand">
        <div class="ja-acm acm-social style-1 size-sm align-left">
          <a class="hx-brand-lock" href="<?php echo $b; ?>/" aria-label="Kinetic">
            <svg class="hx-brand-glyph" width="24" height="24" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <path d="M8 4 Q16 12 8 20 Q16 28 24 20" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"></path>
              <path d="M24 12 Q16 20 24 28 Q16 4 8 12" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" opacity="0.5"></path>
            </svg>
            <span class="hx-brand-word">Kinetic</span>
          </a>
          <p class="hx-social-label">Observability without the overhead. Logs, metrics and traces on one fast timeline.</p>
          <ul class="hx-social-row">
            <li class="hx-social-item">
              <a class="hx-social-tile" href="https://github.com/kinetic-labs" aria-label="Source" title="Source" target="_blank" rel="noopener noreferrer">
                <svg class="hx-social-svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" role="img"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/></g></svg>
              </a>
            </li>
            <li class="hx-social-item">
              <a class="hx-social-tile" href="mailto:hello@kineticlabs.dev" aria-label="Email" title="Email">
                <svg class="hx-social-svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" role="img"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/></g></svg>
              </a>
            </li>
            <li class="hx-social-item">
              <a class="hx-social-tile" href="<?php echo $b; ?>/index.php?option=com_content&amp;view=category&amp;id=22&amp;format=feed&amp;type=rss" aria-label="RSS feed" title="RSS feed" target="_blank" rel="noopener noreferrer">
                <svg class="hx-social-svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" role="img"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></g></svg>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div class="hx-foot-col">
        <h3 class="module-title">PRODUCT</h3>
        <nav class="navbar"><ul class="nav navbar-nav">
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/features" class="nav-link"><span class="menu-item-title">Features</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pricing" class="nav-link"><span class="menu-item-title">Pricing</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/integrations" class="nav-link"><span class="menu-item-title">Integrations</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/changelog" class="nav-link"><span class="menu-item-title">Changelog</span></a></li>
        </ul></nav>
      </div>
      <div class="hx-foot-col">
        <h3 class="module-title">DEVELOPERS</h3>
        <nav class="navbar"><ul class="nav navbar-nav">
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/blog" class="nav-link"><span class="menu-item-title">Blog</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pages/kineticql" class="nav-link"><span class="menu-item-title">KineticQL</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pages/search" class="nav-link"><span class="menu-item-title">Search</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/pages/tags" class="nav-link"><span class="menu-item-title">All Tags</span></a></li>
        </ul></nav>
      </div>
      <div class="hx-foot-col">
        <h3 class="module-title">COMPANY</h3>
        <nav class="navbar"><ul class="nav navbar-nav">
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/about" class="nav-link"><span class="menu-item-title">About</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/team" class="nav-link"><span class="menu-item-title">Team</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/product/faq" class="nav-link"><span class="menu-item-title">FAQ</span></a></li>
          <li class="nav-item"><a href="<?php echo $b; ?>/index.php/company/contact" class="nav-link"><span class="menu-item-title">Contact</span></a></li>
        </ul></nav>
      </div>
    </div>
    <div class="hx-foot-news-band">
      <div class="ja-acm acm-footernews kinetic-news-band">
        <div class="hx-news-copy">
          <h3 class="hx-news-title">Monthly dispatch</h3>
          <p class="hx-news-desc">Incident retros, query tips and product news. No spam, unsubscribe anytime.</p>
        </div>
        <?php /* The error page cannot run the footer-newsletter module (its scripts are
          printed in <head>), so it links to the working form on the home page. */ ?>
        <a class="hx-news-btn" href="<?php echo $b; ?>/index.php#kinetic-newsletter">Subscribe</a>
      </div>
    </div>
    <div class="hx-foot-bottom">
      <div class="ja-acm acm-footerlegal kinetic-legal-band">
        <span class="hx-copy">&copy; 2026 Kinetic Labs, Inc. All rights reserved.</span>
        <ul class="hx-legal">
          <li><a href="<?php echo $b; ?>/index.php/privacy-policy">Privacy</a></li>
          <li><a href="<?php echo $b; ?>/index.php/terms-of-service">Terms</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!-- // KINETIC FOOTER BLOCK -->
</div>

<?php if ($darkEnabled || $defaultTheme === 'auto'): ?>
<script src="<?php echo $tplUrl; ?>/js/darkmode.js?<?php echo $djsV; ?>" defer></script>
<?php endif; ?>
</body>
</html>
