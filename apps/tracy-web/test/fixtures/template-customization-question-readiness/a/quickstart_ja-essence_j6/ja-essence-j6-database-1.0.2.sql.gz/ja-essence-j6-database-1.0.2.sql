-- Cut from ja-essence-j6-database-1.0.2.sql.gz for the group-a tests of the Template Customization Question Readiness check: only the rows and columns the rules read.

CREATE TABLE `jd_menu` (
  `id` text,
  `menutype` text,
  `title` text,
  `alias` text,
  `path` text,
  `link` text,
  `type` text,
  `published` text,
  `level` text,
  `params` text,
  `home` text,
  `language` text,
  `client_id` text
) ENGINE=InnoDB;

INSERT INTO `jd_menu` VALUES (134,'mainmenu','Home 3','home-3','home/home-3','index.php?option=com_content&view=featured&layout=ja_essence:news','component',1,2,'{"page_title":"Minimal Blogging Joomla Template - JA Essence"}',1,'*',0);

CREATE TABLE `jd_modules` (
  `id` text,
  `title` text,
  `module` text,
  `position` text,
  `published` text,
  `client_id` text,
  `content` text
) ENGINE=InnoDB;

INSERT INTO `jd_modules` VALUES (121,'Footer Info','mod_custom','footer-info-left',1,0,'<div class="text-center text-md-start">\r\n  <a href="index.php" class="mb-3 d-block">\r\n	<img src="images/joomlart/logo/item-1.png" loading="lazy" width="132" height="40" data-path="local-images:/joomlart/logo/item-1.png"/>\r\n  </a>\r\n\r\n  <p class="mb-0">\r\n    A super modern theme following the latest trends with premium membership\r\n  </p>\r\n</div>\r\n'),
(124,'copyright','mod_footer','copyright',1,0,NULL);

CREATE TABLE `jd_template_styles` (
  `id` text,
  `template` text,
  `client_id` text,
  `home` text,
  `title` text,
  `params` text
) ENGINE=InnoDB;

INSERT INTO `jd_template_styles` VALUES (11,'cassiopeia',0,'0','Cassiopeia - Default','{"brand":"1","logoFile":"","siteTitle":"","siteDescription":"","useFontScheme":"0","colorName":"colors_standard","fluidContainer":"0","stickyHeader":0,"backTop":0}'),
(12,'ja_essence',0,'1','ja_essence - Default','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"default","typelist-theme":"default","typelist-layout":"default","sub-layout":"detail-sidebar","system_t4frontendedit":"1","system_optimizecss":"1","system_optimizecss_exclude":"","system_optimizejs":"1","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","isotope.js","owl.js"]}'),
(13,'ja_essence',0,'0','ja_essence - Home 2','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"offcanvas-desktop","typelist-theme":"home-2","typelist-layout":"home-2","sub-layout":"","system_t4frontendedit":"1","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","isotope.js","owl.js"]}'),
(14,'ja_essence',0,'0','ja_essence - Home 3','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"offcanvas-desktop","typelist-theme":"default","typelist-layout":"home-3","sub-layout":"","system_t4frontendedit":"1","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","isotope.js","owl.js"]}'),
(15,'ja_essence',0,'0','ja_essence - Home 4','{"tplhelper":"{}","typelist-site":"home-4","typelist-navigation":"offcanvas-desktop","typelist-theme":"default","typelist-layout":"home-4","sub-layout":"","system_t4frontendedit":"1","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","owl.js","isotope.js"]}'),
(16,'ja_essence',0,'0','ja_essence - Home 5','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"offcanvas-desktop","typelist-theme":"home-2","typelist-layout":"home-5","sub-layout":"","system_t4frontendedit":"1","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","isotope.js","owl.js"]}'),
(17,'cassiopeia_extended',0,'0','Cassiopeia Extended - Default','{"brand":"1","logoFile":"","siteTitle":"","siteDescription":"","useFontScheme":"0","systemFontBody":"","systemFontHeading":"","colorName":"colors_standard","fluidContainer":"0","stickyHeader":"0","backTop":"0","colorSettings":"0","headerbg":"rgb(193, 205, 207)","headercolor":"rgb(23, 23, 23)","bodybg":"rgb(254, 254, 254)","bodycolor":"rgb(23, 23, 23)","linkcolor":"rgb(29, 121, 137)","linkcolorh":"rgb(14, 59, 67)","btnbg":"rgb(206, 60, 55)","btnbgh":"rgb(131, 35, 32)","btncolor":"rgb(254, 254, 254)","btncolorh":"rgb(254, 254, 254)","footerbg":"rgb(29, 121, 137)","footercolor":"rgb(254, 254, 254)","fontSettings":"0","bodysize":"1","h1size":"2","h2size":"1.7","h3size":"1.5"}');

