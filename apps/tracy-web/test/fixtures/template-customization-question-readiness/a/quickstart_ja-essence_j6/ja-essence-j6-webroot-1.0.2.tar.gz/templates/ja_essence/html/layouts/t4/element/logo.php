<?php
/**
 * Site logo: the T4 base logo (plugins/system/t4/themes/base/html/layouts/t4/element/logo.php)
 * plus the dark-mode logos "Logo Dark Image" (site_logo_dark) and "Logo Dark on mobile"
 * (site_logo_dark_small) declared in templateDetails.xml. Same pattern as JA Nova.
 *
 * With a logo, the light logo is wrapped in .d-light and the dark-mode counterpart in .d-dark;
 * css/template.css shows one of them by the template's dark-mode hook. With a logo but no dark
 * counterpart, dark mode shows the site name as text instead of a logo made for a light
 * background. No logo at all shows the site name as text in both modes.
 * Never recolour or swap the logo from CSS (filter / content:url): it destroys the owner's logo.
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

$doc = $displayData->doc;
$conf = Factory::getConfig();
$site_settings = $doc->params->get('site-settings');

$site_name = $site_settings->get('site_name', $conf->get('sitename'));
$site_slogan = $site_settings->get('site_slogan', '');
$logo = $site_settings->get('site_logo');
$logo_dark = $site_settings->get('site_logo_dark');
$logo_small = $site_settings->get('site_logo_small');
$logo_dark_small = $site_settings->get('site_logo_dark_small');

$cleanUrl = function ($url) {
	return $url ? \T4\Helper\Metadata::cleanImageURL($url)->url : $url;
};
$size = function ($url) {
	return $url && is_file(JPATH_ROOT . '/' . $url) ? getimagesize(JPATH_ROOT . '/' . $url) : false;
};

$logo = $cleanUrl($logo);
$logo_dark = $logo ? $cleanUrl($logo_dark) : '';
$logo_small = $logo ? $cleanUrl($logo_small) : '';
$logo_dark_small = $logo_small ? $cleanUrl($logo_dark_small) : '';

$logo_cls = $logo ? 'logo-image' : 'logo-text';
$logo_sm_cls = '';
if ($logo_small) {
	$logo_cls .= ' logo-control';
	$logo_sm_cls = ' d-none d-sm-block';
}

$alt = strip_tags($site_name);
$hasLink = !empty($displayData->params) && !empty($displayData->params['nolink']) ? false : true;
?>
<div class="navbar-brand <?php echo $logo_cls; ?>">
  <?php if ($hasLink): ?>
  <a href="<?php echo Uri::root() ?>" title="<?php echo $alt; ?>">
  <?php endif; ?>
    <?php if ($logo) : ?>
      <span class="d-light">
        <?php if ($logo_small) : ?><img class="logo-img-sm d-block d-sm-none" src="<?php echo $logo_small; ?>" alt="<?php echo $alt; ?>" /><?php endif; ?>
        <?php list($width, $height) = $size($logo) ?: ['', '']; ?>
        <img class="logo-img<?php echo $logo_sm_cls; ?>" width="<?php echo $width; ?>" height="<?php echo $height; ?>" src="<?php echo $logo; ?>" alt="<?php echo $alt; ?>" />
      </span>
      <span class="d-dark">
        <?php if ($logo_dark) : ?>
          <?php if ($logo_small) : ?><img class="logo-img-sm d-block d-sm-none" src="<?php echo $logo_dark_small ?: $logo_dark; ?>" alt="<?php echo $alt; ?>" /><?php endif; ?>
          <?php list($width, $height) = $size($logo_dark) ?: ['', '']; ?>
          <img class="logo-img<?php echo $logo_sm_cls; ?>" width="<?php echo $width; ?>" height="<?php echo $height; ?>" src="<?php echo $logo_dark; ?>" alt="<?php echo $alt; ?>" />
        <?php elseif ($site_name) : ?>
          <span class="site-name"><?php echo $site_name; ?></span>
        <?php endif; ?>
      </span>
    <?php else : ?>
      <?php if ($site_name) : ?><span class="site-name"><?php echo $site_name; ?></span><?php endif; ?>
      <?php if ($site_slogan) : ?><small class="site-slogan"><?php echo $site_slogan; ?></small><?php endif; ?>
    <?php endif; ?>

  <?php if ($hasLink): ?>
  </a>
  <?php endif; ?>
</div>
