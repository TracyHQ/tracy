<?php
/**
 * Custom module: the T4 base layout (plugins/system/t4/themes/base/html/mod_custom/default.php), plus the
 * dark-mode logo pair for a picture that IS the site logo.
 *
 * The footer logo lives in a Custom module ("Footer Info"), so it is one picture for both modes. When that
 * picture is the Site setting "Logo Image" (site_logo), it is printed as the same .d-light/.d-dark pair as the
 * header (html/layouts/t4/element/logo.php): the picture in light mode, "Logo Dark Image" (site_logo_dark) in
 * dark mode, or the site name when there is no dark logo. css/template.css shows one of them by the template's
 * dark-mode hook. Every other picture, and every module without the site logo, prints exactly as the base layout.
 * Never recolour or swap the logo from CSS (filter / content:url): it destroys the owner's logo.
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

$content = $module->content;
$siteSettings = Factory::getApplication()->getDocument()->params->get('site-settings');
$siteLogo = $siteSettings ? (string) $siteSettings->get('site_logo', '') : '';

if ($siteLogo !== '' && stripos($content, '<img') !== false) {
	// A path as the site profile and the module content may write it: no #joomlaImage fragment, no host, no leading slash.
	$samePath = function ($url) {
		$url = \T4\Helper\Metadata::cleanImageURL(html_entity_decode(trim((string) $url), ENT_QUOTES, 'UTF-8'))->url;
		$root = Uri::root();
		if ($root !== '' && stripos($url, $root) === 0) {
			$url = substr($url, strlen($root));
		}
		$url = preg_replace('#^[a-z][a-z0-9+.-]*://[^/]+#i', '', $url);
		$base = trim(Uri::root(true), '/');
		$url = ltrim($url, '/');
		if ($base !== '' && stripos($url, $base . '/') === 0) {
			$url = substr($url, strlen($base) + 1);
		}
		return $url;
	};
	$logo = $samePath($siteLogo);
	$logoDark = $samePath($siteSettings->get('site_logo_dark', ''));
	$siteName = trim((string) $siteSettings->get('site_name', '')) ?: (string) Factory::getConfig()->get('sitename');

	$content = preg_replace_callback('#<img\b[^>]*>#i', function ($tag) use ($samePath, $logo, $logoDark, $siteName) {
		$img = $tag[0];
		if (!preg_match('#\ssrc\s*=\s*(["\'])(.*?)\1#is', $img, $src) || $samePath($src[2]) !== $logo) {
			return $img;
		}
		if ($logoDark !== '') {
			$dark = str_replace($src[0], ' src="' . htmlspecialchars($logoDark, ENT_QUOTES, 'UTF-8') . '"', $img);
			// data-path names the light picture in the media manager; the dark copy is not that file.
			$dark = preg_replace('#\sdata-path\s*=\s*(["\']).*?\1#is', '', $dark);
		} else {
			$dark = '<span class="site-name">' . htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') . '</span>';
		}
		return '<span class="logo-pair"><span class="d-light">' . $img . '</span><span class="d-dark">' . $dark . '</span></span>';
	}, $content);
}
?>


<div class="custom" <?php if ($params->get('backgroundimage')) : ?> style="background-image:url(<?php echo $params->get('backgroundimage'); ?>)"<?php endif; ?> >
	<?php echo $content; ?>
</div>
