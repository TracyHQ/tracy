<?php
// Cut for the tests: only the title functions and their hooks.
function wp_tracy_business_identity_title( array $parts ): array {
	$vars = wp_tracy_business_identity();
	if ( ! empty( $vars['site.name'] ) ) {
		if ( isset( $parts['site'] ) ) {
			$parts['site'] = $vars['site.name'];
		}
		if ( is_front_page() && isset( $parts['title'] ) ) {
			$parts['title'] = $vars['site.name'];
		}
	}
	if ( is_front_page() && isset( $parts['tagline'] ) && ! empty( $vars['site.slogan'] ) ) {
		$parts['tagline'] = $vars['site.slogan'];
	}
	return $parts;
}
add_filter( 'document_title_parts', 'wp_tracy_business_identity_title', 20 );
