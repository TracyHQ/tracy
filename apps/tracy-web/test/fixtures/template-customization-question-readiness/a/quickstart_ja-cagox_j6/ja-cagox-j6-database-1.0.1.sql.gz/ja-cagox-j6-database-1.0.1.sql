-- Cut from ja-cagox-j6-database-1.0.1.sql.gz for the group-a tests of the Template Customization Question Readiness check: only the rows and columns the rules read.

CREATE TABLE `jd_template_styles` (
  `id` text,
  `template` text,
  `client_id` text,
  `home` text,
  `title` text,
  `params` text
) ENGINE=InnoDB;

INSERT INTO `jd_template_styles` VALUES (9,'ja_cagox',0,'1','ja_cagox - Default','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}'),
(10,'ja_cagox',0,'0','ja_cagox - Home','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}'),
(12,'ja_cagox',0,'0','ja_cagox - Blank','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}'),
(13,'ja_cagox',0,'0','ja_cagox - Landing','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}'),
(14,'ja_cagox',0,'0','ja_cagox - Horizontal','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}'),
(15,'ja_cagox',0,'0','ja_cagox - Simple','{"t3_template":"1","logotype":"image","sitename":"","slogan":"","logoimage":"images\/joomlart\/logo\/logo-default.png","enable_logoimage_sm":"1","logoimage_sm":"images\/joomlart\/logo\/logo-mobile.png","logofootertype":"image","logofooterimage":"images\/joomlart\/logo\/logo-footer.png"}');
