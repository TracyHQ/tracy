<?php
// Cut for the tests: only the title functions and their hooks.
function wp_ja_kinetic_document_title( string $title ): string {
	// A title that already names the site (the home page's "<site> — <slogan>") is left as it is.
	$named = static fn( string $own ): string => esc_html( str_contains( $own, get_bloginfo( 'name' ) ) ? $own : $own . ' ' . apply_filters( 'document_title_separator', '–' ) . ' ' . get_bloginfo( 'name' ) );
	if ( is_404() ) {
		return $named( '404' );
	}
	$list = function_exists( 'wp_ja_kinetic_current_list' ) ? wp_ja_kinetic_current_list() : null;
	if ( $list && 'author' === $list['kind'] && is_author() ) {
		$user = get_queried_object();
		if ( $user instanceof WP_User ) {
			$job = (string) get_user_meta( $user->ID, 'wp_ja_kinetic_job_title', true );
			return $named( $user->display_name . ( '' !== $job ? ' - ' . $job : '' ) );
		}
	}
	$page = $list ? $list['page'] : ( is_singular() ? get_queried_object() : null );
	if ( $page instanceof WP_Post ) {
		$own = (string) get_post_meta( $page->ID, 'wp_ja_kinetic_document_title', true );
		return $named( '' !== $own ? $own : get_the_title( $page ) );
	}
	return $title;
}
function wp_ja_kinetic_document_title_parts( array $parts ): array {
	unset( $parts['tagline'] );
	return $parts;
}
add_filter( 'pre_get_document_title', 'wp_ja_kinetic_document_title' );
add_filter( 'document_title_parts', 'wp_ja_kinetic_document_title_parts' );
