-- Cut from ja-morgan-j6-database-1.0.2.sql.gz for the group-a tests of the Template Customization Question Readiness check: only the rows and columns the rules read.

CREATE TABLE `jd_menu` (
  `id` text,
  `menutype` text,
  `title` text,
  `alias` text,
  `path` text,
  `link` text,
  `type` text,
  `published` text,
  `level` text,
  `params` text,
  `home` text,
  `language` text,
  `client_id` text
) ENGINE=InnoDB;

INSERT INTO `jd_menu` VALUES (157,'mainmenu','Home','home','home','index.php?option=com_content&view=featured','component',1,1,'{"page_title":"Creative multipurpose Joomla template for business - JA Morgan"}',1,'*',0);

CREATE TABLE `jd_modules` (
  `id` text,
  `title` text,
  `module` text,
  `position` text,
  `published` text,
  `client_id` text,
  `content` text
) ENGINE=InnoDB;

INSERT INTO `jd_modules` VALUES (121,'Foooter','mod_footer','footer',1,0,''),
(163,'Copyright.','mod_custom','footer-4',1,0,'<p>© 2019 Morgan. All Rights Reserved.<br> Made by JoomlArt</p>');

CREATE TABLE `jd_template_styles` (
  `id` text,
  `template` text,
  `client_id` text,
  `home` text,
  `title` text,
  `params` text
) ENGINE=InnoDB;

INSERT INTO `jd_template_styles` VALUES (9,'ja_morgan',0,'1','ja_morgan - Default','{"t3_template": "1", "devmode": "0", "themermode": "1", "legacy_css": "1", "responsive": "1", "non_responsive_width": "970px", "build_rtl": "0", "t3-assets": "t3-assets", "t3-rmvlogo": "1", "minify": "1", "minify_js": "1", "minify_js_tool": "jsmin", "minify_exclude": "", "link_titles": "", "theme": "", "logotype": "text", "sitename": "Morgan<b>.</b>", "slogan": "", "logoimage": "", "enable_logoimage_sm": "0", "logoimage_sm": "", "mainlayout": "default", "sublayout": "", "skip_component_content": ["157", "101", "154", "156"], "mm_type": "mainmenu", "navigation_trigger": "hover", "navigation_type": "megamenu", "navigation_animation": "fading", "navigation_animation_duration": "600", "mm_config": "", "navigation_collapse_enable": "1", "addon_offcanvas_enable": "1", "addon_offcanvas_effect": "off-canvas-effect-4", "snippet_open_head": "", "snippet_close_head": "", "snippet_open_body": "", "snippet_close_body": "", "snippet_debug": "0", "logoimage_dark": ""}'),
(10,'ja_morgan',0,'0','ja_morgan - Style 2','{"t3_template": "1", "devmode": "0", "themermode": "1", "legacy_css": "1", "responsive": "1", "non_responsive_width": "970px", "build_rtl": "0", "t3-assets": "t3-assets", "t3-rmvlogo": "1", "minify": "1", "minify_js": "1", "minify_js_tool": "jsmin", "minify_exclude": null, "link_titles": null, "theme": "style-2", "logotype": "text", "sitename": "Morgan<b>.</b>", "slogan": "", "logoimage": "", "enable_logoimage_sm": "0", "logoimage_sm": "", "mainlayout": "home-2", "sublayout": "", "skip_component_content": ["101", "128"], "mm_type": "mainmenu", "navigation_trigger": "hover", "navigation_type": "megamenu", "navigation_animation": "fading", "navigation_animation_duration": "600", "mm_config": null, "navigation_collapse_enable": "1", "addon_offcanvas_enable": "1", "addon_offcanvas_effect": "off-canvas-effect-4", "snippet_open_head": null, "snippet_close_head": null, "snippet_open_body": null, "snippet_close_body": null, "snippet_debug": "0", "logoimage_dark": ""}'),
(11,'ja_morgan',0,'0','ja_morgan - Style 3','{"t3_template": "1", "devmode": "0", "themermode": "1", "legacy_css": "1", "responsive": "1", "non_responsive_width": "970px", "build_rtl": "0", "t3-assets": "t3-assets", "t3-rmvlogo": "1", "minify": "1", "minify_js": "1", "minify_js_tool": "jsmin", "minify_exclude": null, "link_titles": null, "theme": "style-3", "logotype": "text", "sitename": "Morgan<b>.</b>", "slogan": "", "logoimage": "", "enable_logoimage_sm": "0", "logoimage_sm": "", "mainlayout": "home-3", "sublayout": "", "skip_component_content": ["101", "128", "153", "155"], "mm_type": "mainmenu", "navigation_trigger": "hover", "navigation_type": "megamenu", "navigation_animation": "fading", "navigation_animation_duration": "600", "mm_config": null, "navigation_collapse_enable": "1", "addon_offcanvas_enable": "1", "addon_offcanvas_effect": "off-canvas-effect-4", "snippet_open_head": null, "snippet_close_head": null, "snippet_open_body": null, "snippet_close_body": null, "snippet_debug": "0", "logoimage_dark": ""}'),
(12,'ja_morgan',0,'0','ja_morgan - Style 4','{"t3_template": "1", "devmode": "0", "themermode": "1", "legacy_css": "1", "responsive": "1", "non_responsive_width": "970px", "build_rtl": "0", "t3-assets": "t3-assets", "t3-rmvlogo": "1", "minify": "1", "minify_js": "1", "minify_js_tool": "jsmin", "minify_exclude": null, "link_titles": null, "theme": "style-4", "logotype": "text", "sitename": "Morgan<b>.</b>", "slogan": "", "logoimage": "", "enable_logoimage_sm": "0", "logoimage_sm": "", "mainlayout": "home-4", "sublayout": "", "skip_component_content": ["101", "128", "153", "155"], "mm_type": "mainmenu", "navigation_trigger": "hover", "navigation_type": "megamenu", "navigation_animation": "fading", "navigation_animation_duration": "600", "mm_config": null, "navigation_collapse_enable": "1", "addon_offcanvas_enable": "1", "addon_offcanvas_effect": "off-canvas-effect-4", "snippet_open_head": null, "snippet_close_head": null, "snippet_open_body": null, "snippet_close_body": null, "snippet_debug": "0", "logoimage_dark": ""}'),
(16,'cassiopeia',0,'0','Cassiopeia - Default','{}'),
(17,'cassiopeia_extended',0,'0','Cassiopeia Extended - Default','{"brand":"1","logoFile":"","siteTitle":"","siteDescription":"","useFontScheme":"0","systemFontBody":"","systemFontHeading":"","colorName":"colors_standard","fluidContainer":"0","stickyHeader":"0","backTop":"0","colorSettings":"0","headerbg":"rgb(193, 205, 207)","headercolor":"rgb(23, 23, 23)","bodybg":"rgb(254, 254, 254)","bodycolor":"rgb(23, 23, 23)","linkcolor":"rgb(29, 121, 137)","linkcolorh":"rgb(14, 59, 67)","btnbg":"rgb(206, 60, 55)","btnbgh":"rgb(131, 35, 32)","btncolor":"rgb(254, 254, 254)","btncolorh":"rgb(254, 254, 254)","footerbg":"rgb(29, 121, 137)","footercolor":"rgb(254, 254, 254)","fontSettings":"0","bodysize":"1","h1size":"2","h2size":"1.7","h3size":"1.5"}');

