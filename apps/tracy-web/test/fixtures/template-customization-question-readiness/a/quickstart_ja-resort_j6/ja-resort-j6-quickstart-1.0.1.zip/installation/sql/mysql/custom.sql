-- Cut from resort.sql for the group-a tests of the Template Customization Question Readiness check: only the rows and columns the rules read.

CREATE TABLE `#__menu` (
  `id` text,
  `menutype` text,
  `title` text,
  `alias` text,
  `path` text,
  `link` text,
  `type` text,
  `published` text,
  `level` text,
  `params` text,
  `home` text,
  `language` text,
  `client_id` text
) ENGINE=InnoDB;

INSERT INTO `#__menu` VALUES (101,'mainmenu','Home','homepage','homepage','index.php?option=com_content&view=featured','component',1,1,'{"page_title":"Ultimate Joomla resort and hotel booking template - JA Resort"}',1,'*',0);

CREATE TABLE `#__modules` (
  `id` text,
  `title` text,
  `module` text,
  `position` text,
  `published` text,
  `client_id` text,
  `content` text
) ENGINE=InnoDB;

INSERT INTO `#__modules` VALUES (114,'Footer','mod_footer','footer',1,0,'');

CREATE TABLE `#__template_styles` (
  `id` text,
  `template` text,
  `client_id` text,
  `home` text,
  `title` text,
  `params` text
) ENGINE=InnoDB;

INSERT INTO `#__template_styles` VALUES (9,'ja_resort',0,'1','ja_resort - Default','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"default","typelist-theme":"default","typelist-layout":"default","sub-layout":"","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","font.iconmoon","owl.carousel","font.ionicons","html5lightbox","com.solidres"]}'),
(10,'ja_resort',0,'0','ja_resort - Home','{"tplhelper":"{}","typelist-site":"default","typelist-navigation":"default","typelist-theme":"default","typelist-layout":"home","sub-layout":"","system_optimizecss":"1","system_optimizecss_exclude":"","system_optimizejs_exclude":"","system_advancedCodeAfterHead":"","system_advancedCodeBeforeHead":"","system_advancedCodeAfterBody":"","system_advancedCodeBeforeBody":"","system_addons":["font.awesome5","font.awesome4","font.iconmoon","owl.carousel","font.ionicons","html5lightbox","com.solidres"]}'),
(12,'cassiopeia',0,'0','Cassiopeia - Default','{}'),
(13,'cassiopeia_extended',0,'0','Cassiopeia Extended - Default','{"brand":"1","logoFile":"","siteTitle":"","siteDescription":"","useFontScheme":"0","systemFontBody":"","systemFontHeading":"","colorName":"colors_standard","fluidContainer":"0","stickyHeader":"0","backTop":"0","colorSettings":"0","headerbg":"rgb(193, 205, 207)","headercolor":"rgb(23, 23, 23)","bodybg":"rgb(254, 254, 254)","bodycolor":"rgb(23, 23, 23)","linkcolor":"rgb(29, 121, 137)","linkcolorh":"rgb(14, 59, 67)","btnbg":"rgb(206, 60, 55)","btnbgh":"rgb(131, 35, 32)","btncolor":"rgb(254, 254, 254)","btncolorh":"rgb(254, 254, 254)","footerbg":"rgb(29, 121, 137)","footercolor":"rgb(254, 254, 254)","fontSettings":"0","bodysize":"1","h1size":"2","h2size":"1.7","h3size":"1.5"}');

