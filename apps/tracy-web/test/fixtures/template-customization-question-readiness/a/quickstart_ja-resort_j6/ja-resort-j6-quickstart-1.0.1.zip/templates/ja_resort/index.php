<?php
/**
 * @package   T4_BLANK
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/* ---------------------------------------------------------------------------
 * Dark mode wiring (GUI-configurable: cookie + server-resolve). Light mode is
 * untouched; every dark rule lives in css/darkmode.css scoped under
 * html[data-theme="dark"]. Two admin settings drive it (Template → Settings →
 * Other): other_darkmode (show/hide the toggle) and other_default_theme
 * (light|dark|auto). Persistence is the cookie ja_resort-theme so PHP resolves
 * the first-paint theme server-side (no FOUC; localStorage can't do this).
 * ------------------------------------------------------------------------- */
$darkEnabled  = false;
$defaultTheme = 'light';
$siteProfile  = $this->params->get('typelist-site', 'default');

// LOCAL-FIRST: the admin GUI saves to local/etc/site/<profile>.json; fall back to base etc/site/.
// (Do NOT read the site-settings Registry here — at index.php time it is a stub stdClass and
//  calling ->get() fatals; T4 builds the real Registry later during the body render.)
$profileFile = __DIR__ . '/local/etc/site/' . basename($siteProfile) . '.json';
if (!is_file($profileFile)) {
	$profileFile = __DIR__ . '/etc/site/' . basename($siteProfile) . '.json';
}
if (is_file($profileFile)) {
	$cfg          = json_decode((string) file_get_contents($profileFile), true) ?: [];
	$darkEnabled  = isset($cfg['other_darkmode'])
		&& filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN);
	$defaultTheme = (string) ($cfg['other_default_theme'] ?? 'light');
} else {
	$siteSettings = $this->params->get('site-settings');
	if ($siteSettings instanceof \Joomla\Registry\Registry) {
		$darkEnabled  = filter_var($siteSettings->get('other_darkmode', '0'), FILTER_VALIDATE_BOOLEAN);
		$defaultTheme = (string) $siteSettings->get('other_default_theme', 'light');
	}
}
if (!in_array($defaultTheme, ['auto', 'light', 'dark'], true)) {
	$defaultTheme = 'light';
}

$cookieChoice = \Joomla\CMS\Factory::getApplication()->input->cookie->get('ja_resort-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') {
	$cookieChoice = '';
}

// The cookie applies ONLY when switching is enabled; otherwise the site is locked to the GUI
// default (so "off + dark" = a dark-only site). NEVER force light when disabled.
if ($darkEnabled && $cookieChoice !== '') {
	$resolved = $cookieChoice;
} elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') {
	$resolved = $defaultTheme;
} else {
	$resolved = '';                       // auto → resolve against the OS at first paint
}

if ($resolved !== '') {
	$this->addScriptDeclaration(
		'(function(){var t=' . json_encode($resolved) . ';'
		. "document.documentElement.setAttribute('data-theme',t);"
		. "document.documentElement.setAttribute('data-bs-theme',t);"
		. "if(t==='dark'){document.documentElement.classList.add('t4-dark');}})();"
	);
} else {
	$this->addScriptDeclaration(
		"(function(){try{var d=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;"
		. "var t=d?'dark':'light';document.documentElement.setAttribute('data-theme',t);"
		. "document.documentElement.setAttribute('data-bs-theme',t);"
		. "if(d){document.documentElement.classList.add('t4-dark');}}"
		. "catch(e){document.documentElement.setAttribute('data-theme','light');document.documentElement.setAttribute('data-bs-theme','light');}})();"
	);
}
// Expose the default + whether switching is enabled to darkmode.js (OS-follow / no-clobber gating).
$this->addScriptDeclaration('window.jaResortTheme={def:' . json_encode($defaultTheme) . ',enabled:' . ($darkEnabled ? 'true' : 'false') . '};');

// Load darkmode.css whenever the page CAN be dark (NOT only when the toggle is enabled), LAST in
// <head> (addCustomTag renders after the optimize bundle) so equal-specificity ties resolve to dark.
if ($darkEnabled || $defaultTheme === 'dark' || $defaultTheme === 'auto') {
	$darkCss = __DIR__ . '/css/darkmode.css';
	if (is_file($darkCss)) {
		$href = \Joomla\CMS\Uri\Uri::root(true) . '/templates/' . $this->template . '/css/darkmode.css?' . filemtime($darkCss);
		$this->addCustomTag('<link rel="stylesheet" type="text/css" href="' . $href . '">');
	}
}
// darkmode.js only for live switching (toggle on) or OS-follow (auto).
if ($darkEnabled || $defaultTheme === 'auto') {
	$darkJs = __DIR__ . '/js/darkmode.js';
	if (is_file($darkJs)) {
		$this->getWebAssetManager()->registerAndUseScript('tpl.ja_resort.darkmode',
			'templates/' . $this->template . '/js/darkmode.js?' . filemtime($darkJs), [], ['defer' => true]);
	}
}

if (class_exists('\T4\T4')) {
	\T4\T4::render($this);
} else {
	include 'error-t4.php';
}
