<?php
/*
 * ------------------------------------------------------------------------
 * JA Resort TPL
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites:  http://www.joomlart.com -  http://www.joomlancers.com
 * This file may not be redistributed in whole or significant part.
 * ------------------------------------------------------------------------
*/

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;
if (!isset($this->error)) {
	$this->error = JError::raiseWarning(404, Text::_('JERROR_ALERTNOAUTHOR'));
	$this->debug = false;
}
//get language and direction
$doc = Factory::getDocument(); 
$this->language = $doc->language;
$this->direction = $doc->direction;
$theme = Factory::getApplication()->getTemplate(true)->params->get('theme', '');

/* Dark mode (GUI-configurable) — this standalone doc bypasses index.php, so
 * resolve the theme itself, honoring the admin lock/default + cookie + OS. */
$app          = Factory::getApplication();
$darkEnabled  = false;
$defaultTheme = 'light';
$siteProfile  = $doc->params ? $doc->params->get('typelist-site', 'default') : 'default';
$profileFile  = __DIR__ . '/local/etc/site/' . basename((string) $siteProfile) . '.json';
if (!is_file($profileFile)) {
	$profileFile = __DIR__ . '/etc/site/' . basename((string) $siteProfile) . '.json';
}
if (is_file($profileFile)) {
	$cfg          = json_decode((string) file_get_contents($profileFile), true) ?: [];
	$darkEnabled  = isset($cfg['other_darkmode']) && filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN);
	$defaultTheme = (string) ($cfg['other_default_theme'] ?? 'light');
}
if (!in_array($defaultTheme, ['auto', 'light', 'dark'], true)) { $defaultTheme = 'light'; }
$cookieChoice = $app->input->cookie->get('ja_resort-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') { $cookieChoice = ''; }
if ($darkEnabled && $cookieChoice !== '')                      { $resolved = $cookieChoice; }
elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') { $resolved = $defaultTheme; }
else                                                           { $resolved = ''; }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
<?php if ($resolved !== '') : ?>
	<script>(function(){var t=<?php echo json_encode($resolved); ?>;var h=document.documentElement;h.setAttribute('data-theme',t);h.setAttribute('data-bs-theme',t);if(t==='dark')h.classList.add('t4-dark');})();</script>
<?php else : ?>
	<script>(function(){try{var m=document.cookie.match(/(?:^|;\s*)ja_resort-theme=(dark|light)\b/);var t=m?m[1]:'';if(t!=='dark'&&t!=='light')t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';var h=document.documentElement;h.setAttribute('data-theme',t);h.setAttribute('data-bs-theme',t);if(t==='dark')h.classList.add('t4-dark');}catch(e){}})();</script>
<?php endif; ?>
	<title><?php echo $this->error->getCode(); ?> - <?php echo $this->title; ?></title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link href="https://fonts.googleapis.com/css?family=Frank+Ruhl+Libre:400,500,700|Poppins:400,500,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/error.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/darkmode.css" type="text/css" />

</head>
<body class="page-error">
	<div class="main">
		<div class="error">
			<div id="outline">
				<div id="errorboxoutline">
					<div class="error-code"><?php 
						$errcode = str_split($this->error->getCode());
						$i = 0;
						$lastclass='';
						foreach($errcode as $c){
	                        $firstclass = ($i==0)?'first':'';
							if($i==(count($errcode)-1)){
								$lastclass='last';
							}
							echo '<span class="'.$lastclass.$firstclass.'">'.$c.'</span>';
							$i++;
						}
						?>
					</div>
					<div class="wrap-text">
						<div class="error-message"><h2><span><?php echo $this->error->getMessage(); ?></span></h2></div>
						<div id="errorboxbody">
							<p><?php echo Text::_('JERROR_LAYOUT_PLEASE_TRY_ONE_OF_THE_FOLLOWING_PAGES'); ?></p>
						</div>
						<a class="button-home" href="<?php echo $this->baseurl; ?>/index.php" title="<?php echo Text::_('JERROR_LAYOUT_GO_TO_THE_HOME_PAGE'); ?>"><?php echo Text::_('JERROR_LAYOUT_HOME_PAGE'); ?><span class="ion-android-arrow-forward"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
