-- Cut from ja-essence-wp7-database-1.0.9.sql.gz for the REL-2 tests: only the rows and columns the rule reads.

CREATE TABLE `tr_posts` (
  `ID` text,
  `post_content` text,
  `post_title` text,
  `post_status` text,
  `post_name` text,
  `post_parent` text,
  `post_type` text
) ENGINE=InnoDB;

INSERT INTO `tr_posts` VALUES ('3','','Privacy Policy','draft','privacy-policy','0','page'),
('116','','Not found','draft','page-not-found','0','page'),
('117','','Contact','publish','contact','0','page'),
('118','','Home 3','publish','home-3','0','page'),
('119','','Pages','publish','pages','0','page'),
('120','','Home','publish','home','0','page'),
('121','','Detail','publish','detail','0','page'),
('122','','Resources','publish','resources','0','page'),
('123','','Lifestyle','publish','lifestyle','0','page'),
('124','','Category','publish','category','0','page'),
('125','','Home 2','publish','home-2','120','page'),
('126','','Layout 1','publish','layout-1','121','page'),
('127','','Layout 2','publish','layout-2','121','page'),
('128','','Layout 3','publish','layout-3','121','page'),
('129','','Video','publish','video','121','page'),
('130','','Gallery','publish','gallery','121','page'),
('131','','Home 4','publish','home-4','120','page'),
('132','','Home 5','publish','home-5','120','page'),
('133','','Home 1','publish','home-1','120','page'),
('134','','User','publish','user','119','page'),
('135','','J!Pages','publish','j-pages','119','page'),
('136','','J! Content','publish','j-content','119','page'),
('137','','Category Style 1','publish','category-style-1','124','page'),
('138','','Category Style 2','publish','category-style-2','124','page'),
('139','','Category Style 3','publish','category-style-3','124','page'),
('140','','Category Style 4','publish','category-style-4','124','page'),
('141','','Login Form','publish','login-form','134','page'),
('142','','Registration Form','publish','registration-form','134','page'),
('143','','User Profile','publish','user-profile','134','page'),
('144','','Error Page','publish','error-page','135','page'),
('145','','Offline Pages','publish','offline-pages','135','page'),
('146','','Typography','publish','typography','135','page'),
('147','','Featured Articles','publish','featured-articles','136','page'),
('148','','Edit User Profile','publish','edit-user-profile','134','page'),
('149','','Smart Search','draft','smart-search','135','page'),
('150','','Category Blog','publish','category-blog','136','page'),
('151','','Author listting','publish','author-listting','136','page'),
('152','','Tagged Items','publish','tagged-items','136','page'),
('155','<!-- wp:navigation-submenu {"label":"Home","type":"page","id":118,"url":"https://quickstart.invalid/","kind":"post-type"} -->\n<!-- wp:navigation-link {"label":"Home 1","type":"page","id":133,"url":"https://quickstart.invalid/home/home-1/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Home 2","type":"page","id":125,"url":"https://quickstart.invalid/home/home-2/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Home 3","type":"page","id":118,"url":"https://quickstart.invalid/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Home 4","type":"page","id":131,"url":"https://quickstart.invalid/home/home-4/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Home 5","type":"page","id":132,"url":"https://quickstart.invalid/home/home-5/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-submenu {"label":"#Category"} -->\n<!-- wp:navigation-link {"label":"Category Style 1","type":"page","id":137,"url":"https://quickstart.invalid/category/category-style-1/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Category Style 2","type":"page","id":138,"url":"https://quickstart.invalid/category/category-style-2/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Category Style 3","type":"page","id":139,"url":"https://quickstart.invalid/category/category-style-3/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Category Style 4","type":"page","id":140,"url":"https://quickstart.invalid/category/category-style-4/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-submenu {"label":"Detail"} -->\n<!-- wp:navigation-link {"label":"Layout 1","type":"page","id":126,"url":"https://quickstart.invalid/detail/layout-1/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Layout 2","type":"page","id":127,"url":"https://quickstart.invalid/detail/layout-2/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Layout 3","type":"page","id":128,"url":"https://quickstart.invalid/detail/layout-3/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Video","type":"page","id":129,"url":"https://quickstart.invalid/detail/video/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Gallery","type":"page","id":130,"url":"https://quickstart.invalid/detail/gallery/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-submenu {"label":"Pages"} -->\n<!-- wp:navigation-submenu {"label":"User"} -->\n<!-- wp:navigation-link {"label":"Login Form","type":"page","id":141,"url":"https://quickstart.invalid/pages/user/login-form/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Registration Form","type":"page","id":142,"url":"https://quickstart.invalid/pages/user/registration-form/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"User Profile","type":"page","id":143,"url":"https://quickstart.invalid/pages/user/user-profile/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Edit User Profile","type":"page","id":148,"url":"https://quickstart.invalid/pages/user/edit-user-profile/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-submenu {"label":"J!Pages"} -->\n<!-- wp:navigation-link {"label":"Error Page","type":"page","id":144,"url":"https://quickstart.invalid/pages/j-pages/error-page/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Offline Pages","type":"page","id":145,"url":"https://quickstart.invalid/pages/j-pages/offline-pages/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Typography","type":"page","id":146,"url":"https://quickstart.invalid/pages/j-pages/typography/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Smart Search","url":"/pages/j-pages/smart-search/","kind":"custom"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-submenu {"label":"J! Content"} -->\n<!-- wp:navigation-link {"label":"Category Blog","type":"page","id":150,"url":"https://quickstart.invalid/pages/j-content/category-blog/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Featured Articles","type":"page","id":147,"url":"https://quickstart.invalid/pages/j-content/featured-articles/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Author listting","type":"page","id":151,"url":"https://quickstart.invalid/pages/j-content/author-listting/","kind":"post-type"} /-->\n<!-- wp:navigation-link {"label":"Tagged Items","type":"page","id":152,"url":"https://quickstart.invalid/pages/j-content/tagged-items/","kind":"post-type"} /-->\n<!-- /wp:navigation-submenu -->\n<!-- /wp:navigation-submenu -->\n<!-- wp:navigation-link {"label":"Contact","type":"page","id":117,"url":"https://quickstart.invalid/contact/","kind":"post-type"} /-->','mainmenu','publish','mainmenu','0','wp_navigation'),
('157','<!-- wp:group {"className":"je-header__inner","layout":{"type":"default"}} -->\n<div class="wp-block-group je-header__inner">\n<!-- wp:group {"className":"je-header__top","layout":{"type":"default"}} -->\n<div class="wp-block-group je-header__top">\n<!-- wp:social-links {"iconColor":"fg-2","className":"je-social is-style-logos-only","metadata":{"name":"header.social"},"layout":{"type":"flex","justifyContent":"left"}} -->\n<ul class="wp-block-social-links je-social is-style-logos-only has-icon-color">\n<!-- wp:social-link {"url":"#","service":"facebook"} /-->\n<!-- wp:social-link {"url":"#","service":"x"} /-->\n<!-- wp:social-link {"url":"#","service":"instagram"} /-->\n<!-- wp:social-link {"url":"#","service":"feed"} /-->\n</ul>\n<!-- /wp:social-links -->\n<!-- wp:site-title {"level":0,"className":"je-site-name"} /-->\n<!-- wp:buttons {"className":"je-subscribe","layout":{"type":"flex","justifyContent":"right"}} -->\n<div class="wp-block-buttons je-subscribe">\n<!-- wp:button {"className":"je-btn-primary","metadata":{"name":"header.subscribe"}} -->\n<div class="wp-block-button je-btn-primary"><a class="wp-block-button__link wp-element-button" href="/contact">Subscribe</a></div>\n<!-- /wp:button -->\n</div>\n<!-- /wp:buttons -->\n</div>\n<!-- /wp:group -->\n<!-- wp:group {"className":"je-header__bottom","layout":{"type":"default"}} -->\n<div class="wp-block-group je-header__bottom">\n<!-- wp:group {"className":"je-header__tools","layout":{"type":"default"}} -->\n<div class="wp-block-group je-header__tools">\n<!-- wp:html -->\n<button type="button" class="je-drawer-toggle" aria-controls="je-drawer" aria-expanded="false" aria-label="Open the menu"><span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span></button>\n<button type="button" class="je-theme-toggle" data-tracy-theme-toggle aria-pressed="false" aria-label="Theme: light. Switch to dark"><svg class="je-tt-moon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg><svg class="je-tt-sun" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg></button>\n<!-- /wp:html -->\n</div>\n<!-- /wp:group -->\n<!-- wp:navigation {"ref":155,"overlayMenu":"never","className":"je-nav","metadata":{"name":"nav.mainmenu"},"layout":{"type":"flex","justifyContent":"center","flexWrap":"nowrap"}} /-->\n<!-- wp:search {"label":"Search","showLabel":false,"buttonText":"Search","buttonPosition":"button-only","buttonUseIcon":true,"isSearchFieldHidden":true,"className":"je-search"} /-->\n</div>\n<!-- /wp:group -->\n<!-- wp:group {"anchor":"je-drawer","className":"je-drawer","layout":{"type":"default"}} -->\n<div class="wp-block-group je-drawer" id="je-drawer">\n<!-- wp:group {"className":"je-drawer__head","layout":{"type":"default"}} -->\n<div class="wp-block-group je-drawer__head">\n<!-- wp:paragraph {"className":"je-drawer__title"} -->\n<p class="je-drawer__title">Sidebar Menu</p>\n<!-- /wp:paragraph -->\n<!-- wp:html -->\n<button type="button" class="je-theme-toggle" data-tracy-theme-toggle aria-pressed="false" aria-label="Theme: light. Switch to dark"><svg class="je-tt-moon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg><svg class="je-tt-sun" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg></button>\n<!-- /wp:html -->\n<!-- wp:html -->\n<button type="button" class="je-drawer-close" aria-label="Close the menu">&times;</button>\n<!-- /wp:html -->\n</div>\n<!-- /wp:group -->\n<!-- wp:paragraph {"className":"je-drawer__menu"} -->\n<p class="je-drawer__menu">Menu</p>\n<!-- /wp:paragraph -->\n<!-- wp:navigation {"ref":155,"overlayMenu":"never","className":"je-drawer-nav","metadata":{"name":"nav.mainmenu"},"layout":{"type":"flex","orientation":"vertical"}} /-->\n</div>\n<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n','Header','publish','header','0','wp_template_part');

CREATE TABLE `tr_options` (
  `option_id` text,
  `option_name` text,
  `option_value` text
) ENGINE=InnoDB;

INSERT INTO `tr_options` VALUES ('41','template','wp-ja-essence'),
('42','stylesheet','wp-ja-essence'),
('52','show_on_front','page'),
('83','page_on_front','118');

