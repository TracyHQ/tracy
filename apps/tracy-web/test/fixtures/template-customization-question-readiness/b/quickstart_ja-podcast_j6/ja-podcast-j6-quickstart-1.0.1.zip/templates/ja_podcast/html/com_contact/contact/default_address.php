<?php
/**
T4 Overide
 */

defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;

/**
 * Marker_class: Class based on the selection of text, none, or icons
 * jicon-text, jicon-none, jicon-icon
 */
?>
<dl class="contact-address dl-horizontal" itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">
	<?php if (($this->params->get('address_check') > 0) &&
		($this->item->address || $this->item->suburb  || $this->item->state || $this->item->country || $this->item->postcode)) : ?>
		<?php if ($this->params->get('address_check') > 0) : ?>
			<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
				<span class="<?php echo $this->params->get('marker_class'); ?>" >
					<?php echo $this->params->get('marker_address'); ?>
				</span>
			</dt>
		<?php endif; ?>

		<?php if ($this->item->address && $this->params->get('show_street_address')) : ?>
			<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
				<span class="fa fa-map-marker"></span>
				<span class="contact-street" itemprop="streetAddress">
					<h3 class="title">Address</h3>
					<span class="txt"><?php echo $this->item->address; ?></span>
				</span>
			</dd>
		<?php endif; ?>

		<?php if ($this->item->suburb && $this->params->get('show_suburb')) : ?>
			<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
				<span class="fa fa-location-arrow"></span>
				<span class="contact-suburb" itemprop="addressLocality">
					<h3 class="title">Suburb</h3>
					<span class="txt"><?php echo $this->item->suburb .'<br/>'; ?></span>
				</span>
			</dd>
		<?php endif; ?>
		<?php if ($this->item->state && $this->params->get('show_state')) : ?>
			<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
				<span class="fa fa-location-arrow"></span>
				<span class="contact-state" itemprop="addressRegion">
					<h3 class="title">State</h3>
					<span class="txt"><?php echo $this->item->state . '<br/>'; ?></span>
				</span>
			</dd>
		<?php endif; ?>
		<?php if ($this->item->postcode && $this->params->get('show_postcode')) : ?>
			<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
				<span class="fa fa-magic"></span>
				<span class="contact-postcode" itemprop="postalCode">
					<h3 class="title">Postcode</h3>
					<span class="txt"><?php echo $this->item->postcode .'<br/>'; ?></span>
				</span>
			</dd>
		<?php endif; ?>
		<?php if ($this->item->country && $this->params->get('show_country')) : ?>
		<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
			<span class="fa fa-building-o"></span>
			<span class="contact-country" itemprop="addressCountry">
				<h3 class="title">Country</h3>
				<span class="txt"><?php echo $this->item->country .'<br/>'; ?></span>
			</span>
		</dd>
		<?php endif; ?>
	<?php endif; ?>

<?php if ($this->item->email_to && $this->params->get('show_email')) : ?>
	<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="<?php echo $this->params->get('marker_class'); ?>" itemprop="email">
			<?php echo nl2br($this->params->get('marker_email')); ?>
		</span>
	</dt>
	<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="fa fa-envelope-o"></span>
		<span class="contact-emailto">
			<h3 class="title">Email</h3>
			<span class="txt"><?php echo $this->item->email_to; ?></span>
		</span>
	</dd>
<?php endif; ?>

<?php if ($this->item->telephone && $this->params->get('show_telephone')) : ?>
	<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="<?php echo $this->params->get('marker_class'); ?>">
			<?php echo $this->params->get('marker_telephone'); ?>
		</span>
	</dt>
	<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="fa fa-phone"></span>
		<span class="contact-telephone" itemprop="telephone">
			<h3 class="title">Call Us</h3>
			<span class="txt"><?php echo nl2br($this->item->telephone); ?></span>
		</span>
	</dd>
<?php endif; ?>
<?php if ($this->item->fax && $this->params->get('show_fax')) : ?>
	<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="<?php echo $this->params->get('marker_class'); ?>">
			<?php echo $this->params->get('marker_fax'); ?>
		</span>
	</dt>
	<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="fa fa-print"></span>
		<span class="contact-fax" itemprop="faxNumber">
			<h3 class="title">Fax</h3>
			<span class="txt"><?php echo nl2br($this->item->fax); ?></span>
		</span>
	</dd>
<?php endif; ?>
<?php if ($this->item->mobile && $this->params->get('show_mobile')) :?>
	<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="<?php echo $this->params->get('marker_class'); ?>" >
			<?php echo $this->params->get('marker_mobile'); ?>
		</span>
	</dt>
	<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="fa fa-phone-square"></span>
		<span class="contact-mobile" itemprop="telephone">
			<h3 class="title">Mobile</h3>
			<span class="txt"><?php echo nl2br($this->item->mobile); ?></span>
		</span>
	</dd>
<?php endif; ?>
<?php if ($this->item->webpage && $this->params->get('show_webpage')) : ?>
	<dt class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="<?php echo $this->params->get('marker_class'); ?>" >
			<?php echo Text::_('TPL_CONTACT_WEBSITE');?>
		</span>
	</dt>
	<dd class="<?php echo "show-".$this->params->get('contact_icons') ?>">
		<span class="fa fa-globe"></span>
		<span class="contact-webpage">
			<h3 class="title">Webpage</h3>
			<a clss="txt" href="<?php echo $this->item->webpage; ?>" target="_blank" itemprop="url">
			<?php echo $this->item->webpage; ?></a>
		</span>
	</dd>
<?php endif; ?>
</dl>
