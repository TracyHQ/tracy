<?php

/**
 * @package     Joomla.Site
 * @subpackage  Template.system
 *
 * @copyright   Copyright (C) 2005 - 2021 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\AuthenticationHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$app = Factory::getApplication();

// Add JavaScript Frameworks
HTMLHelper::_('bootstrap.framework');

require_once JPATH_ADMINISTRATOR . '/components/com_users/helpers/users.php';

$twofactormethods = UsersHelper::getTwoFactorMethods();

/* ---- Dark-mode resolution — honor the GUI lock/default like index.php (local-first).
 * Standalone page (bypasses T4::render); resolve the "site" profile from disk. */
$doc          = Factory::getDocument();
$darkEnabled  = true;
$defaultTheme = 'auto';
$siteProfile  = ($doc->params ?? null) ? $doc->params->get('typelist-site', 'default') : 'default';
$profileFile  = __DIR__ . '/local/etc/site/' . basename((string) $siteProfile) . '.json';
if (!is_file($profileFile)) {
    $profileFile = __DIR__ . '/etc/site/' . basename((string) $siteProfile) . '.json';
}
if (is_file($profileFile)) {
    $cfg          = json_decode((string) file_get_contents($profileFile), true) ?: [];
    $darkEnabled  = !isset($cfg['other_darkmode']) || filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN);
    $defaultTheme = (string) ($cfg['other_default_theme'] ?? 'auto');
}
if ($defaultTheme === 'light-active')    { $defaultTheme = 'light'; }
elseif ($defaultTheme === 'dark-active') { $defaultTheme = 'dark'; }
if (!in_array($defaultTheme, ['auto', 'light', 'dark'], true)) { $defaultTheme = 'auto'; }
$cookieChoice = $app->input->cookie->get('ja_essence-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') { $cookieChoice = ''; }
if ($darkEnabled && $cookieChoice !== '')                      { $resolved = $cookieChoice; }
elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') { $resolved = $defaultTheme; }
else                                                           { $resolved = ''; }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
  <?php if ($resolved !== '') : ?>
  <script>(function(){var t=<?php echo json_encode($resolved); ?>;document.documentElement.setAttribute('data-theme',t);})();</script>
  <?php else : ?>
  <script>(function(){try{var m=document.cookie.match(/(?:^|;\s*)ja_essence-theme=(dark|light)\b/);var t=m?m[1]:'';if(t!=='dark'&&t!=='light')t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';document.documentElement.setAttribute('data-theme',t==='dark'?'dark':'light');}catch(e){}})();</script>
  <?php endif; ?>
  <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/jpages.css" type="text/css" />
  <?php if (($darkEnabled || $defaultTheme === 'dark' || $defaultTheme === 'auto') && is_file(JPATH_THEMES . '/' . $this->template . '/css/darkmode.css')) : ?>
  <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/darkmode.css" type="text/css" />
  <?php endif; ?>
  <jdoc:include type="head" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;600&family=Noto+Serif:wght@400;500&display=swap" rel="stylesheet">

  <?php if ($this->direction == 'rtl') : ?>
    <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/system/css/offline_rtl.css" type="text/css" />
  <?php endif; ?>
</head>

<body class="offline">

  <div id="frame" class="outline">
    <jdoc:include type="message" />

    <div class="form-wrap">
      <div class="offline-header">
        <?php if ($app->get('offline_image')) : ?>
          <div class="offline-image">
            <?php echo HTMLHelper::_('image', $app->get('offline_image'), $app->get('sitename'), [], false, 0); ?>
          </div>
        <?php endif; ?>
      </div>

      <form action="<?php echo Route::_('index.php', true); ?>" method="post" id="form-login">
        <fieldset class="input">
          <!-- Site name -->
          <h1><?php echo htmlspecialchars($app->get('sitename')); ?></h1>

          <!-- Offline message -->
          <?php if ($app->get('display_offline_message', 1) == 1 && str_replace(' ', '', $app->get('offline_message')) != '') : ?>
            <p class="offline-message"><?php echo $app->get('offline_message'); ?></p>
          <?php elseif ($app->get('display_offline_message', 1) == 2 && str_replace(' ', '', Text::_('JOFFLINE_MESSAGE')) != '') : ?>
            <p class="offline-message"><?php echo Text::_('JOFFLINE_MESSAGE'); ?></p>
          <?php endif; ?>
          <!-- // Offline message -->

          <!-- UserName -->
          <p id="form-login-username">
            <label><?php echo Text::_('TPL_YOUR_USERNAME'); ?></label>
            <input name="username" id="username" type="text" class="inputbox" placeholder="Username" alt="<?php echo Text::_('JGLOBAL_USERNAME'); ?>" size="18" />
          </p>
          <!-- // UserName -->

          <!-- PassWord -->
          <p id="form-login-password">
            <label><?php echo Text::_('TPL_YOUR_PASSWORD'); ?></label>
            <input type="password" name="password" class="inputbox" size="18" placeholder="Password" alt="<?php echo Text::_('JGLOBAL_PASSWORD'); ?>" id="passwd" />
          </p>
          <!-- // PassWord -->

          <?php if (count($twofactormethods) > 1) : ?>
            <p id="form-login-secretkey">
              <label for="secretkey"><?php echo Text::_('JGLOBAL_SECRETKEY'); ?></label>
              <input type="text" name="secretkey" class="inputbox" size="18" alt="<?php echo Text::_('JGLOBAL_SECRETKEY'); ?>" id="secretkey" />
            </p>
          <?php endif; ?>
          <p id="submit-buton">
            <input type="submit" name="Submit" class="button login" value="<?php echo Text::_('JLOGIN'); ?>" />
          </p>
          <input type="hidden" name="option" value="com_users" />
          <input type="hidden" name="task" value="user.login" />
          <input type="hidden" name="return" value="<?php echo base64_encode(Uri::base()); ?>" />
          <?php echo HTMLHelper::_('form.token'); ?>
        </fieldset>
      </form>
    </div>
  </div>

  <?php if ($darkEnabled || $defaultTheme === 'auto') : ?>
  <script>window.jaEssenceTheme={def:<?php echo json_encode($defaultTheme); ?>,enabled:<?php echo $darkEnabled ? 'true' : 'false'; ?>};</script>
  <script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/darkmode.js" defer></script>
  <?php endif; ?>
</body>

</html>