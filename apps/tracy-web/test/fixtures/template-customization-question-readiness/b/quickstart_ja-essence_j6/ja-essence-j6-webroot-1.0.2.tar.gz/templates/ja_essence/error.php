<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.t4_blank
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;

$app             = Factory::getApplication();
$doc             = Factory::getDocument();
$user            = Factory::getUser();
$this->language  = $doc->language;
$this->direction = $doc->direction;

/* ---- Dark-mode resolution — honor the GUI lock/default like index.php (local-first).
 * This standalone page does NOT run through T4::render(), so site-settings isn't a
 * usable Registry here — resolve the "site" profile from disk (local/etc/site →
 * etc/site). A cookie+OS-only pre-paint would flip a locked-light 404 to dark on a
 * dark OS (DARK-STANDALONE-LOCK-DESYNC) and load a dead toggle/js on a locked page. */
$darkEnabled  = true;
$defaultTheme = 'auto';
$siteProfile  = ($doc->params ?? null) ? $doc->params->get('typelist-site', 'default') : 'default';
$profileFile  = __DIR__ . '/local/etc/site/' . basename((string) $siteProfile) . '.json';
if (!is_file($profileFile)) {
    $profileFile = __DIR__ . '/etc/site/' . basename((string) $siteProfile) . '.json';
}
if (is_file($profileFile)) {
    $cfg          = json_decode((string) file_get_contents($profileFile), true) ?: [];
    $darkEnabled  = !isset($cfg['other_darkmode']) || filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN);
    $defaultTheme = (string) ($cfg['other_default_theme'] ?? 'auto');
}
if ($defaultTheme === 'light-active')    { $defaultTheme = 'light'; }
elseif ($defaultTheme === 'dark-active') { $defaultTheme = 'dark'; }
if (!in_array($defaultTheme, ['auto', 'light', 'dark'], true)) { $defaultTheme = 'auto'; }
$cookieChoice = $app->input->cookie->get('ja_essence-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') { $cookieChoice = ''; }
if ($darkEnabled && $cookieChoice !== '')                      { $resolved = $cookieChoice; }
elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') { $resolved = $defaultTheme; }
else                                                           { $resolved = ''; }

// Getting params from template
$params = $app->getTemplate(true)->params;

// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = $app->get('sitename');

if ($task == "edit" || $layout == "form") {
  $fullWidth = 1;
} else {
  $fullWidth = 0;
}

// Add JavaScript Frameworks
HTMLHelper::_('bootstrap.framework');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title><?php echo $this->title; ?> <?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Dark mode pre-paint (standalone document) — honors GUI lock/default -->
  <?php if ($resolved !== '') : ?>
  <script>(function(){var t=<?php echo json_encode($resolved); ?>;document.documentElement.setAttribute('data-theme',t);})();</script>
  <?php else : ?>
  <script>(function(){try{var m=document.cookie.match(/(?:^|;\s*)ja_essence-theme=(dark|light)\b/);var t=m?m[1]:'';if(t!=='dark'&&t!=='light')t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';document.documentElement.setAttribute('data-theme',t==='dark'?'dark':'light');}catch(e){}})();</script>
  <?php endif; ?>

  <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/jpages.css" type="text/css" />
  <?php if (($darkEnabled || $defaultTheme === 'dark' || $defaultTheme === 'auto') && is_file(JPATH_THEMES . '/' . $this->template . '/css/darkmode.css')) : ?>
  <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/darkmode.css" type="text/css" />
  <?php endif; ?>

  <!-- Load Google font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;600&family=Noto+Serif:wght@400;500&display=swap" rel="stylesheet">

  <!-- Load Font Awesome -->

  <link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />

</head>

<body class="error-page site <?php echo $option
                                . ' view-' . $view
                                . ($layout ? ' layout-' . $layout : ' no-layout')
                                . ($task ? ' task-' . $task : ' no-task')
                                . ($itemid ? ' itemid-' . $itemid : '')
                                . ($params->get('fluidContainer') ? ' fluid' : '');
                              ?>">

  <!-- Body -->
  <div class="error-page-wrap">
    <div class="error-info">
      <span class="error-code">
        <?php echo $this->error->getCode(); ?>
      </span>
      <div class="error-msg">
        <h2><?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></h2>
        <?php if (Factory::getConfig()->get('devmode')) : ?>
          <p class="alert alert-error"><code><?php echo $this->error->getFile() ?> (<?php echo $this->error->getLine() ?>)</code></p>
        <?php endif ?>
      </div>
    </div>

    <div class="error-other-info">

      <p><strong><?php echo Text::_('JERROR_LAYOUT_ERROR_HAS_OCCURRED_WHILE_PROCESSING_YOUR_REQUEST'); ?></strong></p>
      <div class="page-redirect">
        <a href="<?php echo $this->baseurl; ?>/index.php" title="<?php echo Text::_('JERROR_LAYOUT_HOME_PAGE'); ?>"><?php echo Text::_('JERROR_LAYOUT_HOME_PAGE'); ?></a>
      </div>

    </div>
  </div>

  <?php echo $doc->getBuffer('modules', 'debug', array('style' => 'none')); ?>

  <?php if ($darkEnabled || $defaultTheme === 'auto') : ?>
  <script>window.jaEssenceTheme={def:<?php echo json_encode($defaultTheme); ?>,enabled:<?php echo $darkEnabled ? 'true' : 'false'; ?>};</script>
  <script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/darkmode.js" defer></script>
  <?php endif; ?>
</body>

</html>