<?php
/**
 * @package   T4_BLANK
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

/* -----------------------------------------------------------------------------
 * Dark mode wiring — GUI-configurable (cookie + server-resolve) variant.
 *   - Dark CSS lives in its OWN file css/darkmode.css (NOT custom.css), hook
 *     html[data-theme="dark"]. CSS architecture is unchanged.
 *   - Two GUI settings (Template > Settings > Other): other_darkmode (on/off)
 *     and other_default_theme (auto/light/dark).
 *   - Persistence is a COOKIE ('ja_essence-theme'), readable by PHP, so the
 *     initial theme is resolved HERE on the server and emitted before paint
 *     (no FOUC). Resolution order: cookie > explicit default > auto (OS).
 *   - NOTE: this template themes itself entirely off data-theme (darkmode.css
 *     remaps the Bootstrap/T4 color tokens). template.css ships a SEPARATE native
 *     [data-bs-theme=dark] layer, so we deliberately do NOT also emit
 *     data-bs-theme here — that would double-activate and fight the tuned look.
 * --------------------------------------------------------------------------- */

/* Resolve other_darkmode / other_default_theme from the active "site" profile
 * JSON on disk, LOCAL-FIRST (local/etc/site/<profile>.json → base etc/site/),
 * exactly like T4\Helper\Path::findInTheme. The admin GUI SAVES edits to local/,
 * so reading only base etc/ — or the site-settings Registry — ignores every
 * admin change. CRITICAL: at template-root index.php time T4 has NOT built the
 * site-settings Registry yet; $this->params->get('site-settings') is a partial
 * stdClass (only site_logo, no ->get()) and calling ->get() FATALS (500). So we
 * resolve from disk and only touch site-settings when it is a real Registry. */
$darkEnabled  = true;
$defaultTheme = 'auto';
$siteProfile  = $this->params->get('typelist-site', 'default');

$profileFile  = __DIR__ . '/local/etc/site/' . basename((string) $siteProfile) . '.json';
if (!is_file($profileFile)) {
	$profileFile = __DIR__ . '/etc/site/' . basename((string) $siteProfile) . '.json';
}
if (is_file($profileFile)) {
	$cfg          = json_decode((string) file_get_contents($profileFile), true) ?: [];
	$darkEnabled  = !isset($cfg['other_darkmode'])
		|| filter_var($cfg['other_darkmode'], FILTER_VALIDATE_BOOLEAN); // handles JSON bool false AND "0"/"1"
	$defaultTheme = (string) ($cfg['other_default_theme'] ?? 'auto');
} else {
	// Last resort only (no profile JSON on disk). site-settings is a stub stdClass
	// here — guard for a real Registry or the ->get() would fatal.
	$siteSettings = $this->params->get('site-settings');
	if ($siteSettings instanceof \Joomla\Registry\Registry) {
		$darkEnabled  = filter_var($siteSettings->get('other_darkmode', '1'), FILTER_VALIDATE_BOOLEAN);
		$defaultTheme = (string) $siteSettings->get('other_default_theme', 'auto');
	}
}

// normalize legacy values (light-active/dark-active) → auto|light|dark
if ($defaultTheme === 'light-active')      { $defaultTheme = 'light'; }
elseif ($defaultTheme === 'dark-active')   { $defaultTheme = 'dark'; }
if (!in_array($defaultTheme, ['auto', 'light', 'dark'], true)) { $defaultTheme = 'auto'; }

$cookieChoice = Factory::getApplication()->input->cookie->get('ja_essence-theme', '');
if ($cookieChoice !== 'dark' && $cookieChoice !== 'light') {
	$cookieChoice = '';
}

/* First-paint theme.
 *  - Switch ON  : visitor's cookie choice → GUI default → OS (auto).
 *  - Switch OFF : LOCKED to the GUI default (cookie ignored, no toggle). NEVER
 *    force light when disabled — that throws away the owner's Default choice, so
 *    "off + Default Dark" = a dark-only site. */
if ($darkEnabled && $cookieChoice !== '')                      { $resolved = $cookieChoice; }
elseif ($defaultTheme === 'light' || $defaultTheme === 'dark') { $resolved = $defaultTheme; }
else                                                           { $resolved = ''; } // auto → OS at first paint

// NOTE: ja_essence themes entirely off the data-theme hook (darkmode.css remaps
// the BS/T4 tokens). template.css ships a SEPARATE native [data-bs-theme=dark]
// layer, so we deliberately do NOT also emit data-bs-theme / .t4-dark here —
// that would double-activate and fight the tuned look. data-theme is the sole hook.
if ($resolved !== '') {
	$this->addScriptDeclaration(
		'(function(){var t=' . json_encode($resolved) . ';'
		. "document.documentElement.setAttribute('data-theme',t);})();"
	);
} else {
	$this->addScriptDeclaration(
		"(function(){try{var d=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;"
		. "document.documentElement.setAttribute('data-theme',d?'dark':'light');}"
		. "catch(e){document.documentElement.setAttribute('data-theme','light');}})();"
	);
}

// expose default + enabled to darkmode.js (OS-follow / no-clobber gating)
$this->addScriptDeclaration('window.jaEssenceTheme={def:' . json_encode($defaultTheme) . ',enabled:' . ($darkEnabled ? 'true' : 'false') . '};');

// darkmode.css whenever the page CAN render dark (switch on, or default resolves
// dark/auto). LAST in <head> via addCustomTag → after the template.css optimize
// bundle (equal-specificity ties go to dark). registerAndUseStyle is intentionally
// NOT used — it can load before the bundle.
if ($darkEnabled || $defaultTheme === 'dark' || $defaultTheme === 'auto') {
	$darkCss = __DIR__ . '/css/darkmode.css';
	if (is_file($darkCss)) {
		$href = Uri::root(true) . '/templates/' . $this->template . '/css/darkmode.css?' . filemtime($darkCss);
		$this->addCustomTag('<link rel="stylesheet" type="text/css" href="' . $href . '">');
	}
}

// darkmode.js only for live switching (toggle on) or OS-follow (default=auto). The
// button itself is STATIC markup in the gated theme-toggle.php element.
if ($darkEnabled || $defaultTheme === 'auto') {
	$darkJs = __DIR__ . '/js/darkmode.js';
	if (is_file($darkJs)) {
		$this->getWebAssetManager()->registerAndUseScript(
			'tpl.ja_essence.darkmode',
			'templates/' . $this->template . '/js/darkmode.js?' . filemtime($darkJs),
			[],
			['defer' => true]
		);
	}
}

if (class_exists('\T4\T4')) {
	\T4\T4::render($this);
} else {
	include 'error-t4.php';
}
