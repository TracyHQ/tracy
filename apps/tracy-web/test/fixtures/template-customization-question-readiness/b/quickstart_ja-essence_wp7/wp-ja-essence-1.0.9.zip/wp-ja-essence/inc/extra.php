<?php
// Cut for the tests: only the title functions and their hooks.
function wp_ja_essence_title_parts( array $parts ): array {
	unset( $parts['tagline'] );
	if ( is_page() && ! is_front_page() ) {
		$parts['title'] = wp_ja_essence_display_title( get_queried_object_id() );
	}
	return $parts;
}
function wp_ja_essence_title_fixed( $title ) {
	if ( is_front_page() ) {
		return esc_html( get_bloginfo( 'name' ) );
	}
	if ( is_404() ) {
		return esc_html( 'Page not found ' . apply_filters( 'document_title_separator', '–' ) . ' ' . get_bloginfo( 'name' ) );
	}
	return $title;
}
function wp_ja_essence_display_title( $post ): string {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}
	if ( 'page' === $post->post_type ) {
		$heading = trim( (string) get_post_meta( $post->ID, 'tracy_page_heading', true ) );
		if ( '' !== $heading ) {
			return $heading;
		}
	}
	return get_the_title( $post );
}
add_filter( 'document_title_parts', 'wp_ja_essence_title_parts' );
add_filter( 'pre_get_document_title', 'wp_ja_essence_title_fixed' );
