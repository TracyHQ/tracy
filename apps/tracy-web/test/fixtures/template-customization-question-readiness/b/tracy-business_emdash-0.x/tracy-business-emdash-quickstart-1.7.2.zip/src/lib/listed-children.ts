/**
 * Which children of an unticked list page a page the customer KEPT still lists (TCH #1013, decided 08/10/2026): a
 * child stays reachable while a kept page lists it, and answers 404 only when none does. In this theme the one page
 * that lists another page's children is Investors: its Disclosures column lists the newest news posts of category
 * `disclosures`, so with News unticked those posts keep answering 200. The home blocks of Projects and News go with
 * their page (a home block whose only job is to show a page, Akemi 08/10), so they list nothing then. Pure, so node
 * tests run it on the seed; `link-gate.ts` feeds it the records and posts.
 */

/** The news category the Investors page lists, and how many of its newest posts. */
export const DISCLOSURES = 'disclosures'
const DISCLOSURES_SHOWN = 4

/** The posts the Investors page lists: the newest of category `disclosures` (posts arrive newest first). */
export function investorDisclosures<T extends { category?: { slug: string } }>(posts: readonly T[]): T[] {
  return posts.filter((p) => p.category?.slug === DISCLOSURES).slice(0, DISCLOSURES_SHOWN)
}

/** The child paths (`/news/<slug>`) the kept pages list; `kept.investors` is whether the Investors page is published. */
export function listedChildren(
  kept: { investors: boolean },
  posts: readonly { slug: string; category?: { slug: string } }[]
): Set<string> {
  return new Set(kept.investors ? investorDisclosures(posts).map((p) => `/news/${p.slug}`) : [])
}
