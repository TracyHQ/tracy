// Cut for the tests: the default the trim rules fall back to.
const LEADS_TO = '/contact'
