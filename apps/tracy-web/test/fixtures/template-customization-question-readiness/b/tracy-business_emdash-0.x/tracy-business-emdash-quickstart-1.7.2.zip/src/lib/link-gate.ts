/**
 * The link gate of this theme (TCH #1013): which page record each top-level path is served by (the same
 * records `src/pages/[...path].astro` routes to and each list view answers 404 on), wired to EmDash.
 * A view calls `await liveLinks(Astro.request, locale, [urls…])` and draws a link only while `live(url)`.
 * The pure half is `page-records.ts`. A child of an unticked page stays live while a page the customer kept still
 * lists it (Investors' disclosures under an unticked News): `listed-children.ts`.
 */
import { getEmDashEntry } from 'emdash'
import { LOCALES, type Locale } from './i18n'
import { linkChecker, type RecordTable } from './page-records'
import { listedChildren } from './listed-children'
import { loadPosts } from './posts'

/** Top-level path → its page record; `/projects/<slug>` and `/news/category/<c>` go with their list page. */
const RECORDS: RecordTable = {
  about: { collection: 'about', slug: 'about' },
  services: { collection: 'services_page', slug: 'services' },
  projects: { collection: 'projects_page', slug: 'projects' },
  news: { collection: 'news_page', slug: 'news' },
  careers: { collection: 'careers', slug: 'careers' },
  investors: { collection: 'investors', slug: 'investors' },
  contact: { collection: 'contact', slug: 'contact' }
}

/** The children the kept pages still list, in one locale. */
async function listed(locale: string): Promise<Set<string>> {
  const [{ entry: investors }, posts] = await Promise.all([
    getEmDashEntry('investors', 'investors', { locale }),
    loadPosts(locale as Locale)
  ])
  return listedChildren({ investors: Boolean(investors) }, posts)
}

/** One checker per request and locale, so each record is read once however many components ask. */
const perRequest = new WeakMap<Request, Map<string, ReturnType<typeof linkChecker>>>()

/** Read the page records `urls` land on; returns `live(url)`, false only for a URL whose page is off. */
export function liveLinks(request: Request, locale: string, urls: readonly unknown[]) {
  let byLocale = perRequest.get(request)
  if (!byLocale) perRequest.set(request, (byLocale = new Map()))
  let check = byLocale.get(locale)
  if (!check) {
    check = linkChecker(
      async ({ collection, slug }) => Boolean((await getEmDashEntry(collection, slug, { locale })).entry),
      RECORDS,
      LOCALES,
      () => listed(locale)
    )
    byLocale.set(locale, check)
  }
  return check(urls)
}

/** Whether a child page (`/news/<slug>`) is reachable: its list page is published, or a kept page still lists it. */
export async function childLive(request: Request, locale: string, path: string): Promise<boolean> {
  return (await liveLinks(request, locale, [path]))(path)
}
