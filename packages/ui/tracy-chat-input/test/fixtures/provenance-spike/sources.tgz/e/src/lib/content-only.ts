// The content-only guard of a Tracy quickstart site, decided without I/O so a test can pin every
// case. `src/middleware.ts` applies it to every request.
//
// WHY THIS SEAM. A Joomla quickstart is sealed by the Cowork component inside the site: structure
// (menus, schema, extensions) refuses to change, only the declared text slots do. EmDash has no
// such component, and its plugin hooks carry no actor (`ContentHookEvent` is `{content, collection,
// isNew, id}`), so a hook cannot tell the agent from a person editing in the admin. What CAN be
// told apart is HOW a caller authenticated: EmDash's own auth middleware (order `pre`, so it runs
// before this template's) sets `locals.tokenScopes` for an API token and leaves it undefined for a
// browser session. Every automated road into a Tracy site is a token: the agent's `tracy_emdash`
// MCP calls, and the template's own `tools/personalize.mjs`. A person in the admin is a session.
//
// The two token callers differ in the door they use: personalize speaks REST (`/_emdash/api/
// content|settings|menus|…`), the agent speaks MCP (`/_emdash/api/mcp`, `tools/call`). So the
// guard refuses STRUCTURAL MCP tools for token callers and leaves REST alone — a build still
// unpublishes hidden languages and deletes a menu item over REST, while `schema_update_field`
// from the chat is refused with the same `content_only` code the Joomla receiver answers.
//
// 🔒 DEFENCE IN DEPTH, NOT THE FENCE. The first fence is the lane's allowlist on `tracy_emdash`
// (TCH `packages/tools/tracy-site-tools/src/host/emdash.mjs`); this guard is what stands if another
// token road appears. It does NOT stop the site's owner: an owner edits the admin with a session,
// and may set `TRACY_CONTENT_ONLY=off` in the site's environment to switch the guard off.

/**
 * MCP tools (0.38) a token caller may use on a content-only site: every read, and the writes that
 * change words and pictures — never schema, menus, settings, taxonomies, bylines, and nothing
 * deleted. An ALLOWLIST: a tool EmDash adds upstream is refused until someone decides it is
 * content. The lane holds the same list (`sealedToolAllowed`, tracy-site-tools `emdash.mjs`,
 * layer 1); this copy is the template's own, because the template ships alone.
 */
const READS = new Set([
  'content_list',
  'content_get',
  'content_compare',
  'content_translations',
  'content_list_trashed',
  'revision_list',
  'media_list',
  'media_get',
  'menu_list',
  'menu_get',
  'menu_translations',
  'taxonomy_list',
  'taxonomy_get',
  'taxonomy_list_terms',
  'taxonomy_term_translations',
  'schema_list_collections',
  'schema_get_collection',
  'settings_get',
  'byline_list',
  'byline_get',
  'byline_translations'
])
const WRITES = new Set([
  'content_update',
  'content_create',
  'content_duplicate',
  'content_publish',
  'content_unpublish',
  'content_schedule',
  'content_unschedule',
  'content_discard_draft',
  'content_restore',
  'revision_restore',
  'media_upload',
  'media_create',
  'media_update',
  'taxonomy_update_term'
])

/** Whether an MCP tool is refused on a content-only site: anything outside the list above. */
export function structuralTool(name: string): boolean {
  return !READS.has(name) && !WRITES.has(name)
}

/** What the guard sees of a request: the parts a decision needs, nothing from the network. */
export interface GuardInput {
  pathname: string
  method: string
  /** `locals.tokenScopes`: set for an API token, undefined for a session. */
  tokenScopes: string[] | undefined
  /** The JSON-RPC body of a `/_emdash/api/mcp` POST, when the request is one. */
  mcpBody?: unknown
  /** `TRACY_CONTENT_ONLY` from the environment; anything but `off` keeps the guard on. */
  env?: string | undefined
}

export interface Refusal {
  status: 403
  body: { ok: false; code: 'content_only'; error: string; next: string }
}

const NEXT =
  'This site is content-only: change the words in its entries (content_update) and the pictures ' +
  '(media_upload); structure — schema, menus, settings, plugins, users, tokens, deleting entries — ' +
  'is locked on purpose. To see what Tracy wrote and undo it, use tracy_site_build_emdash request ' +
  'site.inspect / site.revert. For anything structural, tell the customer the site is sealed and ' +
  'what would have to change.'

/** The MCP tool a JSON-RPC body calls, or null when the body is not a `tools/call`. */
export function mcpToolOf(body: unknown): string | null {
  if (!body || typeof body !== 'object') return null
  const b = body as { method?: unknown; params?: { name?: unknown } }
  if (b.method !== 'tools/call') return null
  return typeof b.params?.name === 'string' ? b.params.name : null
}

/**
 * Refuse, or null to let the request through. Only token-authenticated MCP `tools/call` of a
 * structural tool is refused; everything else — sessions, REST, reads, content tools — passes.
 */
export function contentOnlyRefusal(input: GuardInput): Refusal | null {
  if ((input.env ?? '').trim().toLowerCase() === 'off') return null
  if (input.tokenScopes === undefined) return null
  if (input.method !== 'POST' || input.pathname !== '/_emdash/api/mcp') return null
  const tool = mcpToolOf(input.mcpBody)
  if (tool === null || !structuralTool(tool)) return null
  return {
    status: 403,
    body: {
      ok: false,
      code: 'content_only',
      error: `${tool} is refused: this site is content-only`,
      next: NEXT
    }
  }
}
