/**
 * The few words the THEME says itself, per locale. Everything else a visitor reads is content —
 * the `site/site/<locale>` entry carries the topbar, header, footer, search and 404 labels — so
 * this stays small on purpose: a language's own name, the date shape, the reading-time label,
 * and two fallbacks the views use when a chrome field is empty.
 *
 * The list of locales is `template.config.json`; a locale missing here reads as English rather
 * than crashing the page, and adding one is one object below plus its seed.
 */
export interface LocaleWords {
  /** The language's name in itself, for the switcher. */
  name: string
  /** Accessible name of the header's mobile menu button. */
  menu: string
  /** Placeholder of the language dialog's filter box (shown from 9 languages up). */
  languageFilter: string
  /** Shown in the language dialog when the filter matches nothing. */
  noLanguageMatch: string
  pages: string
  all: string
  minRead: (minutes: number) => string
  date: (day: number, month: number, year: number) => string
}

const MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const two = (n: number): string => String(n).padStart(2, '0')

/**
 * The date shape of a locale this file does not spell out by hand: ICU already knows how each
 * language writes `12 Aug 2026`, and asking it is the only answer that stays right as locales are
 * added. The calendar is named on purpose — Thai defaults to the Buddhist era, and a news item
 * dated 2569 is a bug no one would look for.
 */
function intlDate(locale: string): (day: number, month: number, year: number) => string {
  const fmt = new Intl.DateTimeFormat(`${locale}-u-ca-gregory`, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC'
  })
  return (day, month, year) => fmt.format(Date.UTC(year, month, day))
}

export const WORDS: Record<string, LocaleWords> = {
  en: {
    name: 'English',
    menu: 'Menu',
    languageFilter: 'Filter languages',
    noLanguageMatch: 'No matching results',
    pages: 'Pages',
    all: 'All',
    minRead: (m) => `${m} min read`,
    date: (day, month, year) => `${day} ${MONTHS_EN[month]} ${year}`
  },
  ru: {
    name: 'Русский',
    menu: 'Меню',
    languageFilter: 'Фильтр языков',
    noLanguageMatch: 'Совпадений не найдено',
    pages: 'Страницы',
    all: 'Все',
    minRead: (m) => `${m} мин чтения`,
    date: (day, month, year) => `${two(day)}.${two(month + 1)}.${year}`
  },
  vi: {
    name: 'Tiếng Việt',
    menu: 'Menu',
    languageFilter: 'Lọc ngôn ngữ',
    noLanguageMatch: 'Không có kết quả phù hợp',
    pages: 'Trang',
    all: 'Tất cả',
    minRead: (m) => `${m} phút đọc`,
    date: (day, month, year) => `${two(day)}/${two(month + 1)}/${year}`
  },
  zh: {
    name: '中文',
    menu: '菜单',
    languageFilter: '筛选语言',
    noLanguageMatch: '没有匹配的结果',
    pages: '页面',
    all: '全部',
    minRead: (m) => `${m} 分钟阅读`,
    date: (day, month, year) => `${year}年${month + 1}月${day}日`
  },
  // ── The 36 locales added with the 1.2.0 seed ────────────────────────────────────────────────
  // Their own names and date shapes come from ICU; the six interface words were translated with
  // the seed and are edited here, not guessed at render time. Adding a locale is one object here,
  // its tag in template.config.json, and its rows in seed/seed.json — nothing else.
  af: {
    name: 'Afrikaans',
    menu: 'Kieslys',
    languageFilter: 'Filter tale',
    noLanguageMatch: 'Geen passende resultate nie',
    pages: 'Bladsye',
    all: 'Alle',
    minRead: (m) => '{n} min leestyd'.replace('{n}', String(m)),
    date: intlDate('af')
  },
  be: {
    name: 'Беларуская',
    menu: 'Меню',
    languageFilter: 'Фільтр моў',
    noLanguageMatch: 'Няма супадзенняў',
    pages: 'Старонкі',
    all: 'Усе',
    minRead: (m) => '{n} хв чытання'.replace('{n}', String(m)),
    date: intlDate('be')
  },
  bg: {
    name: 'Български',
    menu: 'Меню',
    languageFilter: 'Филтриране на езици',
    noLanguageMatch: 'Няма съвпадащи резултати',
    pages: 'Страници',
    all: 'Всички',
    minRead: (m) => '{n} мин. четене'.replace('{n}', String(m)),
    date: intlDate('bg')
  },
  ca: {
    name: 'Català',
    menu: 'Menú',
    languageFilter: 'Filtra llengües',
    noLanguageMatch: 'Sense resultats',
    pages: 'Pàgines',
    all: 'Totes',
    minRead: (m) => '{n} min de lectura'.replace('{n}', String(m)),
    date: intlDate('ca')
  },
  cs: {
    name: 'Čeština',
    menu: 'Menu',
    languageFilter: 'Filtrovat jazyky',
    noLanguageMatch: 'Žádné odpovídající výsledky',
    pages: 'Stránky',
    all: 'Vše',
    minRead: (m) => '{n} min čtení'.replace('{n}', String(m)),
    date: intlDate('cs')
  },
  cy: {
    name: 'Cymraeg',
    menu: 'Dewislen',
    languageFilter: 'Hidlo ieithoedd',
    noLanguageMatch: 'Dim canlyniadau cyfatebol',
    pages: 'Tudalennau',
    all: 'Pob un',
    minRead: (m) => '{n} munud o ddarllen'.replace('{n}', String(m)),
    date: intlDate('cy')
  },
  da: {
    name: 'Dansk',
    menu: 'Menu',
    languageFilter: 'Filtrer sprog',
    noLanguageMatch: 'Ingen matchende resultater',
    pages: 'Sider',
    all: 'Alle',
    minRead: (m) => '{n} min læsning'.replace('{n}', String(m)),
    date: intlDate('da')
  },
  de: {
    name: 'Deutsch',
    menu: 'Menü',
    languageFilter: 'Sprachen filtern',
    noLanguageMatch: 'Keine passenden Ergebnisse',
    pages: 'Seiten',
    all: 'Alle',
    minRead: (m) => '{n} Min. Lesezeit'.replace('{n}', String(m)),
    date: intlDate('de')
  },
  el: {
    name: 'Ελληνικά',
    menu: 'Μενού',
    languageFilter: 'Φιλτράρισμα γλωσσών',
    noLanguageMatch: 'Δεν βρέθηκαν αποτελέσματα',
    pages: 'Σελίδες',
    all: 'Όλα',
    minRead: (m) => '{n} λεπτά ανάγνωση'.replace('{n}', String(m)),
    date: intlDate('el')
  },
  es: {
    name: 'Español',
    menu: 'Menú',
    languageFilter: 'Filtrar idiomas',
    noLanguageMatch: 'No hay resultados coincidentes',
    pages: 'Páginas',
    all: 'Todos',
    minRead: (m) => '{n} min de lectura'.replace('{n}', String(m)),
    date: intlDate('es')
  },
  et: {
    name: 'Eesti',
    menu: 'Menüü',
    languageFilter: 'Filtreeri keeli',
    noLanguageMatch: 'Vasteid ei leitud',
    pages: 'Lehed',
    all: 'Kõik',
    minRead: (m) => '{n} min lugemist'.replace('{n}', String(m)),
    date: intlDate('et')
  },
  fi: {
    name: 'Suomi',
    menu: 'Valikko',
    languageFilter: 'Suodata kieliä',
    noLanguageMatch: 'Ei vastaavia tuloksia',
    pages: 'Sivut',
    all: 'Kaikki',
    minRead: (m) => '{n} min lukuaika'.replace('{n}', String(m)),
    date: intlDate('fi')
  },
  fr: {
    name: 'Français',
    menu: 'Menu',
    languageFilter: 'Filtrer les langues',
    noLanguageMatch: 'Aucun résultat',
    pages: 'Pages',
    all: 'Tous',
    minRead: (m) => '{n} min de lecture'.replace('{n}', String(m)),
    date: intlDate('fr')
  },
  ga: {
    name: 'Gaeilge',
    menu: 'Roghchlár',
    languageFilter: 'Scag teangacha',
    noLanguageMatch: 'Níl aon torthaí comhoiriúnacha',
    pages: 'Leathanaigh',
    all: 'Uile',
    minRead: (m) => '{n} nóiméad léitheoireachta'.replace('{n}', String(m)),
    date: intlDate('ga')
  },
  hr: {
    name: 'Hrvatski',
    menu: 'Izbornik',
    languageFilter: 'Filtriraj jezike',
    noLanguageMatch: 'Nema odgovarajućih rezultata',
    pages: 'Stranice',
    all: 'Sve',
    minRead: (m) => '{n} min čitanja'.replace('{n}', String(m)),
    date: intlDate('hr')
  },
  hu: {
    name: 'Magyar',
    menu: 'Menü',
    languageFilter: 'Nyelvek szűrése',
    noLanguageMatch: 'Nincs találat',
    pages: 'Oldalak',
    all: 'Összes',
    minRead: (m) => '{n} perc olvasás'.replace('{n}', String(m)),
    date: intlDate('hu')
  },
  it: {
    name: 'Italiano',
    menu: 'Menu',
    languageFilter: 'Filtra lingue',
    noLanguageMatch: 'Nessun risultato corrispondente',
    pages: 'Pagine',
    all: 'Tutti',
    minRead: (m) => '{n} min di lettura'.replace('{n}', String(m)),
    date: intlDate('it')
  },
  ja: {
    name: '日本語',
    menu: 'メニュー',
    languageFilter: '言語を絞り込む',
    noLanguageMatch: '一致する結果がありません',
    pages: 'ページ',
    all: 'すべて',
    minRead: (m) => '{n}分で読めます'.replace('{n}', String(m)),
    date: intlDate('ja')
  },
  ka: {
    name: 'ქართული',
    menu: 'მენიუ',
    languageFilter: 'ენების გაფილტვრა',
    noLanguageMatch: 'შედეგები ვერ მოიძებნა',
    pages: 'გვერდები',
    all: 'ყველა',
    minRead: (m) => '{n} წთ კითხვა'.replace('{n}', String(m)),
    date: intlDate('ka')
  },
  lo: {
    name: 'ລາວ',
    menu: 'ເມນູ',
    languageFilter: 'ກັ່ນຕອງພາສາ',
    noLanguageMatch: 'ບໍ່ພົບຜົນລັບທີ່ກົງກັນ',
    pages: 'ໜ້າ',
    all: 'ທັງໝົດ',
    minRead: (m) => 'ອ່ານ {n} ນາທີ'.replace('{n}', String(m)),
    date: intlDate('lo')
  },
  lt: {
    name: 'Lietuvių',
    menu: 'Meniu',
    languageFilter: 'Filtruoti kalbas',
    noLanguageMatch: 'Atitikmenų nerasta',
    pages: 'Puslapiai',
    all: 'Visi',
    minRead: (m) => '{n} min. skaitymo'.replace('{n}', String(m)),
    date: intlDate('lt')
  },
  lv: {
    name: 'Latviešu',
    menu: 'Izvēlne',
    languageFilter: 'Filtrēt valodas',
    noLanguageMatch: 'Nav atbilstošu rezultātu',
    pages: 'Lapas',
    all: 'Visi',
    minRead: (m) => '{n} min lasīšana'.replace('{n}', String(m)),
    date: intlDate('lv')
  },
  ms: {
    name: 'Melayu',
    menu: 'Menu',
    languageFilter: 'Tapis bahasa',
    noLanguageMatch: 'Tiada hasil yang sepadan',
    pages: 'Halaman',
    all: 'Semua',
    minRead: (m) => '{n} min bacaan'.replace('{n}', String(m)),
    date: intlDate('ms')
  },
  nb: {
    name: 'Norsk bokmål',
    menu: 'Meny',
    languageFilter: 'Filtrer språk',
    noLanguageMatch: 'Ingen treff',
    pages: 'Sider',
    all: 'Alle',
    minRead: (m) => '{n} min lesing'.replace('{n}', String(m)),
    date: intlDate('nb')
  },
  nl: {
    name: 'Nederlands',
    menu: 'Menu',
    languageFilter: 'Talen filteren',
    noLanguageMatch: 'Geen overeenkomende resultaten',
    pages: "Pagina's",
    all: 'Alle',
    minRead: (m) => '{n} min leestijd'.replace('{n}', String(m)),
    date: intlDate('nl')
  },
  pl: {
    name: 'Polski',
    menu: 'Menu',
    languageFilter: 'Filtruj języki',
    noLanguageMatch: 'Brak pasujących wyników',
    pages: 'Strony',
    all: 'Wszystkie',
    minRead: (m) => '{n} min czytania'.replace('{n}', String(m)),
    date: intlDate('pl')
  },
  pt: {
    name: 'Português',
    menu: 'Menu',
    languageFilter: 'Filtrar idiomas',
    noLanguageMatch: 'Nenhum resultado correspondente',
    pages: 'Páginas',
    all: 'Todos',
    minRead: (m) => '{n} min de leitura'.replace('{n}', String(m)),
    date: intlDate('pt')
  },
  ro: {
    name: 'Română',
    menu: 'Meniu',
    languageFilter: 'Filtrează limbile',
    noLanguageMatch: 'Niciun rezultat',
    pages: 'Pagini',
    all: 'Toate',
    minRead: (m) => '{n} min de citit'.replace('{n}', String(m)),
    date: intlDate('ro')
  },
  sk: {
    name: 'Slovenčina',
    menu: 'Menu',
    languageFilter: 'Filtrovať jazyky',
    noLanguageMatch: 'Žiadne zodpovedajúce výsledky',
    pages: 'Stránky',
    all: 'Všetko',
    minRead: (m) => '{n} min čítania'.replace('{n}', String(m)),
    date: intlDate('sk')
  },
  sl: {
    name: 'Slovenščina',
    menu: 'Meni',
    languageFilter: 'Filtriraj jezike',
    noLanguageMatch: 'Ni zadetkov',
    pages: 'Strani',
    all: 'Vse',
    minRead: (m) => '{n} min branja'.replace('{n}', String(m)),
    date: intlDate('sl')
  },
  sr: {
    name: 'Српски',
    menu: 'Мени',
    languageFilter: 'Филтрирај језике',
    noLanguageMatch: 'Нема резултата',
    pages: 'Странице',
    all: 'Све',
    minRead: (m) => '{n} мин читања'.replace('{n}', String(m)),
    date: intlDate('sr')
  },
  sv: {
    name: 'Svenska',
    menu: 'Meny',
    languageFilter: 'Filtrera språk',
    noLanguageMatch: 'Inga matchande resultat',
    pages: 'Sidor',
    all: 'Alla',
    minRead: (m) => '{n} min läsning'.replace('{n}', String(m)),
    date: intlDate('sv')
  },
  ta: {
    name: 'தமிழ்',
    menu: 'மெனு',
    languageFilter: 'மொழிகளை வடிகட்டு',
    noLanguageMatch: 'பொருந்தும் முடிவுகள் இல்லை',
    pages: 'பக்கங்கள்',
    all: 'அனைத்தும்',
    minRead: (m) => '{n} நிமிட வாசிப்பு'.replace('{n}', String(m)),
    date: intlDate('ta')
  },
  th: {
    name: 'ไทย',
    menu: 'เมนู',
    languageFilter: 'กรองภาษา',
    noLanguageMatch: 'ไม่พบผลลัพธ์ที่ตรงกัน',
    pages: 'หน้า',
    all: 'ทั้งหมด',
    minRead: (m) => 'อ่าน {n} นาที'.replace('{n}', String(m)),
    date: intlDate('th')
  },
  tr: {
    name: 'Türkçe',
    menu: 'Menü',
    languageFilter: 'Dilleri filtrele',
    noLanguageMatch: 'Eşleşen sonuç yok',
    pages: 'Sayfalar',
    all: 'Tümü',
    minRead: (m) => '{n} dk okuma'.replace('{n}', String(m)),
    date: intlDate('tr')
  },
  uk: {
    name: 'Українська',
    menu: 'Меню',
    languageFilter: 'Фільтрувати мови',
    noLanguageMatch: 'Немає відповідних результатів',
    pages: 'Сторінки',
    all: 'Усі',
    minRead: (m) => '{n} хв читання'.replace('{n}', String(m)),
    date: intlDate('uk')
  }
}

export function wordsOf(locale: string): LocaleWords {
  return WORDS[locale] ?? WORDS.en
}
