// The language tag a visitor's browser and a search engine read, when it is not the locale the
// content is stored under.
//
// 🔒 STORED `en`, SHOWN `en-US`. A template ships one English (`en`): its entries, URLs and admin
// locale. A customer who picked "English" in the Build form answered `en-us` (the form's English
// row carries `en-us`, as Joomla's does), and their site should say so in `<html lang>` and in
// hreflang — without a second English in the admin and without moving a single URL. `personalize`
// writes the decision to `<SITE_DATA_DIR>/display-locale.json` (`{ "en": "en-US" }`); this reads it.
// EmDash settings could not hold it: its settings schema strips any key it does not know.
import { readFileSync, statSync } from 'node:fs'
import path from 'node:path'

const TAG = /^[a-z]{2,3}-[A-Z]{2}$/

/**
 * `{ stored → shown }` from what the file holds, keeping only a tag of the stored locale's own
 * language (`en` → `en-US`, never `en` → `vi-VN`). Pure, so a plain `node --test` can hold it.
 */
export function parseDisplayLocales(raw: unknown, locales: readonly string[]): Record<string, string> {
  const out: Record<string, string> = {}
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out
  for (const [stored, shown] of Object.entries(raw as Record<string, unknown>)) {
    if (!locales.includes(stored) || typeof shown !== 'string' || !TAG.test(shown)) continue
    if (shown.split('-')[0] !== stored.split('-')[0].toLowerCase()) continue
    out[stored] = shown
  }
  return out
}

const FILE = path.join(process.env.SITE_DATA_DIR ?? './data', 'display-locale.json')
let cached: { mtimeMs: number; value: Record<string, string> } | null = null

/** What the file says now, re-read only when it changed; a missing or broken file says nothing. */
function displayLocales(locales: readonly string[]): Record<string, string> {
  let mtimeMs: number
  try {
    mtimeMs = statSync(FILE).mtimeMs
  } catch {
    cached = null
    return {}
  }
  if (cached?.mtimeMs === mtimeMs) return cached.value
  let value: Record<string, string> = {}
  try {
    value = parseDisplayLocales(JSON.parse(readFileSync(FILE, 'utf8')), locales)
  } catch {
    value = {}
  }
  cached = { mtimeMs, value }
  return value
}

/** The tag to print for a stored locale: its display tag when one is set, else the locale itself. */
export function displayLocaleOf(locale: string, locales: readonly string[]): string {
  return displayLocales(locales)[locale] ?? locale
}
