<?php
/** Tracy Business — ACM `tb-page-quote-strip`: bordered strip of cells with a small uppercase label ABOVE a Newsreader value (share price · daily change · market cap · free float). Values are whatever the admin typed — no market feed. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$cells = [];
for ($i = 0, $n = (int) $helper->getRows('label'); $i < $n; $i++) { $l = trim((string) $helper->get('label', $i)); $v = trim((string) $helper->get('value', $i)); if ($l !== '' || $v !== '') $cells[] = [$l, $v]; }
if (!$cells) return;
?>
<section class="ja-acm acm-tb-page-quote-strip tb-pg-quote-strip" id="tb-pg-qs-<?php echo (int) $module->id; ?>">
  <div class="tb-container">
    <dl class="tb-pg-quote-strip__grid">
      <?php foreach ($cells as [$l, $v]) : ?><div class="tb-pg-quote-strip__cell"><dt class="tb-pg-quote-strip__label"><?php echo $esc($l); ?></dt><dd class="tb-pg-quote-strip__value"><?php echo $esc($v); ?></dd></div><?php endforeach; ?>
    </dl>
  </div>
</section>
