# tracy_business — read this before changing anything on this site

This is a Joomla 6 site on the JoomlArt **T4** framework. The template is `tracy_business`;
the customer content is **Northgate Industrial** (EN + RU). Every visible block was built to a
measured design system — a change that "looks fine" but breaks the system is a defect.

## The thirteen rules

1. **Edit SCSS, never `css/template.css`.** `scss/_tracy-business-*.scss` → compile → `css/template.css`.
   Design tokens live in `css/styles/tracy-business.css` (hand-written, not compiled) — colours, type,
   spacing. Use `var(--…)`; never write a hex value that already has a token.
2. **After ANY change: compile SCSS (if touched) and clear the T4 optimize cache** — the site serves
   `media/t4/optimize/*` bundles, so you are looking at stale CSS/JS until you do
   (`docs/checks.md`). "My change does nothing" is almost always this.
3. **Read and write content through the Claude Cowork door, never the database.** The site ships
   `com_claudecowork` for exactly this: `content.list/get/update/delete/batch`, relations
   (module assignment, EN↔RU associations), receipts (`apply_id`) and `apply.revert`. No
   `docker exec … mariadb`, no `UPDATE ng_*`, no ad-hoc PHP against the DB — raw SQL bypasses the
   receipt, the nested-set upkeep and the undo, and leaves the site looking fine over broken data.
   Door URL, token location, actions, kinds and a worked example: `docs/cowork-api.md`. The Admin UI
   is the fallback for the few things the door has no action for; `tools/j/build-*.php` are the
   one-time import scripts of the build machine, not a maintenance path.
4. **Every designed section is a JA ACM module** (`mod_ja_acm`, type `tracy_business:tb-*`) in a
   position. Static pages are an article whose full text is `{loadposition <page>-page}` plus the
   modules in that position. Do not paste section HTML into an article; do not build a section as
   `mod_custom`. Catalogue: `docs/blocks.md`. Need a block that does not exist → `docs/recipes.md` §7.
5. **Two languages, always together.** Every article, category, menu item and module exists once
   per language (`en-GB`, `ru-RU`) with a Joomla **association** between the pair. One language alone
   breaks the switcher and the hreflang alternates. Never machine-translate; if the RU (or EN) text
   is not supplied, leave that language's item unpublished and say so.
6. **Never invent facts.** Numbers, names, dates, addresses, e-mails, phone numbers, URLs, PDFs come
   from the customer or from what the site already holds. Missing data = an empty, valid state (omit
   the row / hide the section), not a plausible placeholder. Known contradictions and open decisions:
   `docs/content-rules.md`.
7. **No fake features.** No `<form>` that does not submit somewhere real, no `href="#"`, no "coming
   soon", no dead download links. Contact form = `com_contact` (mail sending is a site setting — see
   `docs/content-rules.md`). Newsletter/Form/Email/Slide pages are **design samples**, kept static
   on purpose.
8. **Module titles: `[Tracy Business] <Page> - <Section> (<lang>)`**, position `<page>-page`, ordering =
   vertical order on the page. The Module Manager is the map; keep it readable.
9. **Breadcrumbs are automatic** (`mod_breadcrumbs` override, JSON-LD). Home has none. To change the
   last crumb, set the menu item's *Browser Page Title* (`page_title`) — do not touch the module.
10. **Menus:** main nav = `tb-main-en` / `tb-main-ru`; the megamenu structure is in
   `etc/navigation/tracy-business.json` keyed by menu item **id** — adding a top-level item means editing
   both menus AND that JSON (`docs/recipes.md` §5). Marketing-kit pages hang under a hidden menu.
11. **Dark mode is tokens, not overrides.** `html[data-theme="dark"]` remaps the tokens; a component
    written with tokens is dark-safe for free. Check both themes at 1440 and 390 before you say done.
12. **Verify with the scripts, not with your eyes** — `docs/checks.md`: site audit (links, overflow,
    console, raw language keys, switcher targets), interaction probe, megamenu reachability, PHP log.
    Report what the script printed. "Looks good" is not a verdict.
13. **Do not** rerun the build scripts (`tools/j/build-*.php` on the build machine) or delete data you
    did not create. `index.php`, `templateDetails.xml`, `etc/layout/tracy-business-*.json` and the T4
    profiles are editable — adding a position, a row, a megamenu entry is normal work — but write the
    reason into your change report (and the commit message when there is a repo). The other
    `etc/layout/*.json` are Tracy Base leftovers no style uses; ignore them.

## Where things are

| Need | Look at |
|---|---|
| Every page, URL, view, menu item, association, article, category, tag | `docs/site-map.md` (generated) |
| Extensions, modules per position, plugins, custom fields, overrides | `docs/inventory.md` (generated) |
| ACM blocks and their fields | `docs/blocks.md` (generated) |
| Positions, layouts, which page uses which style | `docs/positions.md` (generated) |
| Tokens, type scale, spacing, bands, dark mode, component classes, don'ts | `docs/design-system.md` |
| How to add a page / project / article / menu entry / block / string | `docs/recipes.md` |
| Source limits, contradictions, decisions the owner still has to make | `docs/content-rules.md` |
| Commands to compile, clear cache, audit, probe | `docs/checks.md` |
| The API door: reading/writing content, receipts, undo, worked example | `docs/cowork-api.md` |
| Languages installed, add/remove a site language, the 60-pack catalogue | `docs/languages.md`, `docs/language-packs.json` |

Generated files carry a banner and are rewritten by `tools/j/gen-docs.php` (build machine);
regenerate after content changes instead of editing them.

## Layout of this template

```
index.php, error.php            T4 entry points (error.php renders 404 through the inner layout)
templateDetails.xml             56 positions, language files
etc/site|theme|navigation/tracy-business.json   T4 profiles (site name, tokens for T4, megamenu structure)
etc/layout/tracy-business-home.json, tracy-business-inner.json   the two layouts
css/styles/tracy-business.css        THE token layer (light + dark remap)      ← hand-written
scss/_tracy-business-*.scss          chrome, home, shared, projects, news, system, pages, kit
css/template.css                compiled output — never edit
js/tracy-business.js                 search panel, language dropdown, megamenu Escape/outside-click
acm/tb-*/                       50 blocks: config.xml + tmpl/style-1.xml (fields) + style-1.php
html/                           overrides: com_content, com_contact, com_finder, com_tags, mod_*
html/layouts/t4/block/tracy-business-{topbar,header,footer}.html   chrome blocks
html/layouts/t4/element/{logo,megamenu,search-toggle,theme-toggle}.php
language/{en-GB,ru-RU}/*.tpl_tracy_business.ini   TPL_TRACY_BUSINESS_* strings (also copied to
                                /language/<tag>/ so ACM admin forms resolve them)
docs/                           this documentation (blocked from the web by .htaccess)
tools/add-language.php, remove-language.php   clone / drop a site language (PHP CLI from the webroot)

(not in the template) components/com_claudecowork + plugins/system/claudecoworkapi — the agent's door, docs/cowork-api.md
```
