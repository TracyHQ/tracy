<?php

/**
 * Tracy Business — Smart Search query form: one wide field and the ink button, 640px max, as designed.
 * Hidden fields (taxonomy filters, dates, Itemid) come from the view so a filtered search keeps its
 * filter when re-submitted. Autosuggest follows the menu/component setting exactly as core does.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\Finder\Site\View\Search\HtmlView $this */
if ($this->params->get('show_autosuggest', 1)) {
    $this->getDocument()->getWebAssetManager()->usePreset('awesomplete');
    $this->getDocument()->addScriptOptions('finder-search', ['url' => Route::_('index.php?option=com_finder&task=suggestions.suggest&format=json&tmpl=component')]);
    Text::script('COM_FINDER_SEARCH_FORM_LIST_LABEL');
    Text::script('JLIB_JS_AJAX_ERROR_OTHER');
    Text::script('JLIB_JS_AJAX_ERROR_PARSE');
}
?>
<form action="<?php echo Route::_($this->query->toUri()); ?>" method="get" class="js-finder-searchform tb-searchbar" role="search">
    <?php echo $this->getFields(); ?>
    <label for="q" class="visually-hidden"><?php echo Text::_('COM_FINDER_SEARCH_TERMS'); ?></label>
    <input type="text" name="q" id="q" class="js-finder-search-query tb-searchbar__input" value="<?php echo $this->escape($this->query->input); ?>" placeholder="<?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_PLACEHOLDER'); ?>" autocomplete="off">
    <button type="submit" class="tb-btn tb-btn--ink tb-searchbar__btn"><?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_ARIA'); ?></button>
</form>
