<?php
/**
 * Tracy Business — com_content / category / tb-vacancies (Careers → Vacancies category blog).
 *
 * The page the "Show all roles" footer and the department chips lead to: page-intro (category
 * title as H1, category description as the lede), the department chips (sub-categories of the
 * Vacancies root; the current one is active) and the full roles list — the same renderer the
 * `tb-page-roles` ACM uses on the Careers page, so both surfaces show one shape. Every item in
 * $this->items is listed; no pagination beyond the menu item's limit.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

require dirname(__DIR__, 3) . '/acm/tb-page-roles/_load.php';

$esc      = $ngPageEsc;
$app      = Factory::getApplication();
$category = $this->category;
$items    = (array) ($this->items ?? []);

// the root of the vacancies tree: this category when it has children, otherwise its parent
$children = $ngPageChildCategories((int) $category->id);
$rootId   = $children ? (int) $category->id : (int) $category->parent_id;
if (!$children && $rootId > 0) $children = $ngPageChildCategories($rootId);

$fields = $ngPageFields(array_map(static fn ($a) => (int) $a->id, $items), ['location', 'salary', 'type']);
$mail   = $ngPageCategoryParam($rootId, 'ng_apply_mail');
$roles  = [];
foreach ($items as $a) {
    $f = $fields[(int) $a->id] ?? [];
    $roles[] = ['title' => $a->title, 'dept' => (int) $a->catid === $rootId ? '' : $a->category_title, 'type' => (string) ($f['type'] ?? ''), 'city' => (string) ($f['location'] ?? ''), 'pay' => (string) ($f['salary'] ?? ''),
        'url' => $ngPageApplyUrl($mail, (string) $a->title)];
}
$lede = trim(strip_tags((string) $category->description));
?>
<div class="tb-page tb-pg-vacancies">
    <header class="tb-pageintro">
        <div class="tb-container tb-pageintro__inner">
            <div class="tb-pageintro__copy">
                <h1 class="tb-pageintro__title"><?php echo $esc($category->title); ?></h1>
                <?php if ($lede !== '') : ?><div class="tb-pageintro__lede"><p><?php echo $esc($lede); ?></p></div><?php endif; ?>
            </div>
        </div>
    </header>
    <div class="tb-page__body">
        <section class="tb-pg-band tb-pg-band--paper2 tb-pg-roles tb-pg-roles--page">
            <div class="tb-container">
                <?php if ($children && $rootId > 0) : ?>
                    <nav class="tb-chips tb-pg-roles__chips" aria-label="<?php echo $esc($category->title); ?>">
                        <a class="tb-chip<?php echo (int) $category->id === $rootId ? ' is-active' : ''; ?>" href="<?php echo $esc($ngPageCategoryUrl($rootId)); ?>"<?php echo (int) $category->id === $rootId ? ' aria-current="true"' : ''; ?>><?php echo Text::_('TPL_TRACY_BUSINESS_ACM_FILTER_ALL'); ?></a>
                        <?php foreach ($children as $c) : $active = (int) $c['id'] === (int) $category->id; ?><a class="tb-chip<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo $esc($ngPageCategoryUrl((int) $c['id'])); ?>"<?php echo $active ? ' aria-current="true"' : ''; ?>><?php echo $esc($c['title']); ?></a><?php endforeach; ?>
                    </nav>
                <?php endif; ?>
                <?php if ($roles) : ?>
                    <div class="tb-pg-roles__box"><?php echo $ngPageRolesList($roles, Text::_('TPL_TRACY_BUSINESS_PAGES_APPLY')); ?></div>
                <?php else : ?>
                    <p class="tb-pg-roles__empty"><?php echo Text::_('COM_CONTENT_NO_ARTICLES'); ?></p>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>
