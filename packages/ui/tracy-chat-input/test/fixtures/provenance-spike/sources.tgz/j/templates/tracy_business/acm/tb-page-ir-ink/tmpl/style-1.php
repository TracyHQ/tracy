<?php
/** Tracy Business — ACM `tb-page-ir-ink`: ink band, two columns — Dividends (H2 + line + rows amount/paid | year) on the left; Investor calendar (signal date + event) and Corporate governance links on the right. A governance row without a link is plain text. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$dt = trim((string) $helper->get('div-title')); $dp = trim((string) $helper->get('div-text')); $ct = trim((string) $helper->get('cal-title')); $gt = trim((string) $helper->get('gov-title'));
$divs = []; for ($i = 0, $n = (int) $helper->getRows('div-amount'); $i < $n; $i++) { $a = trim((string) $helper->get('div-amount', $i)); if ($a !== '') $divs[] = [$a, trim((string) $helper->get('div-paid', $i)), trim((string) $helper->get('div-year', $i))]; }
$cal = []; for ($i = 0, $n = (int) $helper->getRows('cal-date'); $i < $n; $i++) { $d = trim((string) $helper->get('cal-date', $i)); $e = trim((string) $helper->get('cal-event', $i)); if ($d !== '' || $e !== '') $cal[] = [$d, $e]; }
$gov = []; for ($i = 0, $n = (int) $helper->getRows('gov-text'); $i < $n; $i++) { $t = trim((string) $helper->get('gov-text', $i)); if ($t !== '') $gov[] = [$t, $route((string) $helper->get('gov-link', $i))]; }
if (!$divs && !$cal && !$gov) return;
?>
<section class="ja-acm acm-tb-page-ir-ink tb-pg-band tb-pg-band--ink tb-pg-irink" id="tb-pg-irink-<?php echo (int) $module->id; ?>">
  <div class="tb-container tb-pg-irink__inner">
    <div class="tb-pg-irink__col">
      <?php if ($dt !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm"><?php echo $esc($dt); ?></h2><?php endif; ?>
      <?php if ($dp !== '') : ?><p class="tb-pg-irink__text"><?php echo $esc($dp); ?></p><?php endif; ?>
      <?php if ($divs) : ?><ul class="tb-pg-irink__divs"><?php foreach ($divs as [$a, $p, $y]) : ?><li class="tb-pg-irink__div"><div><strong class="tb-pg-irink__amount"><?php echo $esc($a); ?></strong><?php if ($p !== '') : ?><span class="tb-pg-irink__paid"><?php echo $esc($p); ?></span><?php endif; ?></div><?php if ($y !== '') : ?><span class="tb-pg-irink__year"><?php echo $esc($y); ?></span><?php endif; ?></li><?php endforeach; ?></ul><?php endif; ?>
    </div>
    <div class="tb-pg-irink__col">
      <?php if ($cal) : ?>
        <?php if ($ct !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm"><?php echo $esc($ct); ?></h2><?php endif; ?>
        <ul class="tb-pg-irink__cal"><?php foreach ($cal as [$d, $e]) : ?><li class="tb-pg-irink__event"><span class="tb-pg-irink__date"><?php echo $esc($d); ?></span><span class="tb-pg-irink__what"><?php echo $esc($e); ?></span></li><?php endforeach; ?></ul>
      <?php endif; ?>
      <?php if ($gov) : ?>
        <?php if ($gt !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--xs tb-pg-irink__govtitle"><?php echo $esc($gt); ?></h2><?php endif; ?>
        <ul class="tb-pg-irink__gov"><?php foreach ($gov as [$t, $l]) : ?><li><?php if ($l !== '') : ?><a href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><span><?php echo $esc($t); ?></span><?php endif; ?></li><?php endforeach; ?></ul>
      <?php endif; ?>
    </div>
  </div>
</section>
