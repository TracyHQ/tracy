<?php
/**
 * Tracy Business — off-canvas drawer: the brand lockup from the logo element, a close button, the
 * `off-canvas` module position (main menu + CTA per language). Base file otherwise unchanged.
 *
 * T4's base draws the drawer's logo with `<img src="…svg">`, and it does NOT go through the `logo`
 * element — so the inline-SVG override that fixes the header never reaches the drawer. An SVG loaded
 * through <img> is an independent document: `currentColor` inside it resolves to the UA default,
 * black. Measured in dark: the site name rendered black on the drawer's #0e0e0e ground while the
 * identical mark in the header measured #f8f8f8.
 *
 * A CSS filter can make it legible and costs the accent its colour. Inlining costs nothing and is
 * the same repair the header already uses, so both places behave alike.
 *
 * Everything else is the base file unchanged.
 */

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$doc = $displayData->doc;
$paramsTpl = $doc->params;
$conf = Factory::getConfig();
//if(empty($paramsTpl->get('t4-navigation'))) $paramsTpl->set('t4-navigation','default');
//$params = json_decode(\T4\Helper\Path::getFileContent('etc/navigation/'.$paramsTpl->get('t4-navigation').'.json'));
//if(empty($params)) return;
//if (!$params->navigation_oc_enabled) return;
$navigation_settings = $paramsTpl->get('navigation-settings');
$site_settings = $paramsTpl->get('site-settings');
if (!$navigation_settings->get('oc_enabled')) return;
$offcanvas_title = Text::_('T4_OFF_CANVAS_TITLE');
$site_name = $site_settings->get('site_name', $conf->get('sitename'));
$site_slogan = $site_settings->get('site_slogan', '');
$logo = $site_settings->get('site_logo');
$logo_small = $site_settings->get('site_logo_small');
$logo_cls = $logo ? 'logo-image' : 'logo-text';
$logo_sm_cls = '';
if ($logo_small) {
    $logo_cls .= ' logo-control';
    $logo_sm_cls = ' d-none d-sm-block';
  if(version_compare(JVERSION, '4.0', 'ge')){
    $logo_small = HTMLHelper::cleanImageURL($logo_small)->url;
  }
}
if($logo && version_compare(JVERSION, '4.0', 'ge')){
  $logo = HTMLHelper::cleanImageURL($logo)->url;
}
$oc_effect = $navigation_settings->get('oc_effect', "left");

$oc_pos_name = $navigation_settings->get('oc_pos_name', 'offcanvas');
$oc_pos_style = $navigation_settings->get('oc_pos_style', 'xhtml');
$oc_rightside = filter_var($navigation_settings->get('oc_rightside'), FILTER_VALIDATE_BOOLEAN);
$oc_menu_effect = $navigation_settings->get('oc_menu_effect', 'def');
// add css & js
$doc->addStylesheet(T4\Helper\Path::findInTheme('vendors/js-offcanvas/_css/js-offcanvas.css', true));
$doc->addScript(T4\Helper\Path::findInTheme('vendors/js-offcanvas/_js/js-offcanvas.pkgd.js', true));
$doc->addScript(T4\Helper\Path::findInTheme('vendors/bodyscrolllock/bodyScrollLock.min.js', true));
$doc->addScript(T4\Helper\Path::findInTheme('js/offcanvas.js', true));
$oc_rightside = $navigation_settings->get('oc_rightside', '');
if($oc_rightside){
      $oc_effect = str_replace("left", 'right', $oc_effect);
  }
switch ($oc_effect) {
	case 'left':
	case 'right':
		$options = '{"modifiers":"'.$oc_effect.',overlay"}';
		break;
	
	default:
		$options = '{"modifiers":"'.str_replace("-",",",$oc_effect).'"}';
		break;
}

$hasLink = !empty($displayData->params) && !empty($displayData->params['nolink']) ? false : true;
?>
<div class="t4-offcanvas tb-drawer" data-offcanvas-options='<?php echo $options; ?>' id="off-canvas-<?php echo $oc_effect;?>" role="complementary" style="display:none;">
	<div class="t4-off-canvas-header tb-drawer__head">
		<?php /* Northgate: the same brand lockup as the header, so the drawer is recognisably the site. */ ?>
		<?php echo \Joomla\CMS\Layout\LayoutHelper::render('t4.element.logo', $displayData, T4PATH . '/html/layouts'); ?>
		<button type="button" class="close js-offcanvas-close tb-drawer__close" data-dismiss="modal" aria-label="<?php echo htmlspecialchars(Text::_('TPL_TRACY_BUSINESS_MENU_CLOSE'), ENT_QUOTES, 'UTF-8'); ?>">&times;</button>
	</div>
	<div class="t4-off-canvas-body tb-drawer__body menu-item-<?php echo $oc_menu_effect;?>" data-effect="<?php echo $oc_menu_effect;?>">
		<jdoc:include type="modules" name="<?php echo $oc_pos_name ?>" style="<?php echo $oc_pos_style ?>" />
	</div>
	<?php if($doc->countModules('offcanvas-footer')): ?>
		<div class="t4-off-canvas-footer">
			<jdoc:include type="modules" name="offcanvas-footer" style="<?php echo $oc_pos_style ?>" />
		</div>
	<?php endif; ?>
</div>
