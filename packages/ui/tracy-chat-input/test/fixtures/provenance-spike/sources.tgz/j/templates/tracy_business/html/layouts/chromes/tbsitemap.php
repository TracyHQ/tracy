<?php

/**
 * Tracy Business — sitemap column chrome: one module (a mod_menu of one real menu) is one column, the
 * module title is the column heading. Used by the Sitemap page as {loadposition sitemap-page, tbsitemap}.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

$module = $displayData['module'];

if (empty($module->content)) {
    return;
}
?>
<section class="tb-sitemap__col" id="Mod<?php echo (int) $module->id; ?>">
    <?php if ($module->showtitle) : ?><h2 class="tb-sitemap__title"><?php echo $module->title; ?></h2><?php endif; ?>
    <?php echo $module->content; ?>
</section>
