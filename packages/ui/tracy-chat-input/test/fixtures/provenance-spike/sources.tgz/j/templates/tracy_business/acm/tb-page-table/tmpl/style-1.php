<?php
/** Tracy Business — ACM `tb-page-table`: paper-2 band, H2 + note, then a real <table> (ink header, forest change column) inside a horizontally scrolling wrapper so the last column survives a phone. IR "Key figures". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title')); $note = trim((string) $helper->get('note'));
$head = []; for ($c = 1; $c <= 4; $c++) $head[] = trim((string) $helper->get('head-' . $c));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('cell-1'); $i < $n; $i++) { $r = []; for ($c = 1; $c <= 4; $c++) $r[] = trim((string) $helper->get('cell-' . $c, $i)); if (implode('', $r) !== '') $rows[] = $r; }
if (!$rows) return;
$id = 'tb-pg-table-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-table tb-pg-band tb-pg-band--paper2 tb-pg-figures" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-figures__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <?php if ($note !== '') : ?><p class="tb-pg-figures__note"><?php echo $esc($note); ?></p><?php endif; ?>
    <div class="tb-pg-figures__scroll table-responsive">
      <table class="tb-pg-figures__table">
        <?php if (implode('', $head) !== '') : ?><thead><tr><?php foreach ($head as $h) : ?><th scope="col"><?php echo $esc($h); ?></th><?php endforeach; ?></tr></thead><?php endif; ?>
        <tbody>
          <?php foreach ($rows as $r) : ?><tr><th scope="row"><?php echo $esc($r[0]); ?></th><td><?php echo $esc($r[1]); ?></td><td class="tb-pg-figures__now"><?php echo $esc($r[2]); ?></td><td class="tb-pg-figures__change"><?php echo $esc($r[3]); ?></td></tr><?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
