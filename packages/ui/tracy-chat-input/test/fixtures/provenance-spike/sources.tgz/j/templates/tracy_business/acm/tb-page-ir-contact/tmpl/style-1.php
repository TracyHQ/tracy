<?php
/** Tracy Business — ACM `tb-page-ir-contact`: bordered paper-2 box — small label, name · role, email + phone on the left; an email field and a forest button on the right. The field/button are a DESIGN SAMPLE: there is no subscription service behind them, so the button is type=button and the block says so in its markup. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$label = trim((string) $helper->get('label')); $name = trim((string) $helper->get('name')); $mail = trim((string) $helper->get('email')); $phone = trim((string) $helper->get('phone'));
$ph = trim((string) $helper->get('input-placeholder')); $btn = trim((string) $helper->get('button'));
if ($name === '' && $mail === '') return;
$id = 'tb-pg-irc-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-ir-contact tb-pg-irc" id="<?php echo $id; ?>">
  <div class="tb-container">
    <div class="tb-pg-irc__box">
      <div class="tb-pg-irc__who">
        <?php if ($label !== '') : ?><p class="tb-pg-irc__label"><?php echo $esc($label); ?></p><?php endif; ?>
        <?php if ($name !== '') : ?><p class="tb-pg-irc__name"><?php echo $esc($name); ?></p><?php endif; ?>
        <p class="tb-pg-irc__lines">
          <?php if ($mail !== '') : ?><a href="mailto:<?php echo $esc($mail); ?>"><?php echo $esc($mail); ?></a><?php endif; ?>
          <?php if ($phone !== '') : ?><a href="tel:<?php echo $esc(preg_replace('/[^0-9+]/', '', $phone)); ?>"><?php echo $esc($phone); ?></a><?php endif; ?>
        </p>
      </div>
      <?php if ($btn !== '') : ?>
        <!-- design sample: no subscription backend is wired, nothing is sent -->
        <div class="tb-pg-irc__sub" data-tb-sample="subscribe">
          <label class="visually-hidden" for="<?php echo $id; ?>-email"><?php echo $esc($ph); ?></label>
          <input class="tb-pg-irc__input" id="<?php echo $id; ?>-email" type="email" placeholder="<?php echo $esc($ph); ?>" autocomplete="email">
          <button class="tb-btn tb-btn--forest tb-pg-irc__btn" type="button"><?php echo $esc($btn); ?></button>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
