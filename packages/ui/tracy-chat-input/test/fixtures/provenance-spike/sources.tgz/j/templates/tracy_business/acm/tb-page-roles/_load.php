<?php
/**
 * Tracy Business — shared loader for the content-driven page blocks (`tb-page-services`, `tb-page-roles`
 * and the Vacancies category layout): published articles of a category with their custom-field
 * values, read straight from #__fields_values so a subform (repeatable) field decodes to a list.
 * Required with `require` (not _once) so the closures exist in every layout's scope.
 */
defined('_JEXEC') or die;

$ngPageEsc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

$ngPageRoute = static function (string $l): string {
    $l = trim($l);
    if ($l === '' || $l === '#') return '';
    return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l);
};

$ngPageImage = static function (string $raw): string {
    $img = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw);
    if ($img !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $img)) $img = \Joomla\CMS\Uri\Uri::root(true) . '/' . $img;
    return $img;
};

/** published articles of a category (+ children when $subcats), ordered by article ordering, oldest ordering first */
$ngPageArticles = static function (int $categoryId, int $limit = 0, bool $subcats = true): array {
    if ($categoryId <= 0) return [];
    $app   = \Joomla\CMS\Factory::getApplication();
    $model = $app->bootComponent('com_content')->getMVCFactory()->createModel('Articles', 'Site', ['ignore_request' => true]);
    $model->setState('params', clone \Joomla\CMS\Component\ComponentHelper::getParams('com_content'));
    $model->setState('filter.category_id', $categoryId);
    $model->setState('filter.subcategories', $subcats);
    $model->setState('filter.max_category_levels', 2);
    $model->setState('filter.published', 1);
    $model->setState('filter.access', true);
    $model->setState('filter.language', $app->getLanguageFilter());
    $model->setState('list.start', 0);
    $model->setState('list.limit', $limit > 0 ? $limit : 0);
    $model->setState('list.ordering', 'a.ordering');
    $model->setState('list.direction', 'ASC');
    return $model->getItems() ?: [];
};

/** total published articles of a category (+ children) — for "show all N" footers */
$ngPageCount = static function (int $categoryId, bool $subcats = true): int {
    if ($categoryId <= 0) return 0;
    $db  = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $ids = [$categoryId];
    if ($subcats) {
        $q = $db->getQuery(true)->select('id')->from('#__categories')->where('parent_id = ' . (int) $categoryId)->where('published = 1');
        $ids = array_merge($ids, array_map('intval', $db->setQuery($q)->loadColumn() ?: []));
    }
    $q = $db->getQuery(true)->select('COUNT(*)')->from('#__content')->where('state = 1')->where('catid IN (' . implode(',', $ids) . ')');
    $lang = \Joomla\CMS\Factory::getApplication()->getLanguageFilter() ? \Joomla\CMS\Factory::getLanguage()->getTag() : '';
    if ($lang !== '') $q->where('language IN (' . $db->quote($lang) . ', ' . $db->quote('*') . ')');
    return (int) $db->setQuery($q)->loadResult();
};

/**
 * custom-field values for a set of articles: [itemId => [fieldName => value]]; a subform value
 * (repeatable) comes back as a flat list of its cell strings, everything else as a string.
 */
$ngPageFields = static function (array $itemIds, array $names): array {
    if (!$itemIds || !$names) return [];
    $db = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $q  = $db->getQuery(true)->select('f.name, f.type, v.item_id, v.value')->from('#__fields_values AS v')
        ->join('INNER', '#__fields AS f ON f.id = v.field_id')
        ->where("f.context = 'com_content.article'")->where('f.state = 1')
        ->where('f.name IN (' . implode(',', array_map([$db, 'quote'], $names)) . ')')
        ->where('v.item_id IN (' . implode(',', array_map([$db, 'quote'], array_map('strval', $itemIds))) . ')');
    $out = [];
    foreach ($db->setQuery($q)->loadAssocList() ?: [] as $r) {
        $v = (string) $r['value'];
        if ($r['type'] === 'subform') {
            $rows = json_decode($v, true) ?: [];
            $list = [];
            foreach ($rows as $row) foreach ((array) $row as $cell) { $cell = trim((string) $cell); if ($cell !== '') $list[] = $cell; }
            $v = $list;
        }
        $out[(int) $r['item_id']][$r['name']] = $v;
    }
    return $out;
};

$ngPageChildCategories = static function (int $parentId): array {
    $db = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $q  = $db->getQuery(true)->select('id, title')->from('#__categories')
        ->where('parent_id = ' . (int) $parentId)->where('published = 1')->where("extension = 'com_content'")->order('lft');
    return $db->setQuery($q)->loadAssocList() ?: [];
};

/** one param of a category (e.g. ng_apply_mail on the Vacancies root) */
$ngPageCategoryParam = static function (int $id, string $name): string {
    if ($id <= 0) return '';
    $db = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $p  = json_decode((string) $db->setQuery('SELECT params FROM #__categories WHERE id = ' . (int) $id)->loadResult(), true) ?: [];
    return trim((string) ($p[$name] ?? ''));
};

/** the Apply link for a role: mailto the HR address with the role as subject — or nothing, never "#" */
$ngPageApplyUrl = static fn (string $mail, string $roleTitle): string => $mail !== '' ? 'mailto:' . $mail . '?subject=' . rawurlencode($roleTitle) : '';

$ngPageCategoryUrl = static fn (int $id): string => \Joomla\CMS\Router\Route::_(\Joomla\Component\Content\Site\Helper\RouteHelper::getCategoryRoute($id));

/**
 * the roles table/cards used by the Careers block and the Vacancies category page.
 * $roles: list of [title, dept, type, city, pay, url]; $applyText: link text.
 */
$ngPageRolesList = static function (array $roles, string $applyText) use ($ngPageEsc): string {
    if (!$roles) return '';
    $h = '<ul class="tb-pg-roles__list">';
    foreach ($roles as $r) {
        $meta = implode(' · ', array_filter([$r['dept'], $r['type']], static fn ($s) => trim((string) $s) !== ''));
        $h .= '<li class="tb-pg-roles__row">'
            . '<div class="tb-pg-roles__main"><strong class="tb-pg-roles__title">' . $ngPageEsc($r['title']) . '</strong>'
            . ($meta !== '' ? '<span class="tb-pg-roles__meta">' . $ngPageEsc($meta) . '</span>' : '') . '</div>'
            . '<span class="tb-pg-roles__city">' . $ngPageEsc($r['city']) . '</span>'
            . '<span class="tb-pg-roles__pay">' . $ngPageEsc($r['pay']) . '</span>'
            . ($applyText !== '' && $r['url'] !== '' ? '<a class="tb-pg-roles__apply" href="' . $ngPageEsc($r['url']) . '">' . $ngPageEsc($applyText) . '</a>' : '<span></span>')
            . '</li>';
    }
    return $h . '</ul>';
};
