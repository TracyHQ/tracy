<?php

/**
 * Tracy Business — main navigation, one menu per language.
 *
 * T4's element reads ONE `menu_type` from the navigation profile. A multilingual site needs a
 * different menu per language, so this override resolves `<menu_type>-<language sef>` first
 * (tb-main-en, tb-main-ru) and falls back to `<menu_type>` when no such menu exists. Everything
 * else is the base element unchanged: the same mod_menu render with the `mega` layout, the same
 * megamenu.js.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\Registry\Registry;

$app        = Factory::getApplication();
$paramsTpl  = $app->getTemplate(true)->params;
$navigation = $paramsTpl->get('navigation-settings');
$menutype   = !empty($displayData->params['menutype']) ? $displayData->params['menutype'] : $navigation->get('menu_type', 'mainmenu');

$sef = '';

foreach (\Joomla\CMS\Language\LanguageHelper::getLanguages('lang_code') as $code => $lang) {
    if ($code === $app->getLanguage()->getTag()) {
        $sef = (string) $lang->sef;
    }
}

if ($sef !== '') {
    $db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $exists = $db->setQuery(
        $db->getQuery(true)->select('menutype')->from('#__menu_types')->where('menutype = ' . $db->quote($menutype . '-' . $sef))
    )->loadResult();

    if ($exists) {
        $menutype = $exists;
    }
}

$params = new Registry();
$params->loadString('{"menutype":"mainmenu","base":"","startLevel":1,"endLevel":0,"showAllChildren":1,"tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":1,"cache_time":900,"cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}');
$params->set('layout', 'mega');
$params->set('menutype', $menutype);
$params->set('startLevel', 1);
$params->set('endLevel', 0);
$params->set('showAllChildren', 1);
$params->set('jamegamenu', 1);
$params->set('cache', 0);

$module            = new \stdClass();
$module->params    = $params;
$module->module    = 'mod_menu';
$module->id        = 0;
$module->name      = 'menu';
$module->title     = $menutype;
$module->showtitle = 0;
$module->position  = 'none';

Factory::getDocument()->addScript(T4PATH_BASE_URI . '/js/megamenu.js');

echo ModuleHelper::renderModule($module, []);
