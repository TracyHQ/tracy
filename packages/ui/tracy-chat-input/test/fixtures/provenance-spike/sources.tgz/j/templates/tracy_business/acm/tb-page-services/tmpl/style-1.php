<?php
/**
 * Tracy Business — ACM `tb-page-services`: paper-2 band, H2 "What we offer" and a 3×2 grid of service
 * cards read from a category — one article per service: title, intro text as the paragraph,
 * custom field `covered` (repeatable) as the "· " list under a forest label, custom field
 * `timeline` as the forest footer line. Adding a seventh service is adding an article.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__, 2) . '/tb-page-roles/_load.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = $ngPageEsc;
$title = trim((string) $helper->get('title')); $catId = (int) $helper->get('source-category'); $label = trim((string) $helper->get('covered-label'));
$items = $ngPageArticles($catId, 0, false);
if (!$items) return;
$fields = $ngPageFields(array_map(static fn ($a) => (int) $a->id, $items), ['covered', 'timeline']);
$id = 'tb-pg-services-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-services tb-pg-band tb-pg-band--paper2 tb-pg-services" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-services__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <ul class="tb-pg-services__grid">
      <?php foreach ($items as $a) : $f = $fields[(int) $a->id] ?? []; $covered = (array) ($f['covered'] ?? []); $timeline = trim((string) ($f['timeline'] ?? '')); $desc = trim(strip_tags((string) $a->introtext)); ?>
        <li class="tb-pg-services__card">
          <h3 class="tb-pg-services__name"><?php echo $esc($a->title); ?></h3>
          <?php if ($desc !== '') : ?><p class="tb-pg-services__desc"><?php echo $esc($desc); ?></p><?php endif; ?>
          <?php if ($covered) : ?>
            <div class="tb-pg-services__covered">
              <?php if ($label !== '') : ?><p class="tb-pg-services__label"><?php echo $esc($label); ?></p><?php endif; ?>
              <ul class="tb-pg-services__list"><?php foreach ($covered as $c) : ?><li><?php echo $esc($c); ?></li><?php endforeach; ?></ul>
            </div>
          <?php endif; ?>
          <?php if ($timeline !== '') : ?><p class="tb-pg-services__timeline"><?php echo $esc($timeline); ?></p><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>
