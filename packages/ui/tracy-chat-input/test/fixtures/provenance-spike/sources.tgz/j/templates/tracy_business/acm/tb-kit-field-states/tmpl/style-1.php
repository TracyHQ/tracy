<?php
/** Tracy Business — ACM `tb-kit-field-states`: FIELD STATES — Default · Focused (forest ring) · Error (red ring + text) · Disabled. Reference inputs only: all disabled, states drawn by class. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$title = trim((string) $helper->get('title'));
$kinds = ['default', 'focused', 'error', 'disabled'];
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('state-label'); $i < $n; $i++) {
    $l = trim((string) $helper->get('state-label', $i)); if ($l === '') continue;
    $k = (string) $helper->get('state-kind', $i);
    $rows[] = [$l, trim((string) $helper->get('state-value', $i)), in_array($k, $kinds, true) ? $k : 'default', trim((string) $helper->get('state-error', $i))];
}
if (!$rows) return;
$id = 'tb-kitstates-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-field-states tb-kitside tb-kitstates" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <?php if ($title !== '') : ?><h2 class="tb-kitside__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-kitstates__list">
    <?php foreach ($rows as $i => [$l, $v, $k, $e]) : ?>
      <li class="tb-kitstates__item tb-kitstates__item--<?php echo $k; ?>">
        <label class="tb-kitstates__label" for="<?php echo $id; ?>-<?php echo $i; ?>"><?php echo $esc($l); ?></label>
        <input class="tb-kitstates__input" id="<?php echo $id; ?>-<?php echo $i; ?>" type="text" placeholder="<?php echo $esc($v); ?>" disabled<?php if ($k === 'error' && $e !== '') : ?> aria-describedby="<?php echo $id; ?>-<?php echo $i; ?>-err"<?php endif; ?>>
        <?php if ($k === 'error' && $e !== '') : ?><span class="tb-kitstates__error" id="<?php echo $id; ?>-<?php echo $i; ?>-err"><?php echo $esc($e); ?></span><?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
</section>
