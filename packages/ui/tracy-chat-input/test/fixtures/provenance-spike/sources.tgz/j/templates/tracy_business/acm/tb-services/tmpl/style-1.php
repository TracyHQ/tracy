<?php
/**
 * Tracy Business — ACM `tb-services`: "What we do" — eyebrow, Newsreader title, "All services →" link,
 * and a row of numbered cards (01…) on the paper band. Numbers come from the row order, so the
 * owner reorders cards in the admin and the numbering follows.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$url = static function (string $link): string {
    $link = trim($link);
    if ($link === '' || $link === '#') return '';
    return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $link) ? $link : \Joomla\CMS\Router\Route::_($link);
};
$eyebrow = trim((string) $helper->get('eyebrow'));
$title   = trim((string) $helper->get('title'));
$allText = trim((string) $helper->get('all-text'));
$allLink = $url((string) $helper->get('all-link'));
$items = [];
for ($i = 0, $n = (int) $helper->getRows('item-title'); $i < $n; $i++) {
    $t = trim((string) $helper->get('item-title', $i));
    if ($t === '') continue;
    $items[] = ['title' => $t, 'desc' => trim((string) $helper->get('item-desc', $i)), 'link' => $url((string) $helper->get('item-link', $i))];
}
$id = 'tb-services-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-services tb-section tb-services" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container">
    <header class="tb-section__head">
      <div>
        <?php if ($eyebrow !== '') : ?><p class="tb-eyebrow"><?php echo $esc($eyebrow); ?></p><?php endif; ?>
        <h2 class="tb-section__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
      </div>
      <?php if ($allText !== '' && $allLink !== '') : ?><a class="tb-textlink" href="<?php echo $esc($allLink); ?>"><?php echo $esc($allText); ?></a><?php endif; ?>
    </header>
    <ol class="tb-services__grid">
      <?php foreach ($items as $i => $item) : ?>
        <li class="tb-services__card">
          <span class="tb-services__num" aria-hidden="true"><?php echo str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT); ?></span>
          <h3 class="tb-services__title">
            <?php if ($item['link'] !== '') : ?><a href="<?php echo $esc($item['link']); ?>"><?php echo $esc($item['title']); ?></a><?php else : ?><?php echo $esc($item['title']); ?><?php endif; ?>
          </h3>
          <?php if ($item['desc'] !== '') : ?><p class="tb-services__desc"><?php echo $esc($item['desc']); ?></p><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>
