<?php

/**
 * Tracy — offline page.
 *
 * Standalone like error.php: own <head>, own stylesheet links, and the SAME server-side dark
 * resolution via theme-resolve.php (gotcha #6). The login form uses the fixture's field vocabulary
 * so a site that is offline still looks like itself.
 *
 * @package TRACY_BASE
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$app      = Factory::getApplication();
$sitename = htmlspecialchars((string) $app->get('sitename'), ENT_QUOTES, 'UTF-8');
$base     = Uri::root(true);
$tpl      = $base . '/templates/' . $this->template;

$tracyBaseSiteProfile = 'default';
require __DIR__ . '/theme-resolve.php';

$darkCss  = __DIR__ . '/css/darkmode.css';
$showDark = $tracyBaseDarkEnabled || $tracyBaseDefaultTheme === 'dark' || $tracyBaseDefaultTheme === 'auto';
$message  = $app->get('display_offline_message', 1) == 1
    ? $app->get('offline_message')
    : ($app->get('display_offline_message', 1) == 2 ? Text::_('JOFFLINE_MESSAGE') : '');
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo $sitename; ?></title>
    <script><?php echo $tracyBaseHeadScript; ?></script>
    <link rel="stylesheet" href="<?php echo $tpl; ?>/css/template.css">
    <?php if ($showDark && is_file($darkCss)) : ?>
        <link rel="stylesheet" href="<?php echo $tpl; ?>/css/darkmode.css?<?php echo filemtime($darkCss); ?>">
    <?php endif; ?>
    <style>
        .tracy-standalone {
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: var(--space-12) var(--container-gutter-desktop);
            background: var(--bg);
            color: var(--fg);
        }
        .tracy-standalone__inner { width: 100%; max-width: 420px; }
        .tracy-standalone__title {
            font-family: var(--font-display);
            font-size: var(--text-2xl);
            line-height: var(--leading-tight);
            letter-spacing: var(--tracking-display);
            margin: 0 0 var(--space-4);
        }
        .tracy-standalone__msg { color: var(--muted); margin: 0 0 var(--space-8); }
        .tracy-standalone label { display: block; margin-bottom: var(--space-2); font-size: var(--text-sm); }
        .tracy-standalone input { width: 100%; margin-bottom: var(--space-4); }
    </style>
</head>
<body class="tracy-offline">
    <main class="tracy-standalone">
        <div class="tracy-standalone__inner">
            <h1 class="tracy-standalone__title"><?php echo $sitename; ?></h1>
            <?php if ($message) : ?>
                <div class="tracy-standalone__msg"><?php echo $message; ?></div>
            <?php endif; ?>

            <form action="<?php echo Uri::root(true); ?>/index.php" method="post" id="tracy-offline-login">
                <label for="username"><?php echo Text::_('JGLOBAL_USERNAME'); ?></label>
                <input id="username" name="username" type="text" class="form-control" autocomplete="username">

                <label for="passwd"><?php echo Text::_('JGLOBAL_PASSWORD'); ?></label>
                <input id="passwd" name="password" type="password" class="form-control" autocomplete="current-password">

                <button type="submit" class="btn btn-primary tracy-btn--primary"><?php echo Text::_('JLOGIN'); ?></button>

                <input type="hidden" name="option" value="com_users">
                <input type="hidden" name="task" value="user.login">
                <input type="hidden" name="return" value="<?php echo base64_encode(Uri::base()); ?>">
                <?php echo HTMLHelper::_('form.token'); ?>
            </form>
        </div>
    </main>
</body>
</html>
