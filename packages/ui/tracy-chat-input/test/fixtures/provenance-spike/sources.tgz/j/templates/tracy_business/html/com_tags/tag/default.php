<?php

/**
 * Tracy Business — tag page (com_tags, tag view). The design has no tag page; this reuses the page
 * intro (tag name as H1, tag description as lede) and the news card grid so tagged articles read
 * like the News listing. The core filter form is dropped: the page is a listing, not a search.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$esc  = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$tags = $this->item ?? [];
$title = trim((string) ($this->params->get('page_heading') ?: ($tags[0]->title ?? '')));
$desc  = trim((string) ($tags[0]->description ?? ''));
?>
<div class="tb-page tb-tagpage">
    <header class="tb-pageintro">
        <div class="tb-container tb-pageintro__inner">
            <div class="tb-pageintro__copy">
                <p class="tb-eyebrow"><?php echo Text::_('COM_TAGS_DEFAULT_PAGE_TITLE'); ?></p>
                <h1 class="tb-pageintro__title"><?php echo $esc($title); ?></h1>
                <?php if ($desc !== '') : ?><div class="tb-pageintro__lede"><?php echo HTMLHelper::_('content.prepare', $desc); ?></div><?php endif; ?>
            </div>
        </div>
    </header>
    <div class="tb-page__body">
        <div class="tb-container">
            <?php if (empty($this->items)) : ?>
                <p class="tb-tagpage__empty"><?php echo Text::_('COM_TAGS_NO_ITEMS'); ?></p>
            <?php else : ?>
                <div class="tb-news__grid tb-tagpage__grid">
                    <?php foreach ($this->items as $item) :
                        $images = json_decode($item->core_images ?: '{}');
                        $img = HTMLHelper::_('cleanImageURL', $images->image_intro ?? '')->url ?? '';
                        $linkable = !in_array($item->type_alias, ['com_users.category', 'com_banners.category'], true);
                        $date = $item->core_publish_up ?: $item->core_created;
                        ?>
                        <article class="tb-ncard">
                            <?php if ($img !== '' && $linkable) : ?><a class="tb-ncard__media" href="<?php echo Route::_($item->link); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($img); ?>" alt="" loading="lazy" decoding="async"></a><?php endif; ?>
                            <?php if ($date) : ?><p class="tb-ncard__meta"><time datetime="<?php echo HTMLHelper::_('date', $date, 'Y-m-d'); ?>"><?php echo HTMLHelper::_('date', $date, Text::_('TPL_TRACY_BUSINESS_DATE_FORMAT')); ?></time></p><?php endif; ?>
                            <h3 class="tb-ncard__title"><?php if ($linkable) : ?><a href="<?php echo Route::_($item->link); ?>"><?php echo $esc($item->core_title); ?></a><?php else : ?><?php echo $esc($item->core_title); ?><?php endif; ?></h3>
                        </article>
                    <?php endforeach; ?>
                </div>
                <?php if ($this->pagination->pagesTotal > 1) : ?><div class="tb-tagpage__pagination"><?php echo $this->pagination->getPagesLinks(); ?></div><?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
