# Image credits — tracy_apple

Every image shipped with this template was generated for it by
`scripts/phase6b-imagery.py` (a build script, kept with the spec-pack): flat gradient fields
with one soft light source, plus geometric portrait and client-mark stand-ins. Colours are the
OpenDesign `apple` tokens.

| File | Size | Source | Licence |
|---|---|---|---|
| `images/tracy-base/chapter-precision.jpg` | 1600x1100 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/chapter-depth.jpg` | 1600x1100 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/chapter-material.jpg` | 1600x1100 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/hero-still.jpg` | 2000x1200 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/portrait-1.jpg` | 640x640 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/portrait-2.jpg` | 640x640 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/portrait-3.jpg` | 640x640 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/portrait-4.jpg` | 640x640 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-1.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-2.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-3.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-4.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-5.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |
| `images/tracy-base/mark-6.png` | 320x120 | generated for this template | same as the template (GPL-2.0-or-later) |

No third-party photography, icon set or typeface binary is redistributed here. The design
system names SF Pro; the template only *references* the family and falls back to
`-apple-system` / Helvetica Neue / Arial, so no font file ships.
