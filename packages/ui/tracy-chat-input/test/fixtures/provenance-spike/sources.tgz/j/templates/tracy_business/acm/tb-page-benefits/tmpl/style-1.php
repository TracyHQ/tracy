<?php
/** Tracy Business — ACM `tb-page-benefits`: "What we offer" — H2 and hairline rows of title + line (no arrow). A column; sits beside `tb-process` in a split row. Careers. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-desc', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-page-benefits tb-pg-benefits" id="tb-pg-benefits-<?php echo (int) $module->id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm tb-pg-benefits__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-pg-benefits__list">
    <?php foreach ($rows as [$t, $d]) : ?><li class="tb-pg-benefits__row"><strong class="tb-pg-benefits__name"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><p class="tb-pg-benefits__desc"><?php echo $esc($d); ?></p><?php endif; ?></li><?php endforeach; ?>
  </ul>
</div>
