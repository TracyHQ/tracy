<?php
/** Tracy Business — ACM `tb-news`, style 1: "News & disclosures" — title, "View all →", three 16:9 photo cards with date · category, title, intro. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__) . '/_load.php'; // not _once: the closures must exist in EVERY layout's scope
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$catId = (int) $helper->get('source-category');
$items = $ngLoadNews($catId, max(1, (int) ($helper->get('count') ?: 3)));
if (!$items) return;
$allText = trim((string) $helper->get('all-text')); $allUrl = $ngNewsCategoryUrl($catId);
$id = 'tb-news-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-news tb-section tb-news" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container">
    <header class="tb-section__head">
      <h2 class="tb-section__title" id="<?php echo $id; ?>-title"><?php echo $esc((string) $helper->get('title')); ?></h2>
      <?php if ($allText !== '') : ?><a class="tb-textlink" href="<?php echo $esc($allUrl); ?>"><?php echo $esc($allText); ?></a><?php endif; ?>
    </header>
    <div class="tb-news__grid">
      <?php foreach ($items as $n) : ?>
        <article class="tb-ncard">
          <?php if ($n['image'] !== '') : ?><a class="tb-ncard__media" href="<?php echo $esc($n['url']); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($n['image']); ?>" alt="" width="800" height="450" loading="lazy" decoding="async"></a><?php endif; ?>
          <p class="tb-ncard__meta"><time datetime="<?php echo $esc($n['datetime']); ?>"><?php echo $esc($n['date']); ?></time> · <?php echo $esc($n['category']); ?></p>
          <h3 class="tb-ncard__title"><a href="<?php echo $esc($n['url']); ?>"><?php echo $esc($n['title']); ?></a></h3>
          <?php if ($n['intro'] !== '') : ?><p class="tb-ncard__desc"><?php echo $esc($n['intro']); ?></p><?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
