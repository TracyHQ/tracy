<?php
/** Tracy Business — ACM `tb-sys-chips`: bordered box with an eyebrow and a row of small bordered links. A chip without a link is plain text. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l, false); };
$title = trim((string) $helper->get('title')); if ($title === '') $title = trim((string) $module->title);
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('label'); $i < $n; $i++) { $l = trim((string) $helper->get('label', $i)); if ($l !== '') $rows[] = [$l, $route((string) $helper->get('link', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-sys-chips tb-sysbox tb-chipbox">
  <?php if ($title !== '') : ?><p class="tb-sysbox__eyebrow"><?php echo $esc($title); ?></p><?php endif; ?>
  <div class="tb-chips tb-chipbox__chips">
    <?php foreach ($rows as [$l, $u]) : ?><?php if ($u !== '') : ?><a class="tb-chip" href="<?php echo $esc($u); ?>"><?php echo $esc($l); ?></a><?php else : ?><span class="tb-chip"><?php echo $esc($l); ?></span><?php endif; ?><?php endforeach; ?>
  </div>
</div>
