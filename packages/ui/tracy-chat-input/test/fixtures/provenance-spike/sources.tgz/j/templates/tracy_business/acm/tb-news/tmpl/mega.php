<?php
/** Tracy Business — ACM `tb-news`, layout `mega`: the dated list in the Resources megamenu plus "All resources →". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__) . '/_load.php'; // not _once: the closures must exist in EVERY layout's scope
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$catId = (int) $helper->get('source-category');
$items = $ngLoadNews($catId, max(1, (int) ($helper->get('count') ?: 5)));
if (!$items) return;
$allText = trim((string) $helper->get('all-text'));
?>
<ul class="tb-mega-news">
  <?php foreach ($items as $n) : ?>
    <li><a href="<?php echo $esc($n['url']); ?>"><span class="tb-mega-news__title"><?php echo $esc($n['title']); ?></span><time class="tb-mega-news__date" datetime="<?php echo $esc($n['datetime']); ?>"><?php echo $esc($n['date']); ?></time></a></li>
  <?php endforeach; ?>
</ul>
<?php if ($allText !== '') : ?><a class="tb-mega-news__all" href="<?php echo $esc($ngNewsCategoryUrl($catId)); ?>"><?php echo $esc($allText); ?></a><?php endif; ?>
