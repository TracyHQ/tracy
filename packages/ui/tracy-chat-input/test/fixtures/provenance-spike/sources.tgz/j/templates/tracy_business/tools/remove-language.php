<?php
/**
 * Remove a site language that add-language.php created — or any language whose content carries
 * the note `lang:<tag>` — and unpublish its content language. The language PACK stays installed
 * (it is 3 MB of strings and harmless); pass --uninstall-pack to remove it too.
 *
 *   php templates/tracy_business/tools/remove-language.php <tag> [--force] [--uninstall-pack] [--dry-run]
 *
 * Without --force it refuses a language whose rows do not all carry the note (a hand-built
 * language such as the original ru-RU): those rows were not made by the script and deleting them
 * is a content decision. With --force it deletes EVERY row of that language: articles, categories,
 * tags, contacts, menu items, menu types `tb-*-<sef>`, modules, their associations, the megamenu
 * block, the template strings and the override file. It never touches en-GB.
 */
declare(strict_types=1);
const _JEXEC = 1;
define('JPATH_BASE', dirname(__DIR__, 3));
require_once JPATH_BASE . '/includes/defines.php';
require_once JPATH_BASE . '/includes/framework.php';

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Table\Table;

$container = Factory::getContainer();
foreach (['session', 'JSession', \Joomla\CMS\Session\Session::class, \Joomla\Session\Session::class, \Joomla\Session\SessionInterface::class] as $alias) { $container->alias($alias, 'session.cli'); }
$app = $container->get(\Joomla\Console\Application::class);
Factory::$application = $app;
$app->createExtensionNamespaceMap();
(function () { $this->populateHttpHost(); })->call($app);
$db = $container->get(\Joomla\Database\DatabaseInterface::class);
$adminId = (int) $db->setQuery("SELECT MIN(u.id) FROM #__users u JOIN #__user_usergroup_map m ON m.user_id = u.id WHERE m.group_id = 8")->loadResult();
$app->loadIdentity($container->get(\Joomla\CMS\User\UserFactoryInterface::class)->loadUserById($adminId));

$args = array_slice($argv, 1);
$flag = static function (string $n) use (&$args): bool { $i = array_search($n, $args, true); if ($i === false) { return false; } array_splice($args, $i, 1); return true; };
$dry = $flag('--dry-run'); $force = $flag('--force'); $uninstall = $flag('--uninstall-pack');
$tag = $args[0] ?? '';
$log = static function (string $m): void { fwrite(STDOUT, $m . "\n"); };
$fail = static function (string $m): never { fwrite(STDERR, "remove-language: $m\n"); exit(1); };
if (!preg_match('/^[a-z]{2,3}-[A-Z]{2}$/', $tag)) { $fail('usage: remove-language.php <xx-YY> [--force] [--uninstall-pack] [--dry-run]'); }
if ($tag === 'en-GB') { $fail('en-GB is the base language of this site'); }
$quote = static fn ($v) => $db->quote((string) $v);
$note = "lang:$tag";
$T = JPATH_BASE . '/templates/tracy_business';
$sef = (string) $db->setQuery("SELECT sef FROM #__languages WHERE lang_code = " . $quote($tag))->loadResult();
$count = static fn (string $sql): int => (int) $db->setQuery($sql)->loadResult();

$rows = [
    'articles'   => ["#__content", "language = " . $quote($tag)],
    'categories' => ["#__categories", "language = " . $quote($tag) . " AND extension IN ('com_content','com_contact')"],
    'tags'       => ["#__tags", "language = " . $quote($tag) . " AND id > 1"],
    'contacts'   => ["#__contact_details", "language = " . $quote($tag)],
    'menu items' => ["#__menu", "client_id = 0 AND language = " . $quote($tag)],
    'modules'    => ["#__modules", "client_id = 0 AND language = " . $quote($tag)],
];
$noteCol = ['articles' => 'note', 'categories' => 'note', 'tags' => 'note', 'contacts' => 'misc', 'menu items' => 'note', 'modules' => 'note'];
$total = 0; $foreign = 0;
foreach ($rows as $what => [$table, $where]) {
    $n = $count("SELECT COUNT(*) FROM $table WHERE $where"); $own = $count("SELECT COUNT(*) FROM $table WHERE $where AND {$noteCol[$what]} = " . $quote($note));
    $total += $n; $foreign += $n - $own;
    $log(sprintf('%-11s %4d (%d carry %s)', $what, $n, $own, $note));
}
if ($total === 0 && $sef === '') { $fail("$tag has nothing on this site"); }
if ($foreign > 0 && !$force) { $fail("$foreign rows of $tag were not created by add-language (no `$note`); re-run with --force to delete every $tag row anyway"); }
if ($dry) { $log('[dry-run] nothing changed'); exit(0); }

// associations first (they point at the rows), then the rows, then the trees
$ids = static fn (string $table, string $where): array => array_map('intval', $db->setQuery("SELECT id FROM $table WHERE $where")->loadColumn());
foreach (['com_content.item' => $rows['articles'], 'com_categories.item' => $rows['categories'], 'com_menus.item' => $rows['menu items'], 'com_contact.item' => $rows['contacts']] as $ctx => [$table, $where]) {
    $list = $ids($table, $where); if (!$list) { continue; }
    // a group of two loses its meaning when one side goes; a group of three keeps the other two
    $keys = $db->setQuery("SELECT DISTINCT `key` FROM #__associations WHERE context = " . $quote($ctx) . " AND id IN (" . implode(',', $list) . ")")->loadColumn();
    $db->setQuery("DELETE FROM #__associations WHERE context = " . $quote($ctx) . " AND id IN (" . implode(',', $list) . ")")->execute();
    foreach ($keys as $k) { if ($count("SELECT COUNT(*) FROM #__associations WHERE context = " . $quote($ctx) . " AND `key` = " . $quote($k)) < 2) { $db->setQuery("DELETE FROM #__associations WHERE context = " . $quote($ctx) . " AND `key` = " . $quote($k))->execute(); } }
}
$arts = $ids('#__content', $rows['articles'][1]);
if ($arts) {
    $in = implode(',', $arts);
    $db->setQuery("DELETE FROM #__fields_values WHERE item_id IN ($in) AND field_id IN (SELECT id FROM #__fields WHERE context = 'com_content.article')")->execute();
    $db->setQuery("DELETE FROM #__contentitem_tag_map WHERE type_alias = 'com_content.article' AND content_item_id IN ($in)")->execute();
    $db->setQuery("DELETE FROM #__content_frontpage WHERE content_id IN ($in)")->execute();
    $db->setQuery("DELETE FROM #__workflow_associations WHERE extension = 'com_content.article' AND item_id IN ($in)")->execute();
    $db->setQuery("DELETE FROM #__ucm_content WHERE core_type_alias = 'com_content.article' AND core_content_item_id IN ($in)")->execute();
    $db->setQuery("DELETE FROM #__content WHERE id IN ($in)")->execute();
}
$mods = $ids('#__modules', $rows['modules'][1]);
if ($mods) { $db->setQuery("DELETE FROM #__modules_menu WHERE moduleid IN (" . implode(',', $mods) . ")")->execute(); $db->setQuery("DELETE FROM #__modules WHERE id IN (" . implode(',', $mods) . ")")->execute(); }
$db->setQuery("DELETE FROM #__contact_details WHERE " . $rows['contacts'][1])->execute();
$db->setQuery("DELETE FROM #__menu WHERE " . $rows['menu items'][1])->execute();
if ($sef !== '') { $db->setQuery("DELETE FROM #__menu_types WHERE menutype LIKE " . $quote('tb-%-' . $sef) . " AND client_id = 0 AND menutype NOT IN (SELECT DISTINCT menutype FROM #__menu WHERE client_id = 0)")->execute(); }
$tags = $ids('#__tags', $rows['tags'][1]);
if ($tags) { $db->setQuery("DELETE FROM #__contentitem_tag_map WHERE tag_id IN (" . implode(',', $tags) . ")")->execute(); $db->setQuery("DELETE FROM #__tags WHERE id IN (" . implode(',', $tags) . ")")->execute(); }
$db->setQuery("DELETE FROM #__categories WHERE " . $rows['categories'][1])->execute();
Table::getInstance('Category')->rebuild(); Table::getInstance('Menu')->rebuild(); (new \Joomla\Component\Tags\Administrator\Table\TagTable($db))->rebuild();
$db->setQuery("UPDATE #__languages SET published = 0 WHERE lang_code = " . $quote($tag))->execute();

// megamenu block, strings, overrides
$navFile = "$T/etc/navigation/tracy-business.json";
$nav = json_decode((string) file_get_contents($navFile), true);
$mega = json_decode((string) ($nav['mega_settings'] ?? '{}'), true) ?: [];
if ($sef !== '' && isset($mega["tb-main-$sef"])) { unset($mega["tb-main-$sef"]); $nav['mega_settings'] = json_encode($mega); file_put_contents($navFile, json_encode($nav, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); }
foreach (["$T/language/$tag", JPATH_BASE . "/language/$tag"] as $dir) { foreach (glob("$dir/$tag.tpl_tracy_business*.ini") ?: [] as $f) { @unlink($f); } }
@unlink(JPATH_BASE . "/language/overrides/$tag.override.ini");
if ($uninstall) {
    $pkg = (int) $db->setQuery("SELECT extension_id FROM #__extensions WHERE type = 'package' AND element = " . $quote('pkg_' . $tag))->loadResult();
    if ($pkg) { Installer::getInstance()->uninstall('package', $pkg); $log('pack uninstalled'); }
}
foreach (glob(JPATH_BASE . '/media/t4/optimize/*/*') as $f) { @unlink($f); }
$log("$tag removed: $total rows, content language unpublished, T4 cache cleared");
