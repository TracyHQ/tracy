<?php
/** Tracy Business — ACM `tb-cta-box`: the closing call-to-action box/band used on most inner pages. Tones: paper box · ink box · ink band · forest box. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$tone = in_array((string) $helper->get('tone'), ['paper','ink','ink-band','forest'], true) ? (string) $helper->get('tone') : 'paper';
$label = trim((string) $helper->get('label')); $title = trim((string) $helper->get('title')); $desc = trim((string) $helper->get('desc'));
$bt = trim((string) $helper->get('btn-text')); $bl = $route((string) $helper->get('btn-link')); $at = trim((string) $helper->get('alt-text')); $al = $route((string) $helper->get('alt-link'));
if ($title === '') return;
$id = 'tb-cta-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-cta-box tb-ctabox tb-ctabox--<?php echo $tone; ?>" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container">
    <div class="tb-ctabox__box">
      <div class="tb-ctabox__copy">
        <?php if ($label !== '') : ?><p class="tb-eyebrow"><?php echo $esc($label); ?></p><?php endif; ?>
        <h2 class="tb-ctabox__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
        <?php if ($desc !== '') : ?><p class="tb-ctabox__desc"><?php echo $esc($desc); ?></p><?php endif; ?>
      </div>
      <div class="tb-ctabox__actions">
        <?php if ($bt !== '' && $bl !== '') : ?><a class="tb-btn tb-btn--signal" href="<?php echo $esc($bl); ?>"><?php echo $esc($bt); ?></a><?php endif; ?>
        <?php if ($at !== '' && $al !== '') : ?><a class="tb-ctabox__alt" href="<?php echo $esc($al); ?>"><?php echo $esc($at); ?></a><?php elseif ($at !== '') : ?><span class="tb-ctabox__alt"><?php echo $esc($at); ?></span><?php endif; ?>
      </div>
    </div>
  </div>
</section>
