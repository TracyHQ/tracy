<?php

/**
 * Tracy Business — Smart Search result list: suggested/explained query, the empty state, the
 * hairline-separated rows and Joomla's pagination. The "Results X–Y of Z" counter is not drawn —
 * the page already states the total above the list.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

/** @var \Joomla\Component\Finder\Site\View\Search\HtmlView $this */
?>
<?php // the spelling suggestion is kept; Joomla's "x is required" explanation is not — the results line above already restates the query ?>
<?php if ($this->suggested && $this->params->get('show_suggested_query', 1)) : ?>
    <div id="search-query-explained" class="tb-search__explained">
        <?php $uri = Uri::getInstance($this->query->toUri()); $uri->setVar('q', $this->suggested); ?>
        <?php echo Text::sprintf('COM_FINDER_SEARCH_SIMILAR', '<a href="' . Route::_($uri->toString(['path', 'query'])) . '">' . $this->escape($this->suggested) . '</a>'); ?>
    </div>
<?php endif; ?>

<?php if (($this->total === 0) || ($this->total === null)) : ?>
    <div id="search-result-empty" class="tb-search__empty">
        <h2 class="tb-search__empty-title"><?php echo Text::_('COM_FINDER_SEARCH_NO_RESULTS_HEADING'); ?></h2>
        <?php $multilang = Factory::getApplication()->getLanguageFilter() ? '_MULTILANG' : ''; ?>
        <p><?php echo Text::sprintf('COM_FINDER_SEARCH_NO_RESULTS_BODY' . $multilang, $this->escape($this->query->input)); ?></p>
    </div>
    <?php return; ?>
<?php endif; ?>

<?php if (!empty($this->query->highlight) && $this->params->get('highlight_terms', 1)) : ?>
    <?php HTMLHelper::_('behavior.highlighter', $this->query->highlight); ?>
<?php endif; ?>

<span id="highlighter-start"></span>
<div class="search-results tb-results">
    <?php $this->baseUrl = Uri::getInstance()->toString(['scheme', 'host', 'port']); ?>
    <?php foreach ($this->results as $i => $result) : ?>
        <?php $this->result = &$result; $this->result->counter = $i + 1; ?>
        <?php echo $this->loadTemplate($this->getLayoutFile($this->result->layout)); ?>
    <?php endforeach; ?>
</div>
<span id="highlighter-end"></span>

<?php if ((int) $this->pagination->pagesTotal > 1) : ?>
    <nav class="tb-search__pagination" aria-label="<?php echo Text::_('JLIB_HTML_PAGINATION'); ?>">
        <?php echo $this->pagination->getPagesLinks(); ?>
    </nav>
<?php endif; ?>
