<?php
/** Tracy Business — ACM `tb-kit-assets`: BRAND ASSETS — a bordered sidebar box of name | meta rows. The source had no files behind these rows, so each renders as text unless a link is given. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('asset-title'); $i < $n; $i++) { $t = trim((string) $helper->get('asset-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('asset-meta', $i)), $route((string) $helper->get('asset-link', $i))]; }
if (!$rows) return;
$id = 'tb-kitassets-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-assets tb-kitside tb-kitbox tb-kitassets" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <?php if ($title !== '') : ?><h2 class="tb-kitside__title tb-kitbox__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-kitassets__list">
    <?php foreach ($rows as [$t, $m, $l]) : ?>
      <li class="tb-kitassets__row"><?php if ($l !== '') : ?><a class="tb-kitassets__name" href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><span class="tb-kitassets__name"><?php echo $esc($t); ?></span><?php endif; ?><?php if ($m !== '') : ?><span class="tb-kitassets__meta"><?php echo $esc($m); ?></span><?php endif; ?></li>
    <?php endforeach; ?>
  </ul>
</section>
