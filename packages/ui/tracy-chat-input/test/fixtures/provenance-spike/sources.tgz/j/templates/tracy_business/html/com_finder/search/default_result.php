<?php

/**
 * Tracy Business — one Smart Search result: an eyebrow with the item's own taxonomy (its category, or
 * its content type when it has no category), the title, the excerpt around the matched term, and
 * the grey URL line. Nothing here is typed in — the eyebrow is what the indexer stored.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Finder\Administrator\Indexer\Helper;
use Joomla\String\StringHelper;

/** @var \Joomla\Component\Finder\Site\View\Search\HtmlView $this */
$description = '';

if ($this->params->get('show_description', 1)) {
    $termLength = StringHelper::strlen($this->query->input);
    $descLength = $this->params->get('description_length', 255);
    $padLength  = $termLength < $descLength ? (int) floor(($descLength - $termLength) / 2) : 0;
    $full       = (!empty($this->result->summary) && !empty($this->result->body)) ? Helper::parse($this->result->summary . $this->result->body) : (string) $this->result->description;
    $pos        = $termLength ? StringHelper::strpos(StringHelper::strtolower($full), StringHelper::strtolower($this->query->input)) : false;
    $start      = ($pos && $pos > $padLength) ? $pos - $padLength : 0;
    $space      = StringHelper::strpos($full, ' ', $start > 0 ? $start - 1 : 0);
    $start      = ($space && $space < $pos) ? $space + 1 : $start;
    $description = HTMLHelper::_('string.truncate', StringHelper::substr($full, $start), $descLength, true);
    if ($start > 0 && $description !== '') $description = '…' . $description;
}

$taxonomies = $this->result->getTaxonomy();
$eyebrow    = '';
foreach (['Category', 'Type'] as $branch) {
    if (!empty($taxonomies[$branch])) { $eyebrow = (string) reset($taxonomies[$branch])->title; break; }
}
$href = $this->result->route ? Route::_($this->result->route) : '';
$shown = $this->params->get('show_url', 1) ? preg_replace('~^https?://~', '', $this->baseUrl . Route::_($this->result->cleanURL)) : '';
?>
<article class="result-item tb-result">
    <?php if ($eyebrow !== '' && $this->params->get('show_taxonomy', 1)) : ?><p class="tb-eyebrow tb-result__kind"><?php echo $this->escape($eyebrow); ?></p><?php endif; ?>
    <h3 class="result-title tb-result__title"><?php if ($href !== '') : ?><a href="<?php echo $href; ?>"><?php echo $this->result->title; ?></a><?php else : ?><?php echo $this->result->title; ?><?php endif; ?></h3>
    <?php if ($description !== '') : ?><p class="result-text tb-result__text"><?php echo $description; ?></p><?php endif; ?>
    <?php if ($shown !== '') : ?><p class="tb-result__url"><?php echo $this->escape($shown); ?></p><?php endif; ?>
</article>
