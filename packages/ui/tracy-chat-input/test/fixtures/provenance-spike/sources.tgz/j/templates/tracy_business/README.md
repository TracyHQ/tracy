# tracy_business — Joomla 6 / T4 template (demo content: Northgate Industrial)

**What this is.** A JoomlArt T4 template for industrial / B2B companies, built by Tracy from the
Northgate Industrial design system. Light and dark themes, 50 admin-editable content blocks
(JA ACM), English + Russian out of the box, twelve more Joomla language packs installed and ready
to enable, and an agent-ready setup: the Claude Cowork API door for reading/writing content, and
this template's own documentation under `docs/`.

**Stack.** Joomla 6.1 · T4 framework 2.5 · `mod_ja_acm` · `com_claudecowork` 0.15 · self-hosted
Archivo + Newsreader. Template version 1.0.0. Demo content is the Northgate Industrial site
(EN/RU); a customer replaces it with their own — the structure, blocks and design system stay.

## Where things run

| | Build copy (Tracy's workspace) | A customer site |
|---|---|---|
| Front | `http://127.0.0.1:8230/en/` · `/ru/` | `https://<host>/en/` |
| Admin | `http://127.0.0.1:8230/administrator/` | `https://<host>/administrator/` |
| Credentials | `private-credentials.json` in the workspace (not in the webroot, not in git) | set by the installer / the provisioner |
| API door token | same file, `claudecowork_token` | set by the provisioner; agents in a Tracy Cowork session never see it |

## How to change things

- **Content** (pages, blocks, menus, translations): a person uses the Admin; an agent uses the
  Cowork door — `docs/cowork-api.md`. No SQL, ever.
- **Design** (colours, type, spacing): tokens in `css/styles/tracy-business.css`, components in
  `scss/_tracy-business-*.scss` → compile → clear the T4 cache. `docs/design-system.md`,
  `docs/checks.md`.
- **A new page / project / article / menu entry / block**: `docs/recipes.md`.
- **A language**: `docs/languages.md` — `tools/add-language.php <tag>` / `remove-language.php`.
- **What exists right now** (every menu item, module, block, position): the generated
  `docs/site-map.md`, `inventory.md`, `blocks.md`, `positions.md`.

Agents start at `AGENTS.md` (thirteen rules). Everything under `docs/` and this file are denied
to the web by `.htaccess`.

## Status (2026-09-13)

- Localhost acceptance complete: 105 links / 98 pages × 4 viewports × 2 themes — 0 broken links,
  0 overflow, 0 console errors, 0 raw language keys; megamenu, drawer, search, dark toggle, EN↔RU
  switcher and admin edit round-trips verified. Report and evidence live in the build workspace
  (`evidence/REPORT.md`), not in this webroot.
- **Not yet packaged**: the Akeeba quickstart (`.jpa` + Kickstart), the clean-frame restore and the
  parity check are the next step. Do not treat this webroot as a release.
- **Open content decisions** the owner still has to make (figures that contradict each other in
  the source, missing PDFs and URLs, empty Terms/Privacy, the copyright line, mail sending):
  `docs/content-rules.md`. None were guessed.

## Hand-over checklist for a new maintainer

1. Read `AGENTS.md`, then `docs/checks.md` — run the door sanity call and the audit once before
   touching anything, so you know what green looks like.
2. Get the admin login and the door token from whoever provisioned the site; never from a doc.
3. Before a large change: `db.snapshot` through the door (or an Akeeba backup); after it: the
   checks in `docs/checks.md`, and regenerate the generated docs.

## Licence and credits

Template code GPL-3.0 (see `templateDetails.xml`). T4 framework and JA ACM by JoomlArt under
their licences. Fonts: Archivo and Newsreader (OFL, `fonts/`). Images under `images/northgate/`
belong to the demo design and are not licensed for reuse outside this site.
