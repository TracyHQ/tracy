<?php
/** Tracy Business — ACM `tb-page-cert-safety`: two columns — "Accreditations" as → rows on the left, a bordered paper-2 "Safety" box (H2 + paragraph + 16:9 image) on the right. About. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$st = trim((string) $helper->get('safety-title')); $sp = trim((string) $helper->get('safety-text')); $si = $img((string) $helper->get('safety-image')); $sa = trim((string) $helper->get('safety-alt'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-desc', $i))]; }
if (!$rows && $st === '') return;
$id = 'tb-pg-cert-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-cert-safety tb-pg-cert" id="<?php echo $id; ?>">
  <div class="tb-container tb-pg-cert__inner">
    <?php if ($rows) : ?>
      <div class="tb-pg-cert__list">
        <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm"><?php echo $esc($title); ?></h2><?php endif; ?>
        <ul class="tb-pg-cert__rows">
          <?php foreach ($rows as [$t, $d]) : ?><li class="tb-pg-cert__row"><span class="tb-pg-cert__arrow" aria-hidden="true">→</span><div><strong class="tb-pg-cert__title"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><span class="tb-pg-cert__desc"><?php echo $esc($d); ?></span><?php endif; ?></div></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
    <?php if ($st !== '') : ?>
      <div class="tb-pg-safety">
        <h2 class="tb-pg-h2 tb-pg-h2--xs"><?php echo $esc($st); ?></h2>
        <?php if ($sp !== '') : ?><p class="tb-pg-safety__text"><?php echo $esc($sp); ?></p><?php endif; ?>
        <?php if ($si !== '') : ?><figure class="tb-pg-safety__visual"><img src="<?php echo $esc($si); ?>" alt="<?php echo $esc($sa); ?>" loading="lazy" decoding="async"></figure><?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
