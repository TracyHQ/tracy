<?php
/** Tracy Business — ACM `tb-why`: "Why Tracy Business" — a 1:1 photo on the left, eyebrow + title + arrow list on the right. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$image = explode('#', trim((string) $helper->get('image')))[0];
if ($image !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $image)) $image = \Joomla\CMS\Uri\Uri::root(true) . '/' . $image;
$eyebrow = trim((string) $helper->get('eyebrow')); $title = trim((string) $helper->get('title'));
$items = [];
for ($i = 0, $n = (int) $helper->getRows('item-title'); $i < $n; $i++) {
    $t = trim((string) $helper->get('item-title', $i));
    if ($t !== '') $items[] = [$t, trim((string) $helper->get('item-desc', $i))];
}
$id = 'tb-why-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-why tb-section tb-why" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-why__grid">
    <?php if ($image !== '') : ?><figure class="tb-why__visual"><img src="<?php echo $esc($image); ?>" alt="<?php echo $esc((string) $helper->get('image-alt')); ?>" width="1024" height="1024" loading="lazy" decoding="async"></figure><?php endif; ?>
    <div class="tb-why__copy">
      <?php if ($eyebrow !== '') : ?><p class="tb-eyebrow"><?php echo $esc($eyebrow); ?></p><?php endif; ?>
      <h2 class="tb-section__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
      <ul class="tb-why__list">
        <?php foreach ($items as [$t, $d]) : ?>
          <li class="tb-why__item"><span class="tb-why__arrow" aria-hidden="true">→</span><div><strong class="tb-why__item-title"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><p class="tb-why__item-desc"><?php echo $esc($d); ?></p><?php endif; ?></div></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</section>
