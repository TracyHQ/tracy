<?php
/** Tracy Business — ACM `tb-page-downloads`: "Reports and presentations" — H2 and rows of title + meta line with a signal ↓. A row is a link only when a file is set; without one it is plain text, never a dead link. A column in a split row. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-meta', $i)), $img((string) $helper->get('row-file', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-page-downloads tb-pg-downloads" id="tb-pg-dl-<?php echo (int) $module->id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm tb-pg-downloads__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-pg-downloads__list">
    <?php foreach ($rows as [$t, $m, $f]) : $tag = $f !== '' ? 'a' : 'div'; ?>
      <li class="tb-pg-downloads__item"><<?php echo $tag; ?> class="tb-pg-downloads__row<?php echo $f === '' ? ' tb-pg-downloads__row--nofile' : ''; ?>"<?php if ($f !== '') : ?> href="<?php echo $esc($f); ?>" download<?php endif; ?>><div><strong class="tb-pg-downloads__name"><?php echo $esc($t); ?></strong><?php if ($m !== '') : ?><span class="tb-pg-downloads__meta"><?php echo $esc($m); ?></span><?php endif; ?></div><?php if ($f !== '') : ?><span class="tb-pg-downloads__arrow" aria-hidden="true">↓</span><?php endif; ?></<?php echo $tag; ?>></li>
    <?php endforeach; ?>
  </ul>
</div>
