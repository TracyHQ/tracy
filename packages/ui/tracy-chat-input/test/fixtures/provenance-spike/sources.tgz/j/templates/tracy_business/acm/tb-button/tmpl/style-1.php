<?php
/** Tracy Business — ACM `tb-button`: one call-to-action whose link goes through Route::_(), so an `index.php?Itemid=N` target stays correct under SEF and language prefixes. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc  = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$text = trim((string) $helper->get('text'));
$link = trim((string) $helper->get('link'));
if ($text === '' || $link === '') return;
if (!preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $link)) $link = \Joomla\CMS\Router\Route::_($link);
$style = in_array((string) $helper->get('style'), ['forest', 'signal', 'outline'], true) ? (string) $helper->get('style') : 'forest';
?>
<a class="tb-btn tb-btn--<?php echo $style; ?>" href="<?php echo $esc($link); ?>"><?php echo $esc($text); ?></a>
