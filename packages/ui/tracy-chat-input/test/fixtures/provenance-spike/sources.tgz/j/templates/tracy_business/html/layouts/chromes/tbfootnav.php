<?php

/**
 * Tracy Business — footer column chrome.
 *
 * A footer column is one module: its title is the uppercase column heading and its content is
 * the link list. The owner renames a column by renaming the module — no template edit.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

$module = $displayData['module'];
$params = $displayData['params'];

if (empty($module->content)) {
    return;
}

$sfx = $params->get('moduleclass_sfx') !== null ? htmlspecialchars((string) $params->get('moduleclass_sfx'), ENT_QUOTES, 'UTF-8') : '';
?>
<div class="tb-footcol<?php echo $sfx !== '' ? ' ' . $sfx : ''; ?>" id="Mod<?php echo (int) $module->id; ?>">
    <?php if ($module->showtitle) : ?>
        <h3 class="tb-footcol__title"><?php echo $module->title; ?></h3>
    <?php endif; ?>
    <?php echo $module->content; ?>
</div>
