# Design system — Northgate Industrial on `tracy_business`

Everything below was **measured on the customer's design** (its Style guide page and rendered
pages), not chosen. When a new page or block is needed, it is built from these parts; a value that
is not here is a value the design does not have. Live token file: `css/styles/tracy-business.css`.

## 1. Palette

Six named colours from the style guide, plus the greys the chrome actually uses.

| Token | Light | Dark | Role |
|---|---|---|---|
| `--tb-ink` | `#14171A` | `#ECEAE4` | text, ink bands |
| `--tb-forest` | `#14483A` | `#7FBFA6` | brand green: links, primary buttons, topbar (bands keep the deep light value) |
| `--tb-signal` | `#DA5A2A` | `#F0865A` | accent: active nav underline, process numbers, arrows, footer logo box |
| `--tb-paper` | `#F5F3EE` | `#101214` | page ground |
| `--tb-paper-2` | `#EDEAE2` | `#1C2023` | second surface: crumb band, cards on paper |
| `--tb-line` | `#DCD7CC` | `#2C3033` | borders |
| `--tb-ink-2/-3` | `#242830` / `#3D4045` | `#DDDAD3` / `#C7C4BD` | nav text, secondary headings |
| `--tb-muted`, `--tb-muted-2` | `#5A5952` / `#6B6A64` | `#A9A6A0` / `#96938C` | body copy on paper, ledes, captions |
| `--tb-meta`, `--tb-meta-2` | `#A8A49B` / `#B4AFA4` | `#807D77` / `#6E6B66` | dates, separators |
| `--tb-line-2`, `--tb-line-3` | `#E4DFD6` / `#C9C3B6` | `#24282B` / `#33383C` | soft border / panel bottom border |
| `--tb-chrome-bg` | `#F5F3EE` | `#15181A` | header, megamenu panel, language menu |
| `--tb-ink-band` (+ `-text -meta -chip -line -line-2 -line-3`) | `#14171A` … | `#0A0C0D` … | footer and hero band |
| `--tb-band-forest-bg/-fg` | `#14483A` / `#CFE0D8` | **unchanged in dark** | topbar, CTA button, logo box |
| semantic `--tb-info/success/warn/danger-bg/-fg` | style guide §5 | remapped | Joomla system messages |

Generic roles every component reads: `--bg`, `--surface` (Paper 2), `--surface-warm` (white),
`--fg`, `--fg-2`, `--muted`, `--meta`, `--border`, `--border-soft`, `--accent` (Forest),
`--accent-on`, `--accent-hover` (Signal), `--accent-active`.

**Rules.** Bands keep their measured colours in both themes: topbar, CTA button and the header logo
box stay deep forest; the footer only goes a shade darker; the active-nav underline stays Signal.
Links and hovers on the page ground go mint (`#7FBFA6`) in dark. No colour outside this table.

## 2. Type

| Token | Value | Use |
|---|---|---|
| `--font-display` | **Newsreader** (self-hosted, 400) | H1, H2, stats values, pull quotes — **content only, never chrome** |
| `--font-body` | **Archivo** (self-hosted 400/500/600/700) | everything else, including nav, buttons, footer, drawer |
| `--text-3xl` | 52px (36 phone) | H1, `letter-spacing -.028em`, `line-height 1.08`, weight 400 |
| `--text-2xl` | 40px (30 phone) | H2 section titles |
| `--text-xl` | 28px | H3 display |
| `--text-lg` | 20px | H3 body |
| `--text-base` | 17.5px, `line-height 1.72` | body, ledes (lede colour `--muted`, max 44em) |
| `--text-sm` | 13px | meta, breadcrumbs (13.5), footer |
| `--text-xs` | 12px, `letter-spacing .18em`, uppercase | eyebrows (`.tb-eyebrow`, Signal) |
| stats value | Newsreader 36 (30 phone) | `.tb-stats__value` |
| nav link | Archivo 14.5 / 500, active 600 + 2px Signal underline | header |

Fonts are shipped in `fonts/` and declared in `css/tracy-business-fonts.css` — no CDN, no Google Fonts.

## 3. Space and shape

- Container `--container-max: 1240px`, gutters 32 / 24 / 20 px (desktop / tablet / phone) — `.tb-container`.
- Section rhythm `--section-y-*`: **72 / 56 / 40** px. Page intro (H1 + lede) `48px 0 40px` (32/28 phone).
- Spacing scale `--space-1…12`: 4 8 12 16 20 24 32 48.
- **No rounded corners anywhere** (`--radius-*: 0`). No drop shadows on content; `--elev-raised` only
  for the megamenu panel and the language menu. Borders are 1px `--border`.
- Chrome: topbar 36px (Forest), header 85px, nav row ends 26px above the header's bottom edge,
  megamenu panel full-width under the header, footer on the ink band. Breakpoints: desktop nav
  ≥ 992px, drawer below; grids collapse at `md` (768).
- Motion: `--motion-fast 150ms`, `--motion-base 220ms`, `--ease-standard`. Nothing animates on scroll.

## 4. Bands (section backgrounds)

| Band | Class / tone | Ground | Text | Where |
|---|---|---|---|---|
| Paper | default | `--bg` | `--fg` / `--muted` | most sections |
| Paper 2 | `.tb-block--paper2`, tone `paper` | `--surface` | `--fg` | crumb band, cards, CTA box (paper) |
| Ink | `.tb-block--ink`, `.tb-stats--ink`, tone `ink` / `ink-band` | `--tb-ink-band` | `#F5F3EE` / `#96938C`, lines `#2C3033` | hero, footer, stats strip, dark CTA box |
| Forest | tone `forest` | `--tb-band-forest-bg` | `#CFE0D8` / white | topbar, CTA band, newsletter signup |

Ink-band literals (`#F5F3EE`, `#2C3033`, `#96938C`) are the only hex values allowed in component
SCSS — they are the band's own constants and do not flip. There is no fifth band: a block that
seems to need one (a warning band, a tinted highlight) is a block the design does not have — ask.

## 5. Components (classes you reuse — `scss/_tracy-business-shared.scss`, `_tracy-business-home.scss`)

| Class | What it is |
|---|---|
| `.tb-section` + `__head`, `__title` | section wrapper with eyebrow + H2 head |
| `.tb-eyebrow` | 12px uppercase Signal label |
| `.tb-btn--signal` / `--forest` / `--outline` / `--outline-light` | the four buttons (37px tall, no radius) |
| `.tb-textlink` | inline link with underline |
| `.tb-chips .tb-chip(.is-active)` | filter chips (Projects, News, Careers) |
| `.tb-pcard`, `.tb-ncard` | project card, news card (16:9 image, meta, title) |
| `.tb-stats` (`--box`, `--ink`, `__grid--4/3/6`) | stats strip |
| `.tb-ctabox` (`--paper`, `--ink`, `--ink-band`, `--forest`) | CTA box / band with title, text, button, alt link |
| `.tb-process` | numbered 01…0N steps |
| `.tb-arrows` | `→` rows with title + description |
| `.tb-split` | two-column row for two blocks |
| `.tb-pageintro` (`--image`) | H1 + lede (+ 16:10 image) under the crumb band |
| `.tb-crumbband`, `.tb-crumbs` | breadcrumb band |

Each of these is exposed as an ACM block (`docs/blocks.md`) — build pages from blocks, reach for
the classes only inside a new block's PHP.

## 6. Images

Frames from style guide §7: **16:9** cover for projects/news, **logo frame** white ground contain,
**circular** for portraits. Only images under `images/northgate/` (49 files) are on the site; the
design ships the RU-labelled map and slide thumbnails for both languages. No stock photos.

## 7. Don'ts (each one was measured as absent in the design)

- No border-radius, no box-shadow on cards/buttons, no gradients, no icons in the megamenu.
- No Newsreader in the header, topbar, footer, buttons, or drawer.
- No colour, font size or spacing that is not a token above.
- No `@media` other than the template breakpoints (992 desktop nav, 768 grid collapse, 576).
- No inline `style=` for colour — the design's own dark mode was inline-style lookups and that is
  exactly what was replaced by tokens; reintroducing inline colours silently loses dark mode.
