<?php
/** Tracy Business — ACM `tb-stats-strip`: N cells of value + label, divided by hairlines. `box` = bordered box on paper (About/Services/Careers/IR), `ink` = dark band. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$title = trim((string) $helper->get('title')); $tone = (string) $helper->get('tone') === 'ink' ? 'ink' : 'box'; $cols = in_array((string) $helper->get('columns'), ['3','4','6'], true) ? (string) $helper->get('columns') : '4';
$cells = [];
for ($i = 0, $n = (int) $helper->getRows('value'); $i < $n; $i++) { $v = trim((string) $helper->get('value', $i)); $l = trim((string) $helper->get('label', $i)); if ($v !== '' || $l !== '') $cells[] = [$v, $l]; }
if (!$cells) return;
$id = 'tb-stats-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-stats-strip tb-stats tb-stats--<?php echo $tone; ?>" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-section__title tb-stats__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <dl class="tb-stats__grid tb-stats__grid--<?php echo $cols; ?>">
      <?php foreach ($cells as [$v, $l]) : ?><div class="tb-stats__cell"><dt class="tb-stats__value"><?php echo $esc($v); ?></dt><dd class="tb-stats__label"><?php echo $esc($l); ?></dd></div><?php endforeach; ?>
    </dl>
  </div>
</section>
