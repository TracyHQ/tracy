<?php
/**
 * Tracy Business — shared loader for the `tb-projects` layouts: the newest published articles of a
 * category (and its children), each with its category name, year, intro image and route.
 */
defined('_JEXEC') or die;

$ngLoadProjects = static function (int $categoryId, int $limit, array $selected = []): array {
    if ($categoryId <= 0 && !$selected) return [];
    $app   = \Joomla\CMS\Factory::getApplication();
    $model = $app->bootComponent('com_content')->getMVCFactory()->createModel('Articles', 'Site', ['ignore_request' => true]);
    $model->setState('params', clone \Joomla\CMS\Component\ComponentHelper::getParams('com_content'));
    $model->setState('filter.category_id', $categoryId); // scalar: the model only walks sub-categories for a scalar id
    $model->setState('filter.subcategories', true);
    $model->setState('filter.max_category_levels', 2);
    $model->setState('filter.published', 1);
    $model->setState('filter.access', true);
    $model->setState('filter.language', $app->getLanguageFilter());
    $model->setState('list.start', 0);
    $model->setState('list.limit', $selected ? count($selected) : $limit);
    $model->setState('list.ordering', 'a.ordering');
    $model->setState('list.direction', 'ASC');
    if ($selected) { $model->setState('filter.article_id', $selected); $model->setState('filter.category_id', null); $model->setState('filter.subcategories', false); }
    $items = $model->getItems();
    if ($selected) { // keep the admin's order
        $byId = []; foreach ($items as $a) $byId[(int) $a->id] = $a; $items = []; foreach ($selected as $sid) if (isset($byId[$sid])) $items[] = $byId[$sid];
    }
    $out = [];
    foreach ($items as $a) {
        $images = json_decode((string) $a->images, true) ?: [];
        $img = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($images['image_intro'] ?? '');
        if ($img === '') $img = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($images['image_fulltext'] ?? '');
        if ($img !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $img)) $img = \Joomla\CMS\Uri\Uri::root(true) . '/' . $img;
        $out[] = [
            'id'       => (int) $a->id,
            'title'    => $a->title,
            'intro'    => trim(strip_tags((string) $a->introtext)),
            'category' => $a->category_title,
            'year'     => \Joomla\CMS\HTML\HTMLHelper::_('date', $a->publish_up ?: $a->created, 'Y'),
            'image'    => $img,
            'alt'      => (string) ($images['image_intro_alt'] ?? $a->title),
            'url'      => \Joomla\CMS\Router\Route::_(\Joomla\Component\Content\Site\Helper\RouteHelper::getArticleRoute($a->id . ':' . $a->alias, $a->catid, $a->language)),
        ];
    }
    return $out;
};

$ngCategoryUrl = static fn (int $id): string => \Joomla\CMS\Router\Route::_(\Joomla\Component\Content\Site\Helper\RouteHelper::getCategoryRoute($id));

$ngChildCategories = static function (int $parentId): array {
    $db = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
    $q  = $db->getQuery(true)->select('id, title')->from('#__categories')
        ->where('parent_id = ' . (int) $parentId)->where('published = 1')->where("extension = 'com_content'")->order('lft');
    return $db->setQuery($q)->loadAssocList() ?: [];
};

// The multi-select field stores an array; the ACM getter assumes scalar text, so read it raw.
$ngSelectedIds = static function ($module, string $type, string $field): array {
    $cfg = json_decode((string) $module->params, true) ?: [];
    $data = json_decode($cfg['jatools-config'] ?? '{}', true) ?: [];
    $raw = (array) ($data[$type][$type . '[' . $field . ']'] ?? []);
    $ids = [];
    array_walk_recursive($raw, static function ($v) use (&$ids) { foreach (explode(',', (string) $v) as $id) if (ctype_digit(trim($id)) && (int) $id > 0) $ids[] = (int) $id; });
    return array_values(array_unique($ids));
};
