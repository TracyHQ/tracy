<?php

/**
 * Tracy Business — mod_articles_categories, `northgate_items`: one row per category (name · count).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$input  = $app->getInput();
$active = $input->getCmd('option') === 'com_content' && in_array($input->getCmd('view'), ['category', 'categories'], true) ? $input->getInt('id') : 0;
$esc    = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

foreach ($list as $item) : ?>
    <li<?php echo $active === (int) $item->id ? ' class="is-active"' : ''; ?>>
        <a class="tb-siderows__row" href="<?php echo $esc(Route::_(RouteHelper::getCategoryRoute($item->id, $item->language))); ?>">
            <span><?php echo $esc($item->title); ?></span>
            <?php if ($params->get('numitems')) : ?><span class="tb-siderows__aux"><?php echo (int) $item->numitems; ?></span><?php endif; ?>
        </a>
    </li>
<?php endforeach; ?>
