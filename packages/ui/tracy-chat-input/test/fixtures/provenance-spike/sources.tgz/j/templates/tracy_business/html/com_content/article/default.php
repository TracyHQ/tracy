<?php

/**
 * Tracy Business — generic content page (com_content article, default layout).
 *
 * The design's "page-intro" pattern: an H1 in Newsreader with a one-line lede underneath, then
 * the body. Pages that are stacks of sections keep their body as `{loadposition <page>-page}`
 * so every section stays an admin-editable module. Projects and news articles use their own
 * alternative layouts (tb-project / tb-article); this file is the plain page.
 *
 * The intro text is the lede. Breadcrumbs are the `breadcrumbs` module position, not this view.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;

$params  = $this->item->params;
$esc     = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$canEdit = $params->get('access-edit');
// The view ran the content plugins on `$item->text` (intro + full joined), not on the two raw
// fields — so `{loadposition <page>-page}` in `fulltext` must be prepared here or it prints as text.
$lede    = trim((string) HTMLHelper::_('content.prepare', (string) $this->item->introtext, '', 'com_content.article'));
$body    = trim((string) HTMLHelper::_('content.prepare', (string) $this->item->fulltext, '', 'com_content.article'));
$images  = json_decode((string) $this->item->images) ?: new stdClass();
$image   = HTMLHelper::_('cleanImageURL', $images->image_fulltext ?? '')->url ?? '';
$eyebrow = trim((string) ($this->item->metadata->get('ng_eyebrow') ?? ''));
?>
<article class="tb-page" itemscope itemtype="https://schema.org/WebPage">
    <?php if ($canEdit) : ?>
        <div class="tb-page__edit"><?php echo LayoutHelper::render('joomla.content.icons', ['params' => $params, 'item' => $this->item, 'print' => false]); ?></div>
    <?php endif; ?>

    <header class="tb-pageintro<?php echo $image !== '' ? ' tb-pageintro--image' : ''; ?>">
        <div class="tb-container tb-pageintro__inner">
            <div class="tb-pageintro__copy">
                <?php if ($eyebrow !== '') : ?><p class="tb-eyebrow"><?php echo $esc($eyebrow); ?></p><?php endif; ?>
                <?php if ($params->get('show_title')) : ?>
                    <h1 class="tb-pageintro__title" itemprop="headline"><?php echo $esc($this->item->title); ?></h1>
                <?php endif; ?>
                <?php if ($lede !== '') : ?><div class="tb-pageintro__lede" itemprop="description"><?php echo $lede; ?></div><?php endif; ?>
            </div>
            <?php if ($image !== '') : ?>
                <figure class="tb-pageintro__visual"><img src="<?php echo $esc($image); ?>" alt="<?php echo $esc($images->image_fulltext_alt ?? ''); ?>" loading="eager" decoding="async"></figure>
            <?php endif; ?>
        </div>
    </header>

    <?php if ($body !== '') : ?>
        <div class="tb-page__body" itemprop="articleBody">
            <?php echo $body; ?>
        </div>
    <?php endif; ?>
</article>
