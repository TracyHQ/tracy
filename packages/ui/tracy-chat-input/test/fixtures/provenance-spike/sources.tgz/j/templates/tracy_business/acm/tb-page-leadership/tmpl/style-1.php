<?php
/** Tracy Business — ACM `tb-page-leadership`: ink band, H2 and a row of people cards — 1:1 photo, name, role in signal, one line. A person without a photo gets a labelled empty frame, never a stand-in picture. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$people = [];
for ($i = 0, $n = (int) $helper->getRows('name'); $i < $n; $i++) { $nm = trim((string) $helper->get('name', $i)); if ($nm !== '') $people[] = [$img((string) $helper->get('photo', $i)), $nm, trim((string) $helper->get('role', $i)), trim((string) $helper->get('bio', $i))]; }
if (!$people) return;
$id = 'tb-pg-lead-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-leadership tb-pg-band tb-pg-band--ink tb-pg-lead" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <ul class="tb-pg-lead__grid">
      <?php foreach ($people as [$p, $nm, $r, $b]) : ?>
        <li class="tb-pg-lead__card">
          <?php if ($p !== '') : ?><div class="tb-pg-lead__photo"><img src="<?php echo $esc($p); ?>" alt="<?php echo $esc($nm); ?>" loading="lazy" decoding="async"></div>
          <?php else : ?><div class="tb-pg-lead__photo tb-pg-lead__photo--empty" aria-hidden="true"><span><?php echo $esc($nm); ?></span></div><?php endif; ?>
          <strong class="tb-pg-lead__name"><?php echo $esc($nm); ?></strong>
          <?php if ($r !== '') : ?><span class="tb-pg-lead__role"><?php echo $esc($r); ?></span><?php endif; ?>
          <?php if ($b !== '') : ?><p class="tb-pg-lead__bio"><?php echo $esc($b); ?></p><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>
