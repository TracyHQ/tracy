<?php
/**
 * Tracy Business — ACM `tb-page-roles`: paper-2 band, H2 "Open roles", filter chips (the sub-categories
 * of the Vacancies category = departments, each a real category route) and the roles list read
 * from the category — one article per role: title, department = its category, custom fields
 * `location`, `salary`, `type`. Four columns from md up, stacked cards below. The footer link
 * appears only when the category holds more roles than the block lists.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__) . '/_load.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = $ngPageEsc;
$title = trim((string) $helper->get('title')); $catId = (int) $helper->get('source-category'); $count = max(1, (int) ($helper->get('count') ?: 6));
$allText = trim((string) $helper->get('all-text')); $applyText = trim((string) $helper->get('apply-text')); $moreText = trim((string) $helper->get('more-text'));
$items = $ngPageArticles($catId, $count, true);
if (!$items) return;
$fields = $ngPageFields(array_map(static fn ($a) => (int) $a->id, $items), ['location', 'salary', 'type']);
$mail = $ngPageCategoryParam($catId, 'ng_apply_mail');
$roles = [];
foreach ($items as $a) {
    $f = $fields[(int) $a->id] ?? [];
    $roles[] = ['title' => $a->title, 'dept' => (int) $a->catid === $catId ? '' : $a->category_title, 'type' => (string) ($f['type'] ?? ''), 'city' => (string) ($f['location'] ?? ''), 'pay' => (string) ($f['salary'] ?? ''),
        'url' => $ngPageApplyUrl($mail, (string) $a->title)];
}
$children = $ngPageChildCategories($catId);
$allUrl = $ngPageCategoryUrl($catId);
$total = $ngPageCount($catId, true);
$id = 'tb-pg-roles-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-roles tb-pg-band tb-pg-band--paper2 tb-pg-roles" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-roles__heading" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <?php if ($children) : ?>
      <nav class="tb-chips tb-pg-roles__chips" aria-label="<?php echo $esc($title); ?>">
        <a class="tb-chip is-active" href="<?php echo $esc($allUrl); ?>" aria-current="true"><?php echo $esc($allText !== '' ? $allText : \Joomla\CMS\Language\Text::_('TPL_TRACY_BUSINESS_ACM_FILTER_ALL')); ?></a>
        <?php foreach ($children as $c) : ?><a class="tb-chip" href="<?php echo $esc($ngPageCategoryUrl((int) $c['id'])); ?>"><?php echo $esc($c['title']); ?></a><?php endforeach; ?>
      </nav>
    <?php endif; ?>
    <div class="tb-pg-roles__box">
      <?php echo $ngPageRolesList($roles, $applyText); ?>
      <?php if ($moreText !== '' && $total > count($roles)) : ?><div class="tb-pg-roles__foot"><a class="tb-textlink" href="<?php echo $esc($allUrl); ?>"><?php echo $esc($moreText); ?></a></div><?php endif; ?>
    </div>
  </div>
</section>
