<?php

/**
 * Tracy Business — mod_articles_categories, layout `northgate`: the "Categories" sidebar box on News.
 * Box label = the module title; one row per category, article count on the right.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

if (empty($list)) {
    return;
}
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<nav class="tb-sidebox tb-sidecats" aria-labelledby="tb-sidecats-<?php echo (int) $module->id; ?>">
    <?php if ($module->showtitle && trim((string) $module->title) !== '') : ?>
        <p class="tb-sidebox__label" id="tb-sidecats-<?php echo (int) $module->id; ?>"><?php echo $esc($module->title); ?></p>
    <?php endif; ?>
    <ul class="tb-siderows">
        <?php require ModuleHelper::getLayoutPath('mod_articles_categories', $params->get('layout', 'default') . '_items'); ?>
    </ul>
</nav>
