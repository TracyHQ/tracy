<?php
/** Tracy Business — ACM `tb-clients`: an uppercase label and a row of white logo frames (fit contain). */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$logos = [];
for ($i = 0, $n = (int) $helper->getRows('logo'); $i < $n; $i++) {
    $src = explode('#', trim((string) $helper->get('logo', $i)))[0];
    if ($src === '') continue;
    if (!preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $src)) $src = \Joomla\CMS\Uri\Uri::root(true) . '/' . $src;
    $logos[] = [$src, trim((string) $helper->get('logo-alt', $i))];
}
if (!$logos) return;
$id = 'tb-clients-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-clients tb-clients" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-clients__inner">
    <p class="tb-eyebrow tb-clients__title" id="<?php echo $id; ?>-title"><?php echo $esc((string) $helper->get('title')); ?></p>
    <ul class="tb-clients__row">
      <?php foreach ($logos as [$src, $alt]) : ?><li class="tb-clients__frame"><img src="<?php echo $esc($src); ?>" alt="<?php echo $esc($alt); ?>" loading="lazy" decoding="async"></li><?php endforeach; ?>
    </ul>
  </div>
</section>
