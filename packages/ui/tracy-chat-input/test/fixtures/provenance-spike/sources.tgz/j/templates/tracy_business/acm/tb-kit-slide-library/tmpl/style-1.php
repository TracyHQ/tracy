<?php
/**
 * Tracy Business — ACM `tb-kit-slide-library`: SLIDE LIBRARY — a 3-column grid of numbered 16:9
 * thumbnails, each drawn in CSS after the design's eight slide kinds, with title, one line and
 * "Use this slide →" linking to #page=N of one PDF deck.
 *
 * The drawn content inside the thumbnails (Завод «Электра», СОДЕРЖАНИЕ, ЭТАПЫ, …) is a picture of a
 * real Russian deck in the source on BOTH language builds — a fixture, not UI copy — and stays
 * verbatim here. The link is rendered only when the deck file exists on disk.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$media = static function (string $v): string { $v = explode('#', trim($v))[0]; if ($v === '') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $v) ? $v : \Joomla\CMS\Uri\Uri::root(true) . '/' . $v; };
$fileUrl = static function (string $path): string {
    $path = ltrim(trim($path), '/');
    if ($path === '' || !is_file(JPATH_ROOT . '/' . $path)) return '';
    return \Joomla\CMS\Uri\Uri::root(true) . '/' . implode('/', array_map('rawurlencode', explode('/', $path)));
};
$title = trim((string) $helper->get('title')); $hint = trim((string) $helper->get('hint')); $use = trim((string) $helper->get('use-text'));
$deck = $fileUrl((string) $helper->get('deck'));
$kinds = ['cover', 'agenda', 'stats', 'case', 'process', 'quote', 'map', 'contact'];
$slides = [];
for ($i = 0, $n = (int) $helper->getRows('slide-title'); $i < $n; $i++) {
    $t = trim((string) $helper->get('slide-title', $i)); if ($t === '') continue;
    $k = (string) $helper->get('slide-kind', $i);
    $slides[] = ['num' => trim((string) $helper->get('slide-num', $i)) ?: sprintf('%02d', count($slides) + 1), 'title' => $t, 'desc' => trim((string) $helper->get('slide-desc', $i)),
        'kind' => in_array($k, $kinds, true) ? $k : 'cover', 'image' => $media((string) $helper->get('slide-image', $i))];
}
if (!$slides) return;
$id = 'tb-kitslides-' . (int) $module->id;
$thumb = static function (array $s) use ($esc): string {
    switch ($s['kind']) {
        case 'cover':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--cover"><div class="tb-kitslide__brand"><span class="tb-kitslide__mark">{site.monogram}</span><span>{site.name}</span></div><div><span class="tb-kitslide__rule"></span><div class="tb-kitslide__h">Завод «Электра»</div><div class="tb-kitslide__sub">ОЭЗ «Липецк» · 2025</div></div></div>';
        case 'agenda':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--agenda"><div class="tb-kitslide__eyebrow">Содержание</div><div class="tb-kitslide__rows"><div><span>01</span><i></i></div><div><span>02</span><i></i></div><div><span>03</span><i style="width:70%"></i></div><div><span>04</span><i style="width:55%"></i></div></div></div>';
        case 'stats':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--stats"><div><b>380+</b><small>объектов</small></div><div><b>1,2 млн</b><small>м² построено</small></div><div><b>22</b><small>года опыта</small></div><div class="is-forest"><b>0</b><small>происшествий</small></div></div>';
        case 'case':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--case">' . ($s['image'] !== '' ? '<div class="tb-kitslide__photo"><img src="' . $esc($s['image']) . '" alt="" loading="lazy" decoding="async"></div>' : '<div class="tb-kitslide__photo"></div>') . '<div class="tb-kitslide__case"><div class="tb-kitslide__eyebrow">Кейс</div><div class="tb-kitslide__case-h">62 000 м² под ключ</div><i></i><i style="width:80%"></i><i style="width:60%"></i></div></div>';
        case 'process':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--process"><div class="tb-kitslide__eyebrow">Этапы</div><div class="tb-kitslide__line"><span class="is-done"></span><i></i><span class="is-done"></span><i></i><span class="is-now"></span><i></i><span class="is-todo"></span></div><div class="tb-kitslide__ticks"><span>Проект</span><span>Каркас</span><span>Кровля</span><span>Сдача</span></div></div>';
        case 'quote':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--quote"><div class="tb-kitslide__q">«График не сдвинулся ни на один день»</div><div class="tb-kitslide__sub">С. Трофимов · Начальник отдела КЖ/КМ</div></div>';
        case 'map':
            return '<div class="tb-kitslide__draw tb-kitslide__draw--map">' . ($s['image'] !== '' ? '<img src="' . $esc($s['image']) . '" alt="" loading="lazy" decoding="async">' : '') . '</div>';
        case 'contact':
        default:
            return '<div class="tb-kitslide__draw tb-kitslide__draw--contact"><div class="tb-kitslide__h">Обсудим ваш объект?</div><div class="tb-kitslide__sub">{contact.email} · {contact.phone}</div><span class="tb-kitslide__cta">Запросить смету</span></div>';
    }
};
?>
<section class="ja-acm acm-tb-kit-slide-library tb-kitlib" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '' || $hint !== '') : ?>
      <header class="tb-section__head tb-kitlib__head">
        <?php if ($title !== '') : ?><h2 class="tb-section__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
        <?php if ($hint !== '') : ?><p class="tb-kitlib__hint"><?php echo $esc($hint); ?></p><?php endif; ?>
      </header>
    <?php endif; ?>
    <ol class="tb-kitlib__grid">
      <?php foreach ($slides as $i => $s) : $page = (int) $s['num'] ?: $i + 1; $href = $deck !== '' ? $deck . '#page=' . $page : ''; ?>
        <li class="tb-kitslide tb-kitslide--<?php echo $s['kind']; ?>">
          <?php if ($href !== '') : ?><a class="tb-kitslide__frame" href="<?php echo $esc($href); ?>" target="_blank" rel="noopener" aria-label="<?php echo $esc($s['title']); ?>"><?php else : ?><div class="tb-kitslide__frame"><?php endif; ?>
            <?php echo $thumb($s); ?>
            <span class="tb-kitslide__num"><?php echo $esc($s['num']); ?></span>
          <?php echo $href !== '' ? '</a>' : '</div>'; ?>
          <h3 class="tb-kitslide__title"><?php echo $esc($s['title']); ?></h3>
          <?php if ($s['desc'] !== '') : ?><p class="tb-kitslide__desc"><?php echo $esc($s['desc']); ?></p><?php endif; ?>
          <?php if ($use !== '') : ?><?php if ($href !== '') : ?><a class="tb-kitslide__use" href="<?php echo $esc($href); ?>" target="_blank" rel="noopener"><?php echo $esc($use); ?></a><?php else : ?><span class="tb-kitslide__use"><?php echo $esc($use); ?></span><?php endif; ?><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>
