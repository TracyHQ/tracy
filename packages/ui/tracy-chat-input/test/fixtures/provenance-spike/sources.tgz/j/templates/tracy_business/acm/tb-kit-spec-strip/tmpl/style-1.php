<?php
/** Tracy Business — ACM `tb-kit-spec-strip`: the Slide page's bordered strip of N cells — small-caps label over a bold value (FORMAT · FONTS · GRID · MIN TYPE). Unlike `tb-stats-strip` the value is body-size, not a display figure. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$cells = [];
for ($i = 0, $n = (int) $helper->getRows('key'); $i < $n; $i++) { $k = trim((string) $helper->get('key', $i)); $v = trim((string) $helper->get('value', $i)); if ($k !== '' || $v !== '') $cells[] = [$k, $v]; }
if (!$cells) return;
?>
<div class="ja-acm acm-tb-kit-spec-strip tb-kitstrip" id="tb-kitstrip-<?php echo (int) $module->id; ?>">
  <div class="tb-container">
    <dl class="tb-kitstrip__grid">
      <?php foreach ($cells as [$k, $v]) : ?><div class="tb-kitstrip__cell"><dt class="tb-kitstrip__key"><?php echo $esc($k); ?></dt><dd class="tb-kitstrip__val"><?php echo $esc($v); ?></dd></div><?php endforeach; ?>
    </dl>
  </div>
</div>
