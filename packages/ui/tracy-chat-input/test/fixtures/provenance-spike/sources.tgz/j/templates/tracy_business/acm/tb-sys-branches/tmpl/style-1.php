<?php
/** Tracy Business — ACM `tb-sys-branches`: bordered box, eyebrow, hairline-separated city + address rows. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('city'); $i < $n; $i++) { $c = trim((string) $helper->get('city', $i)); if ($c !== '') $rows[] = [$c, trim((string) $helper->get('addr', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-sys-branches tb-sysbox tb-branches">
  <?php if ($title !== '') : ?><p class="tb-sysbox__eyebrow"><?php echo $esc($title); ?></p><?php endif; ?>
  <ul class="tb-branches__list">
    <?php foreach ($rows as [$c, $a]) : ?><li class="tb-branches__row"><strong class="tb-branches__city"><?php echo $esc($c); ?></strong><?php if ($a !== '') : ?><span class="tb-branches__addr"><?php echo $esc($a); ?></span><?php endif; ?></li><?php endforeach; ?>
  </ul>
</div>
