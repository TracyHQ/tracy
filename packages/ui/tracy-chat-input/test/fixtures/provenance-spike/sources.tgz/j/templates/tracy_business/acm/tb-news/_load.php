<?php
/** Tracy Business — shared loader for `tb-news`: newest published articles of a category, newest first. */
defined('_JEXEC') or die;
$ngLoadNews = static function (int $categoryId, int $limit): array {
    if ($categoryId <= 0) return [];
    $app   = \Joomla\CMS\Factory::getApplication();
    $model = $app->bootComponent('com_content')->getMVCFactory()->createModel('Articles', 'Site', ['ignore_request' => true]);
    $model->setState('params', clone \Joomla\CMS\Component\ComponentHelper::getParams('com_content'));
    $model->setState('filter.category_id', $categoryId); // scalar: the model only walks sub-categories for a scalar id
    $model->setState('filter.subcategories', true);
    $model->setState('filter.max_category_levels', 2);
    $model->setState('filter.published', 1);
    $model->setState('filter.access', true);
    $model->setState('filter.language', $app->getLanguageFilter());
    $model->setState('list.start', 0);
    $model->setState('list.limit', $limit);
    $model->setState('list.ordering', 'a.publish_up');
    $model->setState('list.direction', 'DESC');
    $out = [];
    foreach ($model->getItems() as $a) {
        $images = json_decode((string) $a->images, true) ?: [];
        $img = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($images['image_intro'] ?? '');
        if ($img !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $img)) $img = \Joomla\CMS\Uri\Uri::root(true) . '/' . $img;
        $out[] = [
            'title'    => $a->title,
            'intro'    => trim(strip_tags((string) $a->introtext)),
            'category' => $a->category_title,
            'date'     => \Joomla\CMS\HTML\HTMLHelper::_('date', $a->publish_up ?: $a->created, \Joomla\CMS\Language\Text::_('TPL_TRACY_BUSINESS_DATE_FORMAT')),
            'datetime' => \Joomla\CMS\HTML\HTMLHelper::_('date', $a->publish_up ?: $a->created, 'Y-m-d'),
            'image'    => $img,
            'url'      => \Joomla\CMS\Router\Route::_(\Joomla\Component\Content\Site\Helper\RouteHelper::getArticleRoute($a->id . ':' . $a->alias, $a->catid, $a->language)),
        ];
    }
    return $out;
};
$ngNewsCategoryUrl = static fn (int $id): string => \Joomla\CMS\Router\Route::_(\Joomla\Component\Content\Site\Helper\RouteHelper::getCategoryRoute($id));
