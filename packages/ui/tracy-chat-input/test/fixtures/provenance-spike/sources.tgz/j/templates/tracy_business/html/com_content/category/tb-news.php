<?php

/**
 * Tracy Business — News: com_content category blog, alternative layout `tb-news`.
 *
 * Page intro (H1 + lede + live article count), filter chips (the category's children), one
 * leading card, a 2 × 2 grid of intro cards, the pagination row, and a right sidebar that renders
 * the modules of position `news-sidebar` (search · categories · latest · newsletter).
 *
 * The sidebar is NOT `sidebar-r`: articles opened from the News menu item share its Itemid, and
 * the article page carries its own aside (TOC · downloads · CTA), so the news boxes must not
 * follow the Itemid onto the article. Rendering a named position here keeps them on the list only.
 *
 * Labels come from the menu item params (set by tools/j/build-news.php, editable in admin):
 *   page_heading · page_subheading · ng_count_label · ng_page_meta · ng_all_label ·
 *   ng_featured_label
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$app    = Factory::getApplication();
$params = $this->params;
$esc    = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dateF  = Text::_('TPL_TRACY_BUSINESS_DATE_FORMAT');

// the category the menu item points at is the root of the chips; a child page keeps the same chips
$root = $this->menuItemMatchCategory ? $this->category : ($this->category->getParent() ?: $this->category);
if ((int) $root->id === 1 || $root->level < 1) {
    $root = $this->category;
}
$children = $root->getChildren();

$catUrl = static fn ($cat) => Route::_(RouteHelper::getCategoryRoute($cat->id, $cat->language));
$artUrl = static fn ($item) => Route::_(RouteHelper::getArticleRoute($item->slug, $item->catid, $item->language));
$imgUrl = static function (string $path): string {
    $url = HTMLHelper::_('cleanImageURL', $path)->url ?? '';
    if ($url !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $url)) {
        $url = Uri::root(true) . '/' . $url;
    }
    return $url;
};
$field = static function ($item, string $name): string {
    foreach ($item->jcfields ?? [] as $f) {
        if ($f->name === $name) {
            return trim((string) ($f->rawvalue ?? ''));
        }
    }
    return '';
};

$items   = is_array($this->items) ? array_values($this->items) : [];
$lead    = $items[0] ?? null;
$intro   = array_slice($items, 1);
$total   = (int) $this->pagination->total;
$countLb = trim((string) $params->get('ng_count_label', ''));
$heading = trim((string) $params->get('page_heading', '')) ?: $this->category->title;
$lede    = trim((string) $params->get('page_subheading', ''));
$pages   = $this->pagination->pagesTotal > 1 ? $this->pagination->getData() : null;
$pageMt  = trim((string) $params->get('ng_page_meta', ''));
$modules = ModuleHelper::getModules('news-sidebar');
?>
<div class="tb-newsblog tb-container<?php echo $this->pageclass_sfx ? ' ' . $esc(trim($this->pageclass_sfx)) : ''; ?>" itemscope itemtype="https://schema.org/Blog">
    <header class="tb-newsblog__intro">
        <div class="tb-newsblog__copy">
            <h1 class="tb-newsblog__title"><?php echo $esc($heading); ?></h1>
            <?php if ($lede !== '') : ?><p class="tb-newsblog__lede"><?php echo $esc($lede); ?></p><?php endif; ?>
        </div>
        <?php if ($countLb !== '' && $total > 1) : ?><?php // the source only has the plural label ?>
            <p class="tb-newsblog__count"><?php echo $esc($total . ' ' . $countLb); ?></p>
        <?php endif; ?>
    </header>

    <?php if ($children) : ?>
        <ul class="tb-newsblog__chips">
            <li><a class="tb-newsblog__chip<?php echo (int) $this->category->id === (int) $root->id ? ' is-active' : ''; ?>" href="<?php echo $esc($catUrl($root)); ?>"><?php echo $esc($params->get('ng_all_label', $root->title)); ?></a></li>
            <?php foreach ($children as $child) : ?>
                <li><a class="tb-newsblog__chip<?php echo (int) $this->category->id === (int) $child->id ? ' is-active' : ''; ?>" href="<?php echo $esc($catUrl($child)); ?>"><?php echo $esc($child->title); ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <div class="tb-newsblog__row">
        <div class="tb-newsblog__main">
            <?php if (!$items) : ?>
                <?php if ($params->get('show_no_articles', 1)) : ?>
                    <p class="tb-newsblog__empty"><?php echo Text::_('COM_CONTENT_NO_ARTICLES'); ?></p>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($lead) : ?>
                <?php
                $img   = json_decode((string) $lead->images) ?: new stdClass();
                $src   = $imgUrl($img->image_intro ?? '');
                $meta  = array_filter([
                    HTMLHelper::_('date', $lead->publish_up ?: $lead->created, $dateF),
                    $field($lead, 'tb-author'),
                    $field($lead, 'tb-read-time'),
                ], static fn ($v) => $v !== '');
                $featL = trim((string) $params->get('ng_featured_label', ''));
                $eyebr = implode(' · ', array_filter([$featL, $lead->category_title], static fn ($v) => $v !== ''));
                ?>
                <article class="tb-newsblog__feat<?php echo $src === '' ? ' tb-newsblog__feat--noimg' : ''; ?>" itemprop="blogPost" itemscope itemtype="https://schema.org/BlogPosting">
                    <?php if ($src !== '') : ?>
                        <a class="tb-newsblog__feat-media" href="<?php echo $esc($artUrl($lead)); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($src); ?>" alt="" width="640" height="580" loading="eager" decoding="async"></a>
                    <?php endif; ?>
                    <div class="tb-newsblog__feat-copy">
                        <?php if ($eyebr !== '') : ?><p class="tb-eyebrow"><?php echo $esc($eyebr); ?></p><?php endif; ?>
                        <h2 class="tb-newsblog__feat-title" itemprop="headline"><a href="<?php echo $esc($artUrl($lead)); ?>"><?php echo $esc($lead->title); ?></a></h2>
                        <?php if (trim(strip_tags((string) $lead->introtext)) !== '') : ?>
                            <p class="tb-newsblog__feat-desc"><?php echo $esc(trim(strip_tags((string) $lead->introtext))); ?></p>
                        <?php endif; ?>
                        <p class="tb-newsblog__feat-meta"><?php echo $esc(implode(' · ', $meta)); ?></p>
                    </div>
                </article>
            <?php endif; ?>

            <?php if ($intro) : ?>
                <ul class="tb-newsblog__grid">
                    <?php foreach ($intro as $item) : ?>
                        <?php
                        $img  = json_decode((string) $item->images) ?: new stdClass();
                        $src  = $imgUrl($img->image_intro ?? '');
                        $desc = trim(strip_tags((string) $item->introtext));
                        $url  = $artUrl($item);
                        ?>
                        <li>
                            <article class="tb-newscard" itemprop="blogPost" itemscope itemtype="https://schema.org/BlogPosting">
                                <?php if ($src !== '') : ?>
                                    <a class="tb-newscard__media" href="<?php echo $esc($url); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($src); ?>" alt="" width="800" height="450" loading="lazy" decoding="async"></a>
                                <?php endif; ?>
                                <?php if ((int) $item->catid !== (int) $root->id) : ?>
                                    <p class="tb-newscard__cat"><a href="<?php echo $esc(Route::_(RouteHelper::getCategoryRoute($item->catid, $item->language))); ?>"><?php echo $esc($item->category_title); ?></a></p>
                                <?php endif; ?>
                                <h3 class="tb-newscard__title" itemprop="headline"><a href="<?php echo $esc($url); ?>"><?php echo $esc($item->title); ?></a></h3>
                                <?php if ($desc !== '') : ?><p class="tb-newscard__desc"><?php echo $esc($desc); ?></p><?php endif; ?>
                                <p class="tb-newscard__date"><time datetime="<?php echo $esc(HTMLHelper::_('date', $item->publish_up ?: $item->created, 'Y-m-d')); ?>"><?php echo $esc(HTMLHelper::_('date', $item->publish_up ?: $item->created, $dateF)); ?></time></p>
                            </article>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if ($pages) : ?>
                <nav class="tb-newsblog__pager" aria-label="<?php echo $esc(Text::_('JLIB_HTML_PAGINATION')); ?>">
                    <ul class="tb-newsblog__pages">
                        <li><?php if ($pages->previous->link) : ?><a class="tb-newsblog__page tb-newsblog__page--arrow" href="<?php echo $esc($pages->previous->link); ?>" rel="prev" aria-label="<?php echo $esc(Text::_('JPREV')); ?>">‹</a><?php else : ?><span class="tb-newsblog__page tb-newsblog__page--arrow" aria-disabled="true">‹</span><?php endif; ?></li>
                        <?php $last = null; ?>
                        <?php foreach ($pages->pages as $n => $page) : ?>
                            <?php if ($last !== null && $n - $last > 1) : ?><li><span class="tb-newsblog__page tb-newsblog__page--gap">…</span></li><?php endif; ?>
                            <li>
                                <?php if ($page->link) : ?>
                                    <a class="tb-newsblog__page" href="<?php echo $esc($page->link); ?>"><?php echo (int) $n; ?></a>
                                <?php else : ?>
                                    <span class="tb-newsblog__page is-active" aria-current="page"><?php echo (int) $n; ?></span>
                                <?php endif; ?>
                            </li>
                            <?php $last = $n; ?>
                        <?php endforeach; ?>
                        <li><?php if ($pages->next->link) : ?><a class="tb-newsblog__page tb-newsblog__page--arrow" href="<?php echo $esc($pages->next->link); ?>" rel="next" aria-label="<?php echo $esc(Text::_('JNEXT')); ?>">›</a><?php else : ?><span class="tb-newsblog__page tb-newsblog__page--arrow" aria-disabled="true">›</span><?php endif; ?></li>
                    </ul>
                    <?php if ($pageMt !== '') : ?>
                        <p class="tb-newsblog__pagemeta"><?php echo $esc(sprintf($pageMt, (int) $this->pagination->pagesCurrent, (int) $this->pagination->pagesTotal, (int) $this->pagination->limit)); ?></p>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </div>

        <?php if ($modules) : ?>
            <aside class="tb-newsblog__side">
                <?php foreach ($modules as $module) : ?>
                    <?php echo ModuleHelper::renderModule($module, ['style' => 'none']); ?>
                <?php endforeach; ?>
            </aside>
        <?php endif; ?>
    </div>
</div>
