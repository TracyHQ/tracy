<?php

/**
 * Tracy Business — mod_articles, layout `tb-latest`: the "Latest articles" sidebar box on News.
 * Box label = the module title; rows of thumbnail · title · date (see tb-latest_items.php).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

if (!$list) {
    return;
}
$esc   = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$items = $grouped ? array_merge(...array_values($list)) : $list;
?>
<div class="tb-sidebox tb-sidelatest-box">
    <?php if ($module->showtitle && trim((string) $module->title) !== '') : ?>
        <p class="tb-sidebox__label"><?php echo $esc($module->title); ?></p>
    <?php endif; ?>
    <?php require ModuleHelper::getLayoutPath('mod_articles', $params->get('layout', 'default') . '_items'); ?>
</div>
