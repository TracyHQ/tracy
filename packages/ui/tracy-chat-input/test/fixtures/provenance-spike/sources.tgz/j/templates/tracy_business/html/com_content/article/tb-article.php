<?php

/**
 * Tracy Business — Article: com_content article, alternative layout `tb-article`.
 *
 * Header (category eyebrow · H1 · lede · byline with share buttons), hero photo + caption, the
 * body (fulltext), tags, prev/next (plg_content_pagenavigation, template override), related
 * articles (same category, newest, not this one), and a sticky aside: "In this article" (built
 * from the body's <h2> elements), downloads (custom field `tb-downloads`), and the Ink CTA box
 * (menu params ng_cta_title · ng_cta_desc · ng_cta_btn · ng_cta_itemid).
 *
 * Content model (all editable in admin):
 *   introtext            the card summary on lists — NOT shown here when `tb-news-lede` is set
 *   fulltext             the body; <h2 id="…" data-toc="short label"> feeds the TOC
 *   images.image_fulltext / image_fulltext_caption   hero photo + caption
 *   fields               tb-news-lede · tb-author · tb-author-role · tb-read-time · tb-downloads
 *   tags                 com_tags
 * Labels come from the News menu item params: ng_tags_label · ng_related_title · ng_toc_title ·
 * ng_downloads_title (prev/next labels are read by the pagenavigation override).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Component\Tags\Site\Helper\RouteHelper as TagRouteHelper;

$app     = Factory::getApplication();
$item    = $this->item;
$params  = $item->params;
$esc     = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dateF   = Text::_('TPL_TRACY_BUSINESS_DATE_FORMAT');
$canEdit = $params->get('access-edit');

$app->getDocument()->getWebAssetManager()
    ->registerAndUseScript('tpl_tracy_business.article', 'templates/tracy_business/js/tracy-business-article.js', [], ['defer' => true]);

$imgUrl = static function (string $path): string {
    $url = HTMLHelper::_('cleanImageURL', $path)->url ?? '';
    if ($url !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $url)) {
        $url = Uri::root(true) . '/' . $url;
    }
    return $url;
};
$fieldObj = static function ($item, string $name) {
    foreach ($item->jcfields ?? [] as $f) {
        if ($f->name === $name) {
            return $f;
        }
    }
    return null;
};
$field = static fn ($item, string $name): string => trim((string) ($fieldObj($item, $name)->rawvalue ?? ''));

// ---- header pieces
$catUrl   = Route::_(RouteHelper::getCategoryRoute($item->catid, $item->language));
$selfUrl  = Route::_(RouteHelper::getArticleRoute($item->slug, $item->catid, $item->language), true, Route::TLS_IGNORE, true);
$ledeF    = $field($item, 'tb-news-lede');
$introTxt = trim((string) $item->introtext);
$lede     = $ledeF !== '' ? '<p>' . $esc($ledeF) . '</p>' : $introTxt;
$author   = $field($item, 'tb-author');
$role     = $field($item, 'tb-author-role');
$readT    = $field($item, 'tb-read-time');
$date     = HTMLHelper::_('date', $item->publish_up ?: $item->created, $dateF);
$authorMt = implode(' · ', array_filter([$role, $date, $readT], static fn ($v) => $v !== ''));
$initials = '';
if ($author !== '') {
    foreach (preg_split('/\s+/u', $author) as $i => $w) {
        if ($i < 2 && $w !== '') {
            $initials .= mb_substr($w, 0, 1);
        }
    }
}

// ---- hero
$images  = json_decode((string) $item->images) ?: new stdClass();
$hero    = $imgUrl($images->image_fulltext ?? '');
$heroAlt = (string) ($images->image_fulltext_alt ?? '');
$heroCap = trim((string) ($images->image_fulltext_caption ?? ''));

// ---- body: plugin-processed text (show_intro=0 on the News menu item ⇒ fulltext only); an
// article with no fulltext keeps its introtext as the lede and has no body
$body = trim((string) $item->fulltext) !== '' ? trim((string) $item->text) : '';

// TOC: every <h2> of the body; an id is added when missing, data-toc wins over the heading text
$toc = [];
if ($body !== '') {
    $n    = 0;
    $body = preg_replace_callback('~<h2\b([^>]*)>(.*?)</h2>~is', static function ($m) use (&$toc, &$n) {
        $n++;
        $attrs = $m[1];
        $id    = preg_match('/\bid="([^"]+)"/', $attrs, $mm) ? $mm[1] : 'tb-h2-' . $n;
        if (!isset($mm[1])) {
            $attrs .= ' id="' . $id . '"';
        }
        $label = preg_match('/\bdata-toc="([^"]*)"/', $attrs, $ml) ? html_entity_decode($ml[1], ENT_QUOTES, 'UTF-8') : trim(strip_tags($m[2]));
        $toc[] = ['id' => $id, 'label' => $label];
        return '<h2' . $attrs . '>' . $m[2] . '</h2>';
    }, $body);
}

// ---- downloads (subform field: rows of tb-dl-name · tb-dl-type · tb-dl-file)
$downloads = [];
if (($dl = $fieldObj($item, 'tb-downloads')) && !empty($dl->subform_rows)) {
    foreach ($dl->subform_rows as $row) {
        $name = trim((string) ($row['tb-dl-name']->rawvalue ?? ''));
        if ($name === '') {
            continue;
        }
        $file = trim((string) ($row['tb-dl-file']->rawvalue ?? ''));
        $downloads[] = ['name' => $name, 'type' => trim((string) ($row['tb-dl-type']->rawvalue ?? '')), 'url' => $file !== '' ? $imgUrl($file) : ''];
    }
}

// ---- related: newest of the same category, not this one
$related = [];
if ((int) $params->get('ng_related_count', 3) > 0) {
    $model = $app->bootComponent('com_content')->getMVCFactory()->createModel('Articles', 'Site', ['ignore_request' => true]);
    $model->setState('params', clone $params);
    $model->setState('filter.category_id', (int) $item->catid);
    $model->setState('filter.published', 1);
    $model->setState('filter.access', true);
    $model->setState('filter.language', $app->getLanguageFilter());
    $model->setState('filter.article_id', (int) $item->id);
    $model->setState('filter.article_id.include', false);
    $model->setState('list.start', 0);
    $model->setState('list.limit', (int) $params->get('ng_related_count', 3));
    $model->setState('list.ordering', 'a.publish_up');
    $model->setState('list.direction', 'DESC');
    foreach ($model->getItems() as $r) {
        $ri = json_decode((string) $r->images) ?: new stdClass();
        $related[] = [
            'title' => $r->title,
            'url'   => Route::_(RouteHelper::getArticleRoute($r->id . ':' . $r->alias, $r->catid, $r->language)),
            'image' => $imgUrl($ri->image_intro ?? ''),
            'date'  => HTMLHelper::_('date', $r->publish_up ?: $r->created, $dateF),
            'dt'    => HTMLHelper::_('date', $r->publish_up ?: $r->created, 'Y-m-d'),
        ];
    }
}

$tags      = !empty($item->tags->itemTags) ? $item->tags->itemTags : [];
$ctaTitle  = trim((string) $params->get('ng_cta_title', ''));
$ctaBtn    = trim((string) $params->get('ng_cta_btn', ''));
$ctaItemid = (int) $params->get('ng_cta_itemid', 0);
$cta       = $ctaTitle !== '' && $ctaBtn !== '' && $ctaItemid > 0;
$hasAside  = $toc || $downloads || $cta;
?>
<div class="tb-article tb-container<?php echo $hasAside ? '' : ' tb-article--noaside'; ?>">
    <article class="tb-article__main" itemscope itemtype="https://schema.org/Article">
        <?php if ($canEdit) : ?>
            <div class="tb-article__edit"><?php echo LayoutHelper::render('joomla.content.icons', ['params' => $params, 'item' => $item, 'print' => false]); ?></div>
        <?php endif; ?>

        <header class="tb-article__header">
            <p class="tb-eyebrow"><a class="tb-article__cat" href="<?php echo $esc($catUrl); ?>"><?php echo $esc($item->category_title); ?></a></p>
            <h1 class="tb-article__title" itemprop="headline"><?php echo $esc($item->title); ?></h1>
            <?php if ($lede !== '') : ?><div class="tb-article__lede" itemprop="description"><?php echo $lede; ?></div><?php endif; ?>

            <div class="tb-article__byline">
                <?php if ($author !== '') : ?>
                    <span class="tb-article__avatar" aria-hidden="true"><?php echo $esc($initials); ?></span>
                    <div class="tb-article__author">
                        <p class="tb-article__author-name" itemprop="author"><?php echo $esc($author); ?></p>
                        <p class="tb-article__author-meta"><?php echo $esc($authorMt); ?></p>
                    </div>
                <?php else : ?>
                    <div class="tb-article__author">
                        <p class="tb-article__author-meta"><time datetime="<?php echo $esc(HTMLHelper::_('date', $item->publish_up ?: $item->created, 'Y-m-d')); ?>" itemprop="datePublished"><?php echo $esc($date); ?></time></p>
                    </div>
                <?php endif; ?>
                <ul class="tb-article__share">
                    <li><a class="tb-article__share-btn" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode($selfUrl); ?>" target="_blank" rel="noopener" aria-label="LinkedIn">in</a></li>
                    <li><a class="tb-article__share-btn" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode($selfUrl); ?>" target="_blank" rel="noopener" aria-label="Facebook">f</a></li>
                    <li><button class="tb-article__share-btn js-tb-copy" type="button" data-url="<?php echo $esc($selfUrl); ?>" aria-label="<?php echo $esc(Text::_('TPL_TRACY_BUSINESS_COPY_LINK')); ?>" title="<?php echo $esc(Text::_('TPL_TRACY_BUSINESS_COPY_LINK')); ?>">⧉</button></li>
                </ul>
            </div>
        </header>

        <?php if ($hero !== '') : ?>
            <figure class="tb-article__hero">
                <img src="<?php echo $esc($hero); ?>" alt="<?php echo $esc($heroAlt); ?>" width="1352" height="840" loading="eager" decoding="async">
                <?php if ($heroCap !== '') : ?><figcaption class="tb-article__caption"><?php echo $esc($heroCap); ?></figcaption><?php endif; ?>
            </figure>
        <?php endif; ?>

        <?php echo $item->event->afterDisplayTitle; ?>
        <?php echo $item->event->beforeDisplayContent; ?>

        <?php if ($body !== '') : ?>
            <div class="tb-article__body" itemprop="articleBody"><?php echo $body; ?></div>
        <?php endif; ?>

        <?php if ($tags) : ?>
            <div class="tb-article__tags">
                <?php if (trim((string) $params->get('ng_tags_label', '')) !== '') : ?><span class="tb-article__tags-label"><?php echo $esc($params->get('ng_tags_label')); ?></span><?php endif; ?>
                <?php foreach ($tags as $tag) : ?>
                    <a class="tb-article__tag" href="<?php echo $esc(Route::_(TagRouteHelper::getComponentTagRoute($tag->tag_id . ':' . $tag->alias, $tag->language))); ?>"><?php echo $esc($tag->title); ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php echo $item->pagination ?? ''; ?>

        <?php if ($related) : ?>
            <section class="tb-article__related" aria-labelledby="tb-related-title">
                <h2 class="tb-article__related-title" id="tb-related-title"><?php echo $esc($params->get('ng_related_title', '')); ?></h2>
                <ul class="tb-article__related-grid">
                    <?php foreach ($related as $r) : ?>
                        <li>
                            <article class="tb-article__relcard">
                                <?php if ($r['image'] !== '') : ?><a class="tb-article__relcard-media" href="<?php echo $esc($r['url']); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($r['image']); ?>" alt="" width="652" height="260" loading="lazy" decoding="async"></a><?php endif; ?>
                                <h3 class="tb-article__relcard-title"><a href="<?php echo $esc($r['url']); ?>"><?php echo $esc($r['title']); ?></a></h3>
                                <p class="tb-article__relcard-date"><time datetime="<?php echo $esc($r['dt']); ?>"><?php echo $esc($r['date']); ?></time></p>
                            </article>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>

        <?php echo $item->event->afterDisplayContent; ?>
    </article>

    <?php if ($hasAside) : ?>
        <aside class="tb-article__aside">
            <?php if ($toc) : ?>
                <nav class="tb-sidebox tb-sidebox--paper tb-article__toc" aria-labelledby="tb-toc-title">
                    <p class="tb-sidebox__label" id="tb-toc-title"><?php echo $esc($params->get('ng_toc_title', '')); ?></p>
                    <ul class="tb-article__toc-list">
                        <?php foreach ($toc as $i => $t) : ?>
                            <li><a class="tb-article__toc-link<?php echo $i === 0 ? ' is-active' : ''; ?>" href="#<?php echo $esc($t['id']); ?>"><?php echo $esc($t['label']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            <?php endif; ?>

            <?php if ($downloads) : ?>
                <div class="tb-sidebox tb-article__downloads">
                    <p class="tb-sidebox__label"><?php echo $esc($params->get('ng_downloads_title', '')); ?></p>
                    <ul class="tb-siderows">
                        <?php foreach ($downloads as $d) : ?>
                            <li>
                                <?php if ($d['url'] !== '') : ?>
                                    <a class="tb-siderows__row tb-article__dl-row" href="<?php echo $esc($d['url']); ?>" download><span><?php echo $esc($d['name']); ?></span><?php if ($d['type'] !== '') : ?><span class="tb-siderows__aux"><?php echo $esc($d['type']); ?></span><?php endif; ?></a>
                                <?php else : ?>
                                    <span class="tb-siderows__row tb-article__dl-row tb-article__dl-row--plain"><span><?php echo $esc($d['name']); ?></span><?php if ($d['type'] !== '') : ?><span class="tb-siderows__aux"><?php echo $esc($d['type']); ?></span><?php endif; ?></span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($cta) : ?>
                <div class="tb-sidecta">
                    <p class="tb-sidecta__title"><?php echo $esc($ctaTitle); ?></p>
                    <?php if (trim((string) $params->get('ng_cta_desc', '')) !== '') : ?><p class="tb-sidecta__desc"><?php echo $esc($params->get('ng_cta_desc')); ?></p><?php endif; ?>
                    <a class="tb-btn tb-btn--signal" href="<?php echo $esc(Route::_('index.php?Itemid=' . $ctaItemid)); ?>"><?php echo $esc($ctaBtn); ?></a>
                </div>
            <?php endif; ?>
        </aside>
    <?php endif; ?>
</div>
