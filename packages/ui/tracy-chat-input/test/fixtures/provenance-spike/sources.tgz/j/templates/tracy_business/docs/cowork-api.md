# The Claude Cowork door — how an agent reads and writes this site

`com_claudecowork` (0.15.0, with `plg_system_claudecoworkapi`) is installed **for you**. It is the
one supported way for an agent to read and change content on this site: it validates the kind and
the columns, writes through Joomla's own tables and workflow, records every change under a receipt
you name, and can undo it. **Never touch the database directly** — no `docker exec … mariadb`, no
`UPDATE ng_*`, no PHP that opens the DB — and do not hand-edit `configuration.php`. Raw SQL skips the
receipt, the nested-set maintenance of menus/categories/tags, the checksums and the undo; the
Module Manager and the site keep running while the data underneath is already wrong.

Order of preference for any content change: **the door → the Admin UI (for the few things the
door has no action for) → nothing else.** The build-machine scripts under `tools/j/` were for the
initial import and are not a maintenance path.

## 1. Where the door is, and the token

```
POST http://<site>/index.php?option=com_claudecowork&task=api.exec&format=json
Content-Type: application/json
{"token": "<token>", "action": "<action>", "params": { … }}
```

The same door answers on `/administrator/index.php?…` (use it if a "coming soon"/maintenance gate
answers the front end with HTML). Every reply is JSON with a boolean `ok`; a refusal is
`{"ok":false,"error":"<code>","message":"…"}` — read the message, it names the rule you hit.

The token is the component's *Token* parameter (System → Extensions → Claude Cowork). On this
build copy it is `claudecowork_token` in the workspace's `private-credentials.json` (chmod 600);
the door URL is `claudecowork_door` next to it. On a Tracy-provisioned site the provisioner sets it
and the agent never sees it — a Tracy Cowork session calls the same actions through the
`tracy_site({action, params})` tool, which carries the viewer's seat instead of a token. **Never
write the token into a doc, a commit, a screenshot or a report.**

Quick sanity: `{"action":"info"}` → `{"ok":true,"info":{"php":…,"joomla":"6.1.1","component":"0.15.0"}}`.

## 2. Actions

| Action | Params | What it does |
|---|---|---|
| `info` | — | versions; proves the door and token work |
| `site.stats` | — | file and DB counts |
| `content.list` | `kind`, `offset`, `limit`, `include_body` | pages through one kind; rows carry a `checksum` |
| `content.get` | `kind`, `id` | one row, every column |
| `content.update` | `apply_id`, `kind`, `id` (0 = create), `fields` | create or edit; on a tree kind, `parent_id` / `move_after` in `fields` **move** an existing node |
| `content.delete` | `apply_id`, `kind`, `id` | trash (kinds with a trash column) or delete |
| `content.batch` | `apply_id`, `request_id`, `operations[]` of `{kind, id, fields, expected?, key?}` | up to 100 writes as one step; `expected` = optimistic check on current values; the same `request_id` replays safely |
| `apply.list` | `apply_id` | the steps recorded under a receipt |
| `apply.revert` | `apply_id` | undo every step of the receipt, newest first (a create is undone by deleting) |
| `media.upload` | `path`, plus the bytes the client streams | put an image under `images/` |
| `file.read` / `files.list` | `path` / `after`, `limit` | read the webroot (files.list pages) |
| `db.snapshot` / `db.rollback` | `tables?` / `tag` | table-level snapshot before a large change, and the way back |
| `extension.install` | `url`, `sha256?`, `bytes?` | install a package from an https URL — how the 12 language packs were installed (`languages.md`); pin `sha256` from `language-packs.json` |
| `extension.list`, `core.manifest` | — | what is installed |
| `content.contract` | — | contract binding — **this site is not bound** (it is a custom template, not a Tracy base quickstart); the action answers `contract_failed` and that is expected |

`db.dump`, `db.cleanup`, `db.purge`, `db.restore`, `extension.enable`,
`core.upgrade`, `files.restore`, `files.pack` exist for operators; do not use them for content work.

## 3. Kinds and the columns you may write

| kind | create | writable columns |
|---|---|---|
| `article` | yes | title, alias, introtext, fulltext, state, catid, images, urls, attribs, metadata, metakey, metadesc, language, featured, ordering, access, publish_up, publish_down — plus `tags` (array of tag ids) beside the row |
| `category` | yes (tree: `parent_id`) | title, note, description, published, access, language, params, metadesc, metakey; create also `extension` (default `com_content`) |
| `tag` | yes (tree) | title, note, description, published, access, language, params |
| `menuItem` | yes (tree: `parent_id`, `menutype`, `link`, `type`) | title, note, published, params, home, language, template_style_id, link; create also alias, browserNav, access |
| `module` | yes | title, note, content, position, module, access, showtitle, params, published, language, ordering |
| `contact` | yes | name, alias, con_position, address, suburb, country, postcode, telephone, fax, misc, email_to, mobile, webpage, published, catid, access, ordering, params, language, metadesc, metakey, metadata, featured, publish_up/down |
| `field` | yes | title, label, note, description, default_value, required, state, params, fieldparams, language, access |
| `menutype`, `language`, `redirect`, `banner`, `bannerClient`, `newsfeed` | yes | their own columns |
| `templateStyle` | no | title, params, home, template |
| `user` | no | name, email, block |
| `extensionParams`, `languageFilter` | no | params (/ enabled) |

Three **relation kinds** — the `id` is the owning row, the field is a **JSON string**:

| kind | id | fields |
|---|---|---|
| `moduleAssignment` | module id | `{"menuids":"[605,638]"}` — `"[0]"` = all pages, `"[]"` = none, negative ids = all except |
| `articleAssociation` | article id | `{"ids":"[555,588]"}` — one item per language, 2–50 ids including the target |
| `menuAssociation` | menu item id | `{"ids":"[600,633]"}` |

Column values are what Joomla stores: `params`/`attribs`/`images` are **JSON strings**, dates
`YYYY-MM-DD HH:MM:SS`, `language` `en-GB` / `ru-RU` / `*`. An ACM module's `params` holds
`jatools-config` as a JSON string inside the JSON — read an existing module of the same block
with `content.get` and copy its shape (`docs/blocks.md` lists the field names).

## 4. Receipts — every write under an `apply_id`

Pick one `apply_id` per task (`certifications-page-2026-09-14`), pass it to every write of that
task, and finish your report with it. `apply.list` shows what you did; `apply.revert` takes it all
back in reverse order. Before a change that touches many rows (re-hanging a menu tree, mass
category moves) take `db.snapshot` first and quote its `tag` in the report.

## 5. Worked example — a new static page, both languages

```bash
DOOR='http://127.0.0.1:8230/index.php?option=com_claudecowork&task=api.exec&format=json'
call(){ curl -s -X POST -H 'Content-Type: application/json' -d "$1" "$DOOR"; echo; }
A=certifications-2026-09-14
```

1. Articles (category ids from `site-map.md`; full text loads the page's position):
```json
{"token":"…","action":"content.update","params":{"apply_id":"certifications-2026-09-14","kind":"article","id":0,"fields":{
  "title":"Certifications","alias":"certifications","catid":263,"language":"en-GB","state":1,
  "introtext":"<p>Lede supplied by the customer.</p>","fulltext":"{loadposition certifications-page}"}}}
```
→ `{"ok":true,"kind":"article","id":<EN id>,"created":true}`; repeat with `ru-RU`, then
`{"kind":"articleAssociation","id":<EN id>,"fields":{"ids":"[<EN id>,<RU id>]"}}`.

2. Menu items under About (parents 600 EN / 633 RU; style 120 = Inner):
```json
{"kind":"menuItem","id":0,"fields":{"title":"Certifications","alias":"certifications","menutype":"tb-main-en",
  "type":"component","link":"index.php?option=com_content&view=article&id=<EN id>","parent_id":600,
  "language":"en-GB","published":1,"template_style_id":120,"params":"{\"page_title\":\"\"}"}}
```
then RU under 633 on `tb-main-ru`, then `menuAssociation` with both menu ids.

3. Modules, one per section, ordering = vertical order; copy `params` from an existing module of
the same block (`content.get` module 837 for `tb-stats-strip`), then assign each to its page:
```json
{"kind":"module","id":0,"fields":{"title":"[Tracy Business] Certifications - Stats (en)","module":"mod_ja_acm",
  "position":"certifications-page","language":"en-GB","published":1,"showtitle":0,"ordering":1,"note":"certifications",
  "params":"{\"jatools-config\":\"{\\\"…\\\"}\",\"jatools-layout-ng-stats-strip\":\"style-1\",\"moduleclass_sfx\":\"\",\"cache\":0}"}}
{"kind":"moduleAssignment","id":<module id>,"fields":{"menuids":"[<EN menu id>]"}}
```

4. Declare `certifications-page` in `templateDetails.xml` (file edit), clear the T4 cache, run the
checks (`checks.md`), report the `apply_id`.

If anything is wrong: `{"action":"apply.revert","params":{"apply_id":"certifications-2026-09-14"}}`.

## 6. What the door will refuse, and what that means

- `unauthorized` — token missing/wrong; you are on the wrong site or reading the wrong secret.
- `unsupported … cannot be created through Apply` — that kind is edit-only (styles, users, params).
- `bad_params: apply_id required` — every write needs a receipt; pick one, do not invent per call.
- `content_only` — only on contract-bound Tracy quickstarts; this site is not one. If you ever see
  it here, stop: the site's binding changed and structural work needs a different workflow.
- `writer_busy` — another write is in flight; retry, do not fall back to SQL.
