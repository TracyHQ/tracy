<?php
/** Tracy Business — ACM `tb-page-split-cards`: paper-2 band, two columns — H2 + paragraph on the left, a stack of bordered cards (title + line) on the right. About "What we do". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title')); $text = trim((string) $helper->get('text'));
$cards = [];
for ($i = 0, $n = (int) $helper->getRows('card-title'); $i < $n; $i++) { $t = trim((string) $helper->get('card-title', $i)); if ($t !== '') $cards[] = [$t, trim((string) $helper->get('card-desc', $i))]; }
if ($title === '' && !$cards) return;
$id = 'tb-pg-split-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-split-cards tb-pg-band tb-pg-band--paper2 tb-pg-what" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-pg-what__inner">
    <div class="tb-pg-what__copy">
      <h2 class="tb-pg-h2" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
      <?php if ($text !== '') : ?><p class="tb-pg-what__text"><?php echo $esc($text); ?></p><?php endif; ?>
    </div>
    <?php if ($cards) : ?>
      <ul class="tb-pg-cards">
        <?php foreach ($cards as [$t, $d]) : ?><li class="tb-pg-cards__card"><strong class="tb-pg-cards__title"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><p class="tb-pg-cards__desc"><?php echo $esc($d); ?></p><?php endif; ?></li><?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</section>
