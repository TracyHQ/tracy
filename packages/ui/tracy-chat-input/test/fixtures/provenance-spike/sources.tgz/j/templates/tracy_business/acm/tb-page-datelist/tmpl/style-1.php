<?php
/** Tracy Business — ACM `tb-page-datelist`: "Material disclosures" — H2 and rows of title (left) + date (right, meta). A row links only when a link is set. A column in a split row. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-date', $i)), $route((string) $helper->get('row-link', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-page-datelist tb-pg-datelist" id="tb-pg-dates-<?php echo (int) $module->id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm tb-pg-datelist__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-pg-datelist__list">
    <?php foreach ($rows as [$t, $d, $l]) : ?><li class="tb-pg-datelist__row"><?php if ($l !== '') : ?><a class="tb-pg-datelist__name" href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><span class="tb-pg-datelist__name"><?php echo $esc($t); ?></span><?php endif; ?><?php if ($d !== '') : ?><span class="tb-pg-datelist__date"><?php echo $esc($d); ?></span><?php endif; ?></li><?php endforeach; ?>
  </ul>
</div>
