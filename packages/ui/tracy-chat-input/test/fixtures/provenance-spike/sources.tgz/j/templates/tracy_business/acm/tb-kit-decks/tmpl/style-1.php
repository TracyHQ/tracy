<?php
/** Tracy Business — ACM `tb-kit-decks`: READY-MADE DECKS — rows of name + note with a signal "PDF · size ↓" on the right. A row is a download link only when its file exists on disk; otherwise the same row renders as text. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$fileUrl = static function (string $path): string {
    $path = ltrim(trim($path), '/');
    if ($path === '' || !is_file(JPATH_ROOT . '/' . $path)) return '';
    return \Joomla\CMS\Uri\Uri::root(true) . '/' . implode('/', array_map('rawurlencode', explode('/', $path)));
};
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('deck-title'); $i < $n; $i++) { $t = trim((string) $helper->get('deck-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('deck-desc', $i)), $fileUrl((string) $helper->get('deck-file', $i)), trim((string) $helper->get('deck-size', $i))]; }
if (!$rows) return;
$id = 'tb-kitdecks-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-decks tb-kitdecks" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-section__title tb-kitdecks__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <ul class="tb-kitdecks__list">
      <?php foreach ($rows as [$t, $d, $u, $s]) : ?>
        <li class="tb-kitdecks__row">
          <?php if ($u !== '') : ?><a class="tb-kitdecks__link" href="<?php echo $esc($u); ?>" download><?php else : ?><div class="tb-kitdecks__link tb-kitdecks__link--static"><?php endif; ?>
            <span class="tb-kitdecks__copy"><strong class="tb-kitdecks__name"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><span class="tb-kitdecks__desc"><?php echo $esc($d); ?></span><?php endif; ?></span>
            <?php if ($s !== '') : ?><span class="tb-kitdecks__size"><?php echo $esc($s); ?><?php if ($u !== '') : ?> <span aria-hidden="true">↓</span><?php endif; ?></span><?php endif; ?>
          <?php echo $u !== '' ? '</a>' : '</div>'; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>
