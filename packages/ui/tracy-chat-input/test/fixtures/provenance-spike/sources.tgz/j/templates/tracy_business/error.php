<?php

/**
 * Tracy Business — error page.
 *
 * A 404 is a page of the site, not a maintenance screen: it is rendered THROUGH T4 with the inner
 * layout, so it carries the real topbar, header, megamenu and footer, and its body is whatever is
 * published in the `error-page` position — the `tb-sys-error` block (status code, heading, text, a
 * live Smart Search form, the back-to-home link and the suggested pages). The head is wired exactly
 * as index.php wires it (dark resolution, design-system tokens, fonts, chrome script); the theme
 * resolution itself is shared through theme-resolve.php so the two cannot drift.
 *
 * Any other status, or a 404 while T4 cannot render (the fault is in T4 itself), falls back to a
 * one-column standalone page so the visitor still gets the code, the message and a way home.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$app      = Factory::getApplication();
$sitename = htmlspecialchars((string) $app->get('sitename'), ENT_QUOTES, 'UTF-8');
$base     = Uri::root(true);
$tpl      = $base . '/templates/' . $this->template;
$code     = isset($this->error) && method_exists($this->error, 'getCode') ? (int) $this->error->getCode() : 500;
$msg      = isset($this->error) ? $this->error->getMessage() : '';
$lang     = $app->getLanguage()->getTag();
$home     = $app->getMenu()->getDefault($lang) ?: $app->getMenu()->getDefault();
$homeUrl  = $home ? Route::_('index.php?Itemid=' . (int) $home->id) : ($base ?: '/');

$tracyBaseSiteProfile = $this->params->get('typelist-site', 'default');
require __DIR__ . '/theme-resolve.php';

$full = $code === 404 && class_exists('\T4\T4');

if ($full) {
    $doc = $this;
    $obLevel = ob_get_level();
    try {
        // A 404 thrown while routing never reaches onAfterRoute, where T4 normally initialises
        // its paths — do it here, or Asset.php dies on an undefined T4PATH_BASE.
        if (!\defined('T4PATH_BASE')) {
            \T4\T4::getInstance()->init();
        }

        // --- the same head index.php builds: first-paint theme, tokens, dark remap, fonts, chrome js
        $this->params->set('typelist-layout', 'tracy-business-inner');
        $this->setMetaData('robots', 'noindex, nofollow');
        $this->setMetaData('viewport', 'width=device-width, initial-scale=1');
        $this->setTitle($code . ' — ' . $app->get('sitename'));
        $this->addScriptDeclaration($tracyBaseHeadScript);
        $this->addScriptDeclaration('window.tracyTheme={def:' . json_encode($tracyBaseDefaultTheme) . ',enabled:' . ($tracyBaseDarkEnabled ? 'true' : 'false') . '};');

        $designSystem = $this->params->get('typelist-theme', 'default');
        foreach ([
            'css/styles/' . $designSystem . '.css',
            ($tracyBaseDarkEnabled || $tracyBaseDefaultTheme !== 'light') ? 'css/darkmode.css' : '',
            'css/tracy-business-fonts.css',
            'css/site-repairs.css',
        ] as $rel) {
            if ($rel !== '' && is_file(__DIR__ . '/' . $rel)) {
                $this->addCustomTag('<link rel="stylesheet" href="' . $tpl . '/' . $rel . '?' . filemtime(__DIR__ . '/' . $rel) . '">');
            }
        }
        foreach (['js/darkmode.js' => 'tpl.northgate.darkmode', 'js/tracy-business.js' => 'tpl.northgate.chrome'] as $rel => $name) {
            if (is_file(__DIR__ . '/' . $rel)) {
                $this->getWebAssetManager()->registerAndUseScript($name, 'templates/' . $this->template . '/' . $rel . '?' . filemtime(__DIR__ . '/' . $rel), [], ['defer' => true]);
            }
        }

        // --- the body: the error-page modules of this language, or the bare code + message
        $blocks = '';
        foreach (ModuleHelper::getModules('error-page') as $mod) {
            $mod->ngErrorCode = $code;
            $blocks .= ModuleHelper::renderModule($mod, ['style' => 'none']);
        }
        if (trim($blocks) === '') {
            $blocks = '<div class="tb-404 tb-404--bare"><div class="tb-404__main"><p class="tb-404__code" aria-hidden="true">' . $code . '</p>'
                . '<h1 class="tb-404__title">' . htmlspecialchars((string) $msg, ENT_QUOTES, 'UTF-8') . '</h1>'
                . '<p class="tb-404__back"><a class="tb-textlink" href="' . htmlspecialchars($homeUrl, ENT_QUOTES, 'UTF-8') . '">' . $sitename . '</a></p></div></div>';
        }
        $this->setBuffer('<div class="tb-errorpage"><div class="tb-container">' . $blocks . '</div></div>', ['type' => 'component', 'name' => '', 'title' => '']);

        // The design has no breadcrumb on the 404; the module is assigned by menu item and a 404
        // has none, so it would print a lone "Home". Park it in a position no layout renders.
        foreach (ModuleHelper::getModules('breadcrumbs') as $crumbs) {
            $crumbs->position = 'tb-error-unused';
        }

        // T4 fills its {t4post:*} placeholders in onAfterRender and Joomla renders <jdoc:include>
        // tags after this file returns — neither happens in the order a T4 page needs on an error
        // response (Joomla would render the head BEFORE the megamenu registers its assets and the
        // asset manager throws "locked"). So the document is assembled right here, through the
        // public buffer API, in T4's order: modules → message → component/elements → head last.
        $t4doc = \T4\T4::getInstance()->getDocument($this);
        ob_start();
        \T4\T4::render($this);
        $out = (string) ob_get_clean();

        $tags = [[], [], []];
        if (preg_match_all('#<jdoc:include\ type="([^"]+)"(.*)\/>#iU', $out, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $attribs = empty($m[2]) ? [] : \Joomla\CMS\Utility\Utility::parseAttributes($m[2]);
                $rank    = ($m[1] === 'module' || $m[1] === 'modules') ? 0 : ($m[1] === 'message' ? 1 : 2);
                $tags[$rank][$m[0]] = [$m[1], $attribs['name'] ?? null, $attribs];
            }
        }
        foreach ($tags as $group) {
            foreach ($group as $tag => [$type, $name, $attribs]) {
                $out = str_replace($tag, (string) $this->getBuffer($type, $name, $attribs), $out);
            }
        }
        $out = preg_replace_callback('/\{t4post:([a-z_]+)\}/i', static function (array $m) use ($t4doc, $doc): string {
            if ($m[1] === 'head') {
                return (string) $doc->getBuffer('head');
            }
            $getter = 'get' . ucfirst($m[1]);
            return method_exists($t4doc, $getter) ? (string) $t4doc->$getter() : '';
        }, $out);
        // the same sweep T4's afterRender does: drop layout containers that came out empty
        do {
            $out = preg_replace('/<div[^>]*class="t4-[^>]*>\s*<\/div>/mi', '', $out, -1, $swept);
        } while ($swept);

        echo $out;
        return;
    } catch (\Throwable $e) {
        // fall through to the standalone page below; say why in the PHP log so it is not silent
        error_log('northgate error.php: full-chrome render failed, standalone fallback used — ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        while (ob_get_level() > $obLevel) { ob_end_clean(); }
    }
}

$darkCss  = __DIR__ . '/css/darkmode.css';
$showDark = $tracyBaseDarkEnabled || $tracyBaseDefaultTheme === 'dark' || $tracyBaseDefaultTheme === 'auto';
$tokens   = __DIR__ . '/css/styles/' . $this->params->get('typelist-theme', 'default') . '.css';
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo $code; ?> — <?php echo $sitename; ?></title>
    <script><?php echo $tracyBaseHeadScript; ?></script>
    <link rel="stylesheet" href="<?php echo $tpl; ?>/css/template.css">
    <?php if (is_file($tokens)) : ?><link rel="stylesheet" href="<?php echo $tpl; ?>/css/styles/<?php echo basename($tokens); ?>?<?php echo filemtime($tokens); ?>"><?php endif; ?>
    <?php if ($showDark && is_file($darkCss)) : ?><link rel="stylesheet" href="<?php echo $tpl; ?>/css/darkmode.css?<?php echo filemtime($darkCss); ?>"><?php endif; ?>
    <?php if (is_file(__DIR__ . '/css/tracy-business-fonts.css')) : ?><link rel="stylesheet" href="<?php echo $tpl; ?>/css/tracy-business-fonts.css"><?php endif; ?>
</head>
<body class="tb-errorpage tb-errorpage--bare">
    <main class="tb-container tb-404 tb-404--bare">
        <div class="tb-404__main">
            <p class="tb-404__code" aria-hidden="true"><?php echo $code; ?></p>
            <h1 class="tb-404__title"><?php echo htmlspecialchars((string) $msg, ENT_QUOTES, 'UTF-8'); ?></h1>
            <p class="tb-404__back"><a class="tb-textlink" href="<?php echo htmlspecialchars($homeUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo $sitename; ?></a></p>
        </div>
    </main>
</body>
</html>
