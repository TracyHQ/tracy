<?php
/**
 * Tracy Business — Projects listing (com_content category, alternative layout `tb-projects`).
 *
 * page-sections.md §4.4: page intro (H1 = the menu item's page heading, lede = the root category's
 * description) → sector chips (the root's child categories, each a real category route; the chip of the
 * category being viewed is active) → the flagship box (the FEATURED article of the listing, with the
 * Area / Steel frame / Duration / Region fields) → the portfolio grid (every other article: photo,
 * SECTOR · YEAR, title, `area · city` from the fields, "View project →") → the modules of position
 * `projects-band` (Sectors + How we run a project, two columns on paper-2) → the modules of position
 * `projects-page` (the ink CTA box). The two positions are rendered HERE, not by the T4 layout, so they
 * appear on the listing only — a project page shares the listing's menu item and would otherwise
 * inherit every bottom-a module.
 *
 * The same file serves /projects/<sector>: the sector categories carry `category_layout =
 * tb-projects`, and the menu item's params (numbers, heading) reach them through the router.
 * Breadcrumbs are the module position, not this view.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

require_once __DIR__ . '/tb-projects_fields.php';

$app    = Factory::getApplication();
$esc    = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$params = $this->params;
$cat    = $this->category;

// --- the tree: the root Projects category and its sectors (this page may be the root or one sector)
$parent   = $cat->getParent();
$isSector = $parent && (int) $parent->id > 1;
$root     = $isSector ? $parent : $cat;
$sectors  = $root->getChildren();
$catUrl   = static fn (int $id): string => Route::_(RouteHelper::getCategoryRoute($id, $cat->language ?? '*'));

// --- copy: H1 from the menu item's page heading, lede from the root category description
$h1   = trim((string) $params->get('page_heading')) !== '' && $params->get('show_page_heading') ? trim((string) $params->get('page_heading')) : $cat->title;
$lede = trim((string) $root->description);
if ($lede === '' && $isSector) $lede = trim((string) $cat->description);
$lede = $lede !== '' ? HTMLHelper::_('content.prepare', $lede, '', 'com_content.category') : '';

// --- items: the featured one is the flagship, the rest the portfolio (dates descending, see the menu params)
$items = is_array($this->items) ? $this->items : [];
$flag  = null; $grid = [];
foreach ($items as $it) {
    if ($flag === null && (int) ($it->featured ?? 0) === 1) { $flag = $it; continue; }
    $grid[] = $it;
}
$years = array_map('ng_article_year', $grid ?: $items);
$range = $years ? (min($years) === max($years) ? min($years) : min($years) . '–' . max($years)) : '';
$flagF = $flag ? ng_project_fields($flag) : [];
$renderPosition = static function (string $position): string {
    $out = '';
    foreach (ModuleHelper::getModules($position) as $m) $out .= ModuleHelper::renderModule($m, ['style' => 'none']);
    return $out;
};
$band  = $renderPosition('projects-band');
$after = $renderPosition('projects-page');
$flagFacts = [];
foreach (['tb-area', 'tb-steel', 'tb-duration', 'tb-region'] as $k) if (ng_pf($flagF, $k) !== '') $flagFacts[$k] = ng_pf($flagF, $k);
?>
<div class="tb-projlist com-content-category<?php echo $this->pageclass_sfx ? ' ' . $esc(trim($this->pageclass_sfx)) : ''; ?>" itemscope itemtype="https://schema.org/CollectionPage">

    <header class="tb-pageintro tb-projlist__intro">
        <div class="tb-container">
            <h1 class="tb-pageintro__title" itemprop="headline"><?php echo $esc($h1); ?></h1>
            <?php if ($lede !== '') : ?><div class="tb-pageintro__lede" itemprop="description"><?php echo $lede; ?></div><?php endif; ?>
            <?php if ($sectors) : ?>
                <nav class="tb-chips tb-proj-chips" aria-label="<?php echo $esc($root->title); ?>">
                    <a class="tb-chip<?php echo $isSector ? '' : ' is-active'; ?>" href="<?php echo $esc($catUrl((int) $root->id)); ?>"<?php echo $isSector ? '' : ' aria-current="page"'; ?>><?php echo Text::_('TPL_TRACY_BUSINESS_ACM_FILTER_ALL'); ?></a>
                    <?php foreach ($sectors as $s) : $on = (int) $s->id === (int) $cat->id; ?>
                        <a class="tb-chip<?php echo $on ? ' is-active' : ''; ?>" href="<?php echo $esc($catUrl((int) $s->id)); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?>><?php echo $esc($s->title); ?></a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </div>
    </header>

    <?php if ($flag) : $url = ng_article_url($flag); $img = ng_article_image($flag, 'image_fulltext'); ?>
        <section class="tb-flagship" aria-labelledby="tb-flagship-title">
            <div class="tb-container">
                <article class="tb-flagship__box">
                    <?php if ($img !== '') : ?>
                        <a class="tb-flagship__media" href="<?php echo $esc($url); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($img); ?>" alt="" width="1200" height="750" loading="eager" decoding="async"></a>
                    <?php endif; ?>
                    <div class="tb-flagship__body">
                        <p class="tb-eyebrow tb-flagship__eyebrow"><?php echo Text::_('TPL_TRACY_BUSINESS_PROJECTS_FLAGSHIP'); ?></p>
                        <h2 class="tb-flagship__title" id="tb-flagship-title"><a href="<?php echo $esc($url); ?>"><?php echo $esc($flag->title); ?></a></h2>
                        <?php if (trim(strip_tags((string) $flag->introtext)) !== '') : ?><div class="tb-flagship__desc"><?php echo $flag->introtext; ?></div><?php endif; ?>
                        <?php if ($flagFacts) : ?>
                            <dl class="tb-flagship__facts">
                                <?php foreach ($flagFacts as $k => $v) : ?>
                                    <div class="tb-flagship__fact"><dt><?php echo $esc(ng_field_label($flagF, $k)); ?></dt><dd><?php echo $esc($v); ?></dd></div>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                        <a class="tb-flagship__link" href="<?php echo $esc($url); ?>"><?php echo Text::_('TPL_TRACY_BUSINESS_PROJECTS_CASE_STUDY'); ?> →</a>
                    </div>
                </article>
            </div>
        </section>
    <?php endif; ?>

    <section class="tb-portfolio" aria-labelledby="tb-portfolio-title">
        <div class="tb-container">
            <header class="tb-portfolio__head">
                <h2 class="tb-section__title tb-portfolio__title" id="tb-portfolio-title"><?php echo Text::_('TPL_TRACY_BUSINESS_PROJECTS_PORTFOLIO'); ?></h2>
                <?php if ($range !== '') : ?><p class="tb-portfolio__meta"><?php echo $esc(Text::sprintf('TPL_TRACY_BUSINESS_PROJECTS_SELECTION', $range)); ?></p><?php endif; ?>
            </header>
            <?php if ($grid) : ?>
                <div class="tb-portfolio__grid">
                    <?php foreach ($grid as $it) : $url = ng_article_url($it); $img = ng_article_image($it, 'image_intro'); $f = ng_project_fields($it); $meta = ng_project_meta($it, $f); ?>
                        <article class="tb-projcard" itemscope itemtype="https://schema.org/CreativeWork">
                            <?php if ($img !== '') : ?>
                                <a class="tb-projcard__media" href="<?php echo $esc($url); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($img); ?>" alt="" width="800" height="450" decoding="async"></a>
                            <?php endif; ?>
                            <p class="tb-projcard__tag"><span class="tb-projcard__cat"><?php echo $esc($it->category_title); ?></span><span class="tb-projcard__dot" aria-hidden="true">·</span><span class="tb-projcard__year"><?php echo $esc(ng_article_year($it)); ?></span></p>
                            <h3 class="tb-projcard__title" itemprop="name"><a href="<?php echo $esc($url); ?>" itemprop="url"><?php echo $esc($it->title); ?></a></h3>
                            <?php if ($meta !== '') : ?><p class="tb-projcard__meta"><?php echo $esc($meta); ?></p><?php endif; ?>
                            <a class="tb-projcard__link" href="<?php echo $esc($url); ?>"><?php echo Text::_('TPL_TRACY_BUSINESS_PROJECTS_VIEW'); ?> →</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php elseif (!$flag) : ?>
                <p class="tb-portfolio__empty"><?php echo Text::_('COM_CONTENT_NO_ARTICLES'); ?></p>
            <?php endif; ?>
            <?php if ($params->get('show_pagination', 1) && $this->pagination->pagesTotal > 1) : ?>
                <div class="tb-portfolio__pagination"><?php echo $this->pagination->getPagesLinks(); ?></div>
            <?php endif; ?>
        </div>
    </section>

    <?php if (trim($band) !== '') : ?>
        <section class="tb-proj-band tb-proj-bleed">
            <div class="tb-container tb-proj-band__grid"><?php echo $band; ?></div>
        </section>
    <?php endif; ?>
    <?php if (trim($after) !== '') : ?>
        <div class="tb-projlist__after"><?php echo $after; ?></div>
    <?php endif; ?>
</div>
