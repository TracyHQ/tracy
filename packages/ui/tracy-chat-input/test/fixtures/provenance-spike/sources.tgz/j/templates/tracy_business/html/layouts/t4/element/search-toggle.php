<?php

/**
 * Tracy Business — search toggle.
 *
 * Reveals the `search` module position instead of shipping a second search form: whatever search
 * module the owner publishes there is what opens, so this control never goes stale against the
 * site's actual search extension.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
?>
<button type="button" class="tb-iconbtn tb-header__search" data-tb-search-toggle
        aria-expanded="false" aria-controls="tb-searchpanel"
        aria-label="<?php echo htmlspecialchars(Text::_('TPL_TRACY_BUSINESS_SEARCH_ARIA'), ENT_QUOTES, 'UTF-8'); ?>">
    <span class="tb-iconbtn__glyph" aria-hidden="true">&#9906;</span>
</button>
