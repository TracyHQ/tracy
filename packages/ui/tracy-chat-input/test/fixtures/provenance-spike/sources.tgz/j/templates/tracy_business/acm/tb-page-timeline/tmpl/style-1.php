<?php
/** Tracy Business — ACM `tb-page-timeline`: H2 with a hairline, then rows of year (signal Newsreader) · title · line. About "History". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('year'); $i < $n; $i++) { $y = trim((string) $helper->get('year', $i)); $t = trim((string) $helper->get('row-title', $i)); if ($y !== '' || $t !== '') $rows[] = [$y, $t, trim((string) $helper->get('row-desc', $i))]; }
if (!$rows) return;
$id = 'tb-pg-timeline-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-timeline tb-pg-timeline" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--rule" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <ol class="tb-pg-timeline__list">
      <?php foreach ($rows as [$y, $t, $d]) : ?>
        <li class="tb-pg-timeline__row"><span class="tb-pg-timeline__year"><?php echo $esc($y); ?></span><strong class="tb-pg-timeline__title"><?php echo $esc($t); ?></strong><p class="tb-pg-timeline__desc"><?php echo $esc($d); ?></p></li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>
