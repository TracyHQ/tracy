<?php
/** Tracy Business — ACM `tb-kit-newsletter-body`: the lower half of the digest email — "Also in this issue" rows and the Paper-2 footer with unsubscribe / preferences (plain text unless a link is set). */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$itemsT = trim((string) $helper->get('items-title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('item-title'); $i < $n; $i++) { $t = trim((string) $helper->get('item-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('item-desc', $i)), $route((string) $helper->get('item-link', $i))]; }
$foot = trim((string) $helper->get('foot-text'));
$links = [];
foreach (['unsub', 'prefs'] as $k) { $t = trim((string) $helper->get($k . '-text')); if ($t !== '') $links[] = [$t, $route((string) $helper->get($k . '-link'))]; }
if (!$rows && $foot === '') return;
?>
<div class="ja-acm acm-tb-kit-newsletter-body tb-kitnl__body" id="tb-kitnl-body-<?php echo (int) $module->id; ?>">
  <?php if ($rows) : ?>
    <div class="tb-kitnl__also">
      <?php if ($itemsT !== '') : ?><p class="tb-kitnl__also-title"><?php echo $esc($itemsT); ?></p><?php endif; ?>
      <ul class="tb-kitnl__list">
        <?php foreach ($rows as [$t, $d, $l]) : ?>
          <li class="tb-kitnl__item">
            <?php if ($l !== '') : ?><a class="tb-kitnl__item-title" href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><strong class="tb-kitnl__item-title"><?php echo $esc($t); ?></strong><?php endif; ?>
            <?php if ($d !== '') : ?><span class="tb-kitnl__item-desc"><?php echo $esc($d); ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <?php if ($foot !== '' || $links) : ?>
    <div class="tb-kitnl__foot">
      <?php if ($foot !== '') : ?><p class="tb-kitnl__foot-text"><?php echo $esc($foot); ?></p><?php endif; ?>
      <?php if ($links) : ?><p class="tb-kitnl__foot-links"><?php foreach ($links as [$t, $l]) : ?><?php if ($l !== '') : ?><a href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><span><?php echo $esc($t); ?></span><?php endif; ?><?php endforeach; ?></p><?php endif; ?>
    </div>
  <?php endif; ?>
</div>
