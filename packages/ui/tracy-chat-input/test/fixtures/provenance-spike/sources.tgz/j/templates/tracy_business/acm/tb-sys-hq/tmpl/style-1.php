<?php
/** Tracy Business — ACM `tb-sys-hq`: the dark HEAD OFFICE box — eyebrow, two address lines, label/value rows. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$label = trim((string) $helper->get('label')); $addr1 = trim((string) $helper->get('addr1')); $addr2 = trim((string) $helper->get('addr2'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-label'); $i < $n; $i++) { $l = trim((string) $helper->get('row-label', $i)); $v = trim((string) $helper->get('row-value', $i)); if ($l !== '' || $v !== '') $rows[] = [$l, $v]; }
if ($addr1 === '' && $addr2 === '' && !$rows) return;
$link = static function (string $v) use ($esc): string {
    if (filter_var($v, FILTER_VALIDATE_EMAIL)) return '<a href="mailto:' . $esc($v) . '">' . $esc($v) . '</a>';
    if (preg_match('/^\+?[\d][\d\s().-]{6,}$/', $v)) return '<a href="tel:' . $esc(preg_replace('/[^0-9+]/', '', $v)) . '">' . $esc($v) . '</a>';
    return $esc($v);
};
?>
<div class="ja-acm acm-tb-sys-hq tb-hq">
  <?php if ($label !== '') : ?><p class="tb-hq__eyebrow"><?php echo $esc($label); ?></p><?php endif; ?>
  <?php if ($addr1 !== '' || $addr2 !== '') : ?><p class="tb-hq__addr"><?php echo $esc($addr1); ?><?php if ($addr1 !== '' && $addr2 !== '') : ?><br><?php endif; ?><?php echo $esc($addr2); ?></p><?php endif; ?>
  <?php if ($rows) : ?>
    <dl class="tb-hq__rows">
      <?php foreach ($rows as [$l, $v]) : ?><div class="tb-hq__row"><dt><?php echo $esc($l); ?></dt><dd><?php echo $link($v); ?></dd></div><?php endforeach; ?>
    </dl>
  <?php endif; ?>
</div>
