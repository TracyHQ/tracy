<?php
/** Tracy Business — ACM `tb-page-life`: ink band — H2, a row of 16:9 photos with captions, and a quote with a signal rule on the left. Careers "Life on our sites". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title')); $quote = trim((string) $helper->get('quote')); $by = trim((string) $helper->get('quote-by'));
$photos = [];
for ($i = 0, $n = (int) $helper->getRows('caption'); $i < $n; $i++) { $p = $img((string) $helper->get('photo', $i)); $c = trim((string) $helper->get('caption', $i)); if ($p !== '' || $c !== '') $photos[] = [$p, $c]; }
if (!$photos && $quote === '') return;
$id = 'tb-pg-life-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-life tb-pg-band tb-pg-band--ink tb-pg-life" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <div class="tb-container">
    <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
    <?php if ($photos) : ?>
      <ul class="tb-pg-life__grid">
        <?php foreach ($photos as [$p, $c]) : ?>
          <li class="tb-pg-life__item">
            <?php if ($p !== '') : ?><figure class="tb-pg-life__photo"><img src="<?php echo $esc($p); ?>" alt="<?php echo $esc($c); ?>" loading="lazy" decoding="async"></figure><?php else : ?><div class="tb-pg-life__photo tb-pg-life__photo--empty" aria-hidden="true"></div><?php endif; ?>
            <?php if ($c !== '') : ?><span class="tb-pg-life__caption"><?php echo $esc($c); ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <?php if ($quote !== '') : ?>
      <blockquote class="tb-pg-quote"><p class="tb-pg-quote__text"><?php echo $esc($quote); ?></p><?php if ($by !== '') : ?><footer class="tb-pg-quote__by"><?php echo $esc($by); ?></footer><?php endif; ?></blockquote>
    <?php endif; ?>
  </div>
</section>
