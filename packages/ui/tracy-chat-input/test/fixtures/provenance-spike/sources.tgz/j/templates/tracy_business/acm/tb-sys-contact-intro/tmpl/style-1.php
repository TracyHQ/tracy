<?php
/**
 * Tracy Business — ACM `tb-sys-contact-intro`: the contact page's lede, the notice box and the form
 * labels. The com_contact layout (html/com_contact/contact/default.php) READS this module from the
 * `contact-page` position and places each field where the design puts it, so on its own the block
 * only renders the lede and the notice — enough to see what is stored when it lands elsewhere.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$lede = trim((string) $helper->get('lede')); $notice = trim((string) $helper->get('notice'));
if ($lede === '' && $notice === '') return;
?>
<div class="ja-acm acm-tb-sys-contact-intro tb-contact-intro">
  <?php if ($lede !== '') : ?><p class="tb-pageintro__lede"><?php echo $esc($lede); ?></p><?php endif; ?>
  <?php if ($notice !== '') : ?><div class="tb-notice"><span class="tb-notice__i" aria-hidden="true">i</span><p><?php echo $esc($notice); ?></p></div><?php endif; ?>
</div>
