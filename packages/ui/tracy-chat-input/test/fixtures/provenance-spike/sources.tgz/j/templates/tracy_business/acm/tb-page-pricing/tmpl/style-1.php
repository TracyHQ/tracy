<?php
/** Tracy Business — ACM `tb-page-pricing`: "Indicative pricing" — H2, a note, and a bordered list of rows (title + line on the left, "from ₽…" in forest on the right). A column; sits beside `tb-process` in a split row. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title')); $intro = trim((string) $helper->get('intro'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-price', $i)), trim((string) $helper->get('row-desc', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-page-pricing tb-pg-pricing" id="tb-pg-pricing-<?php echo (int) $module->id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-pg-h2 tb-pg-h2--sm tb-pg-pricing__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <?php if ($intro !== '') : ?><p class="tb-pg-pricing__intro"><?php echo $esc($intro); ?></p><?php endif; ?>
  <ul class="tb-pg-pricing__list">
    <?php foreach ($rows as [$t, $v, $d]) : ?><li class="tb-pg-pricing__row"><div><strong class="tb-pg-pricing__name"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><span class="tb-pg-pricing__desc"><?php echo $esc($d); ?></span><?php endif; ?></div><span class="tb-pg-pricing__price"><?php echo $esc($v); ?></span></li><?php endforeach; ?>
  </ul>
</div>
