# Languages — what is installed, how to add one, how to drop one

The site runs **English (en-GB, base) and Russian (ru-RU)**. Twelve more Joomla language packs are
**installed but not enabled** (their content language is unpublished — nothing shows on the site),
so a customer in one of those markets can be switched on without downloading anything. Every other
accredited Joomla translation (60 in total across Joomla 4/5/6) can be added with one command;
`language-packs.json` next to this file is the catalogue.

## Installed packs

| tag | language | pack | note |
|---|---|---|---|
| en-GB | English | core | base language — never removed |
| ru-RU | Russian | 6.1.1 | live, hand-translated content |
| zh-CN | Chinese, Simplified | 6.0.1 | installed, off |
| ja-JP | Japanese | 6.1.3 | installed, off |
| ko-KR | Korean | **5.0.2** | installed, off — no Joomla 6 pack exists; strings 6.x added fall back to English |
| de-DE | German | 6.1.3 | installed, off |
| fr-FR | French | 6.1.3 | installed, off |
| es-ES | Spanish | 6.1.3 | installed, off |
| pt-BR | Portuguese, Brazil | 6.0.3 | installed, off |
| it-IT | Italian | 6.1.3 | installed, off |
| tr-TR | Turkish | 6.1.3 | installed, off |
| th-TH | Thai | 6.0.0 | installed, off |
| pl-PL | Polish | 6.0.0 | installed, off |
| ms-MY | Malay | 6.1.3 | installed, off |

A pack is only the **Joomla core UI strings** (admin, system messages, "Read more"). Everything a
visitor reads on this site — pages, menus, blocks, the template's own labels — is content, and a
new language needs its own copy of all of it. That is what the script below builds.

## Add a language

```bash
php templates/tracy_business/tools/add-language.php ko-KR            # from the webroot, PHP CLI
php templates/tracy_business/tools/add-language.php vi-VN --dry-run  # list what it would do
```

What it does (all rows carry the note `lang:<tag>`):

1. Installs the official pack if missing — Joomla 6 pack first, else 5, else 4 (`language-packs.json`,
   sha256-pinned). Older packs install and run; the strings they lack fall back to English.
2. Publishes the content language (`/xx/` = the lowercase 639-1 code; `--sef` to override).
3. Clones from English (`--from` to clone from another language): content + contact categories,
   tags (alias gets a `-xx` suffix — Joomla wants tag aliases unique), every published article
   with its custom-field values and tags, the contact, the six `tb-*-xx` menus with all items
   (home included, links and alias targets remapped), all 81 modules with their menu assignment
   and inner ids remapped, the T4 megamenu block for `tb-main-xx`, the template strings
   (`xx-YY.tpl_tracy_business.ini` in the template and in `/language/xx-YY/`) and the override file.
4. Creates the EN↔new associations (categories, articles, contact, menu items).
5. Clears the T4 cache.

The new language is live at once **with English text** — by design: the structure is complete and
correct (routes, breadcrumbs, switcher, hreflang, megamenu), and every item is ready to be
translated in place. Translate through the Cowork door (`cowork-api.md`: `content.list` kind
`article` filtered to the language, `content.update` per item under one `apply_id`) or in Admin.
Unpublish what must not show until it is translated; never machine-translate the customer's facts.

Measured on this site (2026-09-13, `ko-KR`): 19 categories, 4 tags, 43 articles, 1 contact, 6 menus /
38 items, 81 modules in ~20 s; audit afterwards 0 broken links, 0 overflow, switcher 3 languages.

## Remove a language

```bash
php templates/tracy_business/tools/remove-language.php ko-KR                   # rows made by add-language
php templates/tracy_business/tools/remove-language.php ru-RU --force           # a hand-built language: every ru-RU row
php templates/tracy_business/tools/remove-language.php ko-KR --uninstall-pack  # also drop the 3 MB pack
```

Deletes the language's articles (with field values, tags, featured rows), categories, tags,
contact, menu items and the `tb-*-xx` menu types, modules and assignments, associations (a
pair loses its key; a group of three keeps the other two), the megamenu block, the template strings
and override file; unpublishes the content language; rebuilds the trees; clears the cache. Without
`--force` it refuses when any row lacks the `lang:<tag>` note, so the original Russian (built by
hand) is only removed on purpose. `en-GB` cannot be removed. Take a DB dump first
(`checks.md`) — this is the one operation that deletes content.

## Add a language that has no Joomla pack at all

`language-packs.json` covers 60 tags. For anything else (Hindi, Indonesian, …) install a pack by
hand if a third party publishes one, or create the content language in Admin (System → Content
Languages) and run `add-language.php <tag>` — it skips the pack step when the content language
already exists — then the admin UI stays English for that tag.

## Verify after either command

`checks.md`: full audit (it follows the language switcher, so the new language is crawled),
`mega-hover.mjs http://<site>/xx/`, `interact.mjs` (`langOptions` lists it), and the counts at the end
of the script's output. Then regenerate `site-map.md`/`inventory.md` (`gen-docs.php`).
