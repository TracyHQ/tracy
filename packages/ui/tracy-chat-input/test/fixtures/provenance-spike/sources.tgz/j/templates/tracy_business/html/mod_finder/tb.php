<?php

/**
 * Tracy Business — Smart Search box for the header search panel.
 * Core markup, the design's field + forest button, no autosuggest chrome (the panel is transient).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$app->getLanguage()->load('com_finder', JPATH_SITE);
$finderHelper = $app->bootModule('mod_finder', 'site')->getHelper('FinderHelper');
$q = htmlspecialchars($app->getInput()->get('q', '', 'string'), ENT_QUOTES, 'UTF-8');
$id = 'mod-finder-searchword' . (int) $module->id;
?>
<search>
    <form class="mod-finder js-finder-searchform form-search" action="<?php echo Route::_($route); ?>" method="get" aria-label="<?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_ARIA'); ?>">
        <label for="<?php echo $id; ?>" class="visually-hidden"><?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_ARIA'); ?></label>
        <div class="tb-search">
            <input type="search" name="q" id="<?php echo $id; ?>" value="<?php echo $q; ?>" placeholder="<?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_PLACEHOLDER'); ?>" autocomplete="off">
            <button class="tb-btn tb-btn--forest" type="submit"><?php echo Text::_('TPL_TRACY_BUSINESS_SEARCH_ARIA'); ?></button>
        </div>
        <?php echo $finderHelper->getHiddenFields($route); ?>
    </form>
</search>
