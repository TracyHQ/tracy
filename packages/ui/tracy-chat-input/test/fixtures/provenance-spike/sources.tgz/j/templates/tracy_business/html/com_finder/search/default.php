<?php

/**
 * Tracy Business — Smart Search page.
 *
 * No breadcrumb (the breadcrumbs module is unassigned from this item). H1, the big query box with
 * the ink button, the "N results for …" line from the real count, then two columns: the result
 * list on the left and, on the right, whatever is published in the `search-page` position — the
 * section filter (mod_finder, layout tb-page) and the popular-searches chips. Advanced
 * search is deliberately not drawn: the section filter in the sidebar is the design's filter.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Language\Text;

/** @var \Joomla\Component\Finder\Site\View\Search\HtmlView $this */
$this->getDocument()->getWebAssetManager()->useStyle('com_finder.finder')->useScript('com_finder.finder');

$esc      = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$searched = $this->query->search === true;
$aside    = ModuleHelper::getModules('search-page');
$total    = (int) ($this->total ?? 0);
$byRelevance = ($this->state->get('list.raworder') ?? 'relevance') === 'relevance';
?>
<div class="com-finder finder tb-search">
    <div class="tb-container">
        <h1 class="tb-search__title"><?php echo Text::_('TPL_TRACY_BUSINESS_SYS_SEARCH_TITLE'); ?></h1>

        <?php if ($this->params->get('show_search_form', 1)) : ?>
            <div id="search-form" class="com-finder__form tb-search__form"><?php echo $this->loadTemplate('form'); ?></div>
        <?php endif; ?>

        <?php if ($searched && $total > 0) : ?>
            <p class="tb-search__line">
                <?php echo Text::plural('TPL_TRACY_BUSINESS_SYS_SEARCH_LINE', $total, $esc($this->query->input)); ?>
                <?php if ($byRelevance) : ?><span class="tb-search__sep" aria-hidden="true"> · </span><?php echo Text::_('TPL_TRACY_BUSINESS_SYS_SEARCH_SORTED_RELEVANCE'); ?><?php endif; ?>
            </p>
        <?php endif; ?>

        <div class="tb-search__body">
            <div class="tb-search__main">
                <?php if ($searched) : ?>
                    <div id="search-results" class="com-finder__results"><?php echo $this->loadTemplate('results'); ?></div>
                <?php endif; ?>
            </div>
            <?php if ($aside) : ?>
                <aside class="tb-search__aside">
                    <?php foreach ($aside as $mod) : ?><?php echo ModuleHelper::renderModule($mod, ['style' => 'none']); ?><?php endforeach; ?>
                </aside>
            <?php endif; ?>
        </div>
    </div>
</div>
