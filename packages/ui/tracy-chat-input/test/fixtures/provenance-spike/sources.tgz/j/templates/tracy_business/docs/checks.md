# Checks — the commands that decide whether a change is done

**These commands run on the build machine only** — `$W` = the workspace folder holding
`webroot/`, `$T` = `$W/webroot/templates/tracy_business`, `$S` = the JoomlArt T4 skill checkout
that ships the compile/clear/review scripts. None of it is installed on a live server; there, use
the Admin equivalent noted under each step and say in your report which checks you could not run.

## Every time, in this order

```bash
bash $S/scripts/compile-scss.sh --template $T      # only if SCSS changed; stops on error
bash $S/scripts/clear-cache.sh --root $W/webroot   # ALWAYS — T4 serves media/t4/optimize bundles
```
Admin equivalent for the cache: System → Clear Cache, then open the template style and Save (T4
rebuilds `media/t4/optimize`). Without this you are looking at the previous build.

## The door answers

```bash
curl -s -X POST -H 'Content-Type: application/json' -d '{"token":"…","action":"info"}' \
  'http://127.0.0.1:8230/index.php?option=com_claudecowork&task=api.exec&format=json'
```
`{"ok":true,…}` before any content work; `unauthorized` means the token you read is not this
site's. After a task: `apply.list` with your `apply_id` is the change log to quote in the report,
and `apply.revert` is the way back (`cowork-api.md` §4).

## Full site audit — links, overflow, console, resources, language keys, switcher

```bash
node $W/tools/audit.mjs $W/evidence/final 120       # ~10 min, writes audit.md + audit.json
```
Pass = `badLinks 0 · overflow 0 · renderErrors 0 · consoleErrors 0 · failedResources 0 ·
rawLanguageKeys 0 · placeholders 0 · langSwitchBroken 0 · homeHasCrumbs 0`. `emptyPages` is
expected to list exactly `/en/terms /en/privacy /ru/terms /ru/privacy` until the owner supplies
that text; any other entry is a regression. It crawls from `/en/` and `/ru/`, so a new page is
covered only once it is linked. Admin equivalent: none — this is the one check that needs the
workspace.

## Interaction probe — hover, focus order, Escape, theme toggle, switcher, drawer, search

```bash
node $W/tools/interact.mjs $W/evidence/r4           # prints JSON; errs must be []
```

## Megamenu reachability — a panel a mouse can actually enter

```bash
node $S/scripts/review/mega-hover.mjs http://127.0.0.1:8230/en/                 # exit 0 = PASS
node $S/scripts/review/mega-hover.mjs http://127.0.0.1:8230/ru/ --viewport 1024
```
Run per language, at the desktop breakpoint and at 1024. Forcing the panel open for a screenshot
proves nothing about this.

## One page, all viewports and themes

```bash
node $W/tools/shot.mjs "http://127.0.0.1:8230/en/<path>" $W/evidence/<area>/<slug> "1440,1024,768,390" "light,dark"
node $W/tools/cs.mjs "<url>" "<selector>|<selector>" 1440 light   # computed style numbers
```
`shot.mjs` prints `overflow=` and `errs=` per variant; both must be clean.

## Admin round trip — is the block really editable?

```bash
node $W/tools/admin-edit.mjs $W/evidence/r6          # edits a hero field, checks the front, restores
```

## Mail — not covered by any script

`com_contact` sending is decided by System → Global Configuration → Mail (`mailonline`). The audit
cannot see it: a site can pass every check above with a contact form that only shows "mail is
disabled". Before a hand-over to production, submit the form once with a real mailbox.

## PHP log

```bash
docker compose -p northgate logs --since 30m web | grep -iE "php (warning|notice|fatal)"   # must be empty
```

## After add-language / remove-language

The script prints its counts; then the full audit (it follows the switcher into the new language),
`mega-hover.mjs http://127.0.0.1:8230/<sef>/`, `interact.mjs` (`langOptions`), and `gen-docs.php`.

## Regenerate the reference docs after content changes

```bash
$W/tools/j/run.sh $W/tools/j/gen-docs.php            # rewrites docs/site-map, inventory, blocks, positions
```

## What "done" means

All of the above green, both languages, both themes, 1440 and 390 — **and** the report says what
was run and what it printed. A change that could not be checked by one of these is reported as
"unverified", not as done.
