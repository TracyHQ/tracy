<?php
/**
 * Tracy Business — shared readers for the project custom fields (com_fields, group "Project", names `tb-*`).
 * Used by the Projects listing (category/tb-projects.php) and the project page
 * (article/tb-project.php). Everything reads the RAW value — the layouts do their own markup —
 * so a field the admin leaves empty simply does not render; nothing is invented.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\MediaHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;

if (!function_exists('ng_project_fields')) {
    /**
     * name → ['value' => raw string, 'label' => admin label] for every `tb-*` field of an article.
     * Uses $item->jcfields when the fields plugin already ran, otherwise asks com_fields directly.
     */
    function ng_project_fields(object $item): array
    {
        $fields = isset($item->jcfields) && is_array($item->jcfields) && $item->jcfields
            ? $item->jcfields
            : FieldsHelper::getFields('com_content.article', $item, false);
        $out = [];
        foreach ($fields as $f) {
            if (strpos((string) $f->name, 'tb-') !== 0) continue;
            $raw = $f->rawvalue ?? $f->value ?? '';
            if (is_array($raw)) $raw = json_encode($raw);
            $raw = trim((string) $raw);
            if ($raw === '') continue;
            $out[$f->name] = ['value' => $raw, 'label' => (string) $f->label];
        }
        return $out;
    }

    /** raw value of one field, '' when unset */
    function ng_pf(array $fields, string $name): string
    {
        return $fields[$name]['value'] ?? '';
    }

    /** the label a visitor sees: TPL_TRACY_BUSINESS_FIELD_<NAME> when the template translates it, else the admin label */
    function ng_field_label(array $fields, string $name): string
    {
        $key = 'TPL_TRACY_BUSINESS_FIELD_' . strtoupper(str_replace('-', '_', substr($name, 3)));
        return Factory::getLanguage()->hasKey($key) ? Text::_($key) : ($fields[$name]['label'] ?? $name);
    }

    /** a media value (plain path, `path#joomlaImage://…`, or the media field's JSON) → site URL, '' when empty */
    function ng_image_url($value): string
    {
        if (is_string($value) && $value !== '' && $value[0] === '{') {
            $decoded = json_decode($value, true);
            if (is_array($decoded)) $value = $decoded;
        }
        if (is_array($value)) $value = $value['imagefile'] ?? '';
        $src = MediaHelper::getCleanMediaFieldValue((string) $value);
        if ($src === '') return '';
        if (!preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $src)) $src = Uri::root(true) . '/' . $src;
        return $src;
    }

    /** the subform gallery → [['src' => url, 'caption' => text, 'alt' => text], …] (rows without an image are skipped) */
    function ng_project_gallery(array $fields): array
    {
        $raw = ng_pf($fields, 'tb-gallery');
        $rows = $raw !== '' ? json_decode($raw, true) : null;
        if (!is_array($rows)) return [];
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $src = ''; $caption = ''; $alt = '';
            foreach ($row as $cell) {   // cells are keyed field<id>: the media one decodes to an image, the text one is the caption
                $decoded = is_string($cell) && $cell !== '' && $cell[0] === '{' ? json_decode($cell, true) : null;
                if (is_array($cell) || is_array($decoded)) {
                    $media = is_array($cell) ? $cell : $decoded;
                    if (isset($media['imagefile'])) { $src = ng_image_url($media); $alt = (string) ($media['alt_text'] ?? ''); continue; }
                }
                if (is_string($cell) && $src === '' && preg_match('~\.(png|jpe?g|webp|gif|svg|avif)(#|$)~i', $cell)) { $src = ng_image_url($cell); continue; }
                if (is_string($cell) && trim($cell) !== '') $caption = trim($cell);
            }
            if ($src !== '') $out[] = ['src' => $src, 'caption' => $caption, 'alt' => $alt !== '' ? $alt : $caption];
        }
        return $out;
    }

    /** intro / full image of an article row (images JSON) → site URL */
    function ng_article_image(object $item, string $which = 'image_intro'): string
    {
        $images = is_string($item->images ?? null) ? (json_decode((string) $item->images, true) ?: []) : (array) ($item->images ?? []);
        $src = ng_image_url($images[$which] ?? '');
        if ($src === '' && $which === 'image_fulltext') $src = ng_image_url($images['image_intro'] ?? '');
        if ($src === '' && $which === 'image_intro') $src = ng_image_url($images['image_fulltext'] ?? '');
        return $src;
    }

    /** route to an article row */
    function ng_article_url(object $item): string
    {
        $slug = !empty($item->alias) ? $item->id . ':' . $item->alias : (string) $item->id;
        return Route::_(RouteHelper::getArticleRoute($slug, $item->catid, $item->language ?? '*'));
    }

    /** year an article was published */
    function ng_article_year(object $item): string
    {
        return HTMLHelper::_('date', $item->publish_up ?: $item->created, 'Y');
    }

    /** the "area · city" line of a list card — fields only; an article without them shows no line */
    function ng_project_meta(object $item, array $fields): string
    {
        return implode(' · ', array_filter([ng_pf($fields, 'tb-area'), ng_pf($fields, 'tb-city')], static fn ($v) => $v !== ''));
    }

    /**
     * Newest published articles of a category tree, minus one — the "Other projects" strip. Articles from the
     * same category come first, then the rest of the tree, so the strip is full even in a small sector.
     */
    function ng_related_projects(object $item, int $limit = 4): array
    {
        $app   = Factory::getApplication();
        $db    = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
        $cats  = $db->setQuery('SELECT parent_id FROM #__categories WHERE id = ' . (int) $item->catid)->loadResult();
        $root  = (int) $cats > 1 ? (int) $cats : (int) $item->catid;   // the tree root = the parent, or the category itself at top level
        $model = $app->bootComponent('com_content')->getMVCFactory()->createModel('Articles', 'Site', ['ignore_request' => true]);
        $model->setState('params', clone \Joomla\CMS\Component\ComponentHelper::getParams('com_content'));
        $model->setState('filter.category_id', $root);
        $model->setState('filter.subcategories', true);
        $model->setState('filter.max_category_levels', 2);
        $model->setState('filter.published', 1);
        $model->setState('filter.access', true);
        $model->setState('filter.language', $app->getLanguageFilter());
        $model->setState('list.start', 0);
        $model->setState('list.limit', 0);
        $model->setState('list.ordering', 'a.publish_up');
        $model->setState('list.direction', 'DESC');
        $same = []; $rest = [];
        foreach ($model->getItems() as $a) {
            if ((int) $a->id === (int) $item->id) continue;
            if ((int) $a->catid === (int) $item->catid) $same[] = $a; else $rest[] = $a;
        }
        return array_slice(array_merge($same, $rest), 0, $limit);
    }

    /** the Contact page of the current language (a com_contact menu item), '' when the site has none */
    function ng_contact_url(): string
    {
        $app  = Factory::getApplication();
        $lang = Factory::getLanguage()->getTag();
        foreach ($app->getMenu()->getItems('component', 'com_contact') as $m) {
            if ($m->type === 'component' && in_array($m->language, ['*', $lang], true)) return Route::_('index.php?Itemid=' . (int) $m->id);
        }
        return '';
    }
}
