<?php

/**
 * Tracy Business — com_contact mail form, laid out as the design's form card.
 *
 * Every control here is Joomla's own and posts to contact.submit: name, email, subject, message,
 * the optional copy-to-sender box and the captcha fieldset when one is enabled. The design's
 * "Request type" chips are the SUBJECT field rendered as a radio group (the chosen label becomes
 * the mail subject) when the intro module lists choices; with no choices it is the plain text
 * subject. "Clear form" is a native reset button. What core has no field for — company, phone,
 * file upload, the 152-FZ consent box — is not drawn: a control that looks live but posts nothing
 * is worse than a missing one (see NOTES-system.md).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')->useScript('form.validate');

$esc   = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$intro = $this->item->ngIntro ?? null;
$g     = static fn (string $k) => $intro ? trim((string) $intro->get($k)) : '';
$form  = $this->form;

foreach (['contact_name' => 'ph-name', 'contact_email' => 'ph-email', 'contact_message' => 'ph-message'] as $name => $key) {
    if ($g($key) !== '') $form->setFieldAttribute($name, 'hint', $g($key));
}
$form->setFieldAttribute('contact_message', 'rows', '5');

$types = [];
if ($intro) for ($i = 0, $n = (int) $intro->getRows('type'); $i < $n; $i++) { $t = trim((string) $intro->get('type', $i)); if ($t !== '') $types[] = $t; }

$notice  = $g('notice');
$submit  = $g('submit') !== '' ? $g('submit') : Text::_('COM_CONTACT_CONTACT_SEND');
$reset   = $g('reset');
$label = static function (string $name, string $override = '') use ($form, $esc): string {
    $f = $form->getField($name);
    if (!$f) return '';
    $text = $override !== '' ? $override : Text::_($f->title);
    return '<label class="tb-field__label" for="' . $esc($f->id) . '">' . $esc($text) . ($f->required ? ' <span class="tb-req" aria-hidden="true">*</span>' : '') . '</label>';
};
$fieldId = static fn (string $name) => $form->getField($name) ? $form->getField($name)->id : $name;
?>
<?php if (isset($this->error)) : ?>
    <p class="tb-field__error contact-error"><?php echo $this->error; ?></p>
<?php endif; ?>

<div class="com-contact__form contact-form">
    <form id="contact-form" action="<?php echo Route::_('index.php'); ?>" method="post" class="form-validate tb-form">

        <?php if ($notice !== '') : ?>
            <div class="tb-notice"><span class="tb-notice__i" aria-hidden="true">i</span><p><?php echo $esc($notice); ?></p></div>
        <?php endif; ?>

        <div class="tb-form__grid">
            <div class="tb-field-group contact-contact_name">
                <?php echo $label('contact_name'); ?>
                <?php echo $form->getInput('contact_name'); ?>
            </div>
            <div class="tb-field-group contact-contact_email">
                <?php echo $label('contact_email'); ?>
                <?php echo $form->getInput('contact_email'); ?>
            </div>
        </div>

        <div class="tb-field-group contact-contact_subject">
            <?php if ($types) : ?>
                <fieldset class="tb-chipradio">
                    <legend class="tb-field__label"><?php echo $esc($g('subject-label') !== '' ? $g('subject-label') : Text::_($form->getField('contact_subject')->title)); ?> <span class="tb-req" aria-hidden="true">*</span></legend>
                    <div class="tb-chipradio__list">
                        <?php foreach ($types as $i => $t) : ?>
                            <?php $id = 'tb-subject-' . $i; ?>
                            <input type="radio" class="tb-chipradio__input" id="<?php echo $id; ?>" name="jform[contact_subject]" value="<?php echo $esc($t); ?>"<?php echo $i === 0 ? ' checked' : ''; ?> required>
                            <label class="tb-chip tb-chipradio__chip" for="<?php echo $id; ?>"><?php echo $esc($t); ?></label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            <?php else : ?>
                <?php echo $label('contact_subject', $g('subject-label')); ?>
                <?php echo $form->getInput('contact_subject'); ?>
            <?php endif; ?>
        </div>

        <div class="tb-field-group contact-contact_message">
            <?php echo $label('contact_message', $g('message-label')); ?>
            <?php echo $form->getInput('contact_message'); ?>
        </div>

        <?php // Fieldsets a plugin adds (captcha, privacy consent) keep working — they are rendered as Joomla gives them. ?>
        <?php foreach ($form->getFieldsets() as $fieldset) : ?>
            <?php if ($fieldset->name === 'contact' || ($fieldset->name === 'captcha' && !$this->captchaEnabled)) continue; ?>
            <?php $fields = $form->getFieldset($fieldset->name); if (!count($fields)) continue; ?>
            <?php foreach ($fields as $field) : ?>
                <?php if ($field->hidden) : ?>
                    <?php echo $field->input; ?>
                <?php else : ?>
                    <div class="tb-field-group"><?php echo $field->label; ?><?php echo $field->input; ?></div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endforeach; ?>

        <?php if ($this->params->get('show_email_copy')) : ?>
            <div class="tb-check email-copy">
                <?php echo $form->getInput('contact_email_copy'); ?>
                <?php echo $form->getLabel('contact_email_copy'); ?>
            </div>
        <?php endif; ?>

        <div class="tb-form__actions">
            <button class="tb-btn tb-btn--signal tb-btn--lg validate" type="submit"><?php echo $esc($submit); ?></button>
            <?php if ($reset !== '') : ?><button class="tb-btn tb-btn--outline tb-btn--lg" type="reset"><?php echo $esc($reset); ?></button><?php endif; ?>
        </div>

        <input type="hidden" name="option" value="com_contact">
        <input type="hidden" name="task" value="contact.submit">
        <input type="hidden" name="return" value="<?php echo $esc($this->return_page ?? ''); ?>">
        <input type="hidden" name="id" value="<?php echo $esc($this->item->slug ?? ''); ?>">
        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
</div>
