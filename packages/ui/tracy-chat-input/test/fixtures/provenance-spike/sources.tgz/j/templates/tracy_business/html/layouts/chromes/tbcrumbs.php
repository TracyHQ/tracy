<?php

/**
 * Tracy Business — chrome for the breadcrumb band: the Paper-2 strip with the 1240px inner column.
 * Renders nothing when the module has no output (e.g. the home page), so no empty band appears.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

$module = $displayData['module'];

if (empty($module->content)) {
    return;
}
?>
<div class="tb-crumbband" id="Mod<?php echo (int) $module->id; ?>">
    <div class="tb-container tb-crumbband__inner"><?php echo $module->content; ?></div>
</div>
