<?php

/**
 * Tracy Business — com_contact single-contact page.
 *
 * Page intro (H1 = the menu page heading, lede from the `tb-sys-contact-intro` module), then two
 * columns: the white form card on the left and, on the right, every module published in the
 * `contact-page` position in its ordering (head office box, map, branches, social profiles). The
 * intro module is read for its fields and not rendered as a block; everything else is rendered
 * with the "none" chrome. Nothing on this page is baked copy: the form is Joomla's real mail form
 * (see default_form.php), the rest is Module Manager content.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$esc      = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$tparams  = $this->item->params;
$showForm = $tparams->get('show_email_form') && ($this->item->email_to || $this->item->user_id);
$heading  = trim((string) $this->params->get('page_heading')) ?: (string) $this->item->name;

// the `contact-page` modules: the intro block is data for this layout, the others are the aside
$intro  = null;
$aside  = [];
foreach (ModuleHelper::getModules('contact-page') as $mod) {
    if ($mod->module === 'mod_ja_acm' && str_contains((string) $mod->params, 'tracy_business:tb-sys-contact-intro')) {
        if ($intro === null) {
            require_once dirname(__DIR__, 3) . '/acm/data.php';
            $intro = new TracyAcmData(new class { public function get($n, $i = 0, $d = null) { return $d; } public function getRows($n) { return 0; } }, (string) $mod->params);
        }
        continue;
    }
    $aside[] = $mod;
}
$this->item->ngIntro = $intro;
$lede = $intro ? trim((string) $intro->get('lede')) : '';
?>
<div class="com-contact tb-contact-page<?php echo $esc($this->pageclass_sfx); ?>" itemscope itemtype="https://schema.org/Organization">

    <header class="tb-pageintro">
        <div class="tb-container tb-pageintro__inner">
            <div class="tb-pageintro__copy">
                <h1 class="tb-pageintro__title"><?php echo $esc($heading); ?></h1>
                <?php if ($lede !== '') : ?><div class="tb-pageintro__lede"><p><?php echo $esc($lede); ?></p></div><?php endif; ?>
            </div>
        </div>
    </header>

    <?php echo $this->item->event->afterDisplayTitle; ?>
    <?php echo $this->item->event->beforeDisplayContent; ?>

    <div class="tb-container tb-contact">
        <div class="tb-contact__card">
            <?php if ($showForm) : ?>
                <?php echo $this->loadTemplate('form'); ?>
            <?php endif; ?>
        </div>

        <?php if ($aside) : ?>
            <aside class="tb-contact__aside">
                <?php foreach ($aside as $mod) : ?>
                    <?php echo ModuleHelper::renderModule($mod, ['style' => 'none']); ?>
                <?php endforeach; ?>
            </aside>
        <?php endif; ?>
    </div>

    <?php echo $this->item->event->afterDisplayContent; ?>
</div>
