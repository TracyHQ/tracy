<?php

/**
 * Topbar user bar — mod_custom layout `userbar`.
 *
 * The account control lives in its own module in its own position (`topbar-user`, declared in
 * templateDetails.xml and given a row at the top of both layouts), so it no longer competes with
 * the hotline, the utility links, the language switcher and the theme toggle for one line — that
 * competition is what pushed the topbar onto a second row.
 *
 * A guest gets NOTHING: the layout returns before printing, the row is empty, and the empty row is
 * hidden by .tb-userbar:empty in css/tracy-business-userbar.css. The bar only exists while someone
 * is signed in.
 *
 * An output override (html/mod_custom/) rather than markup in the module's content field: the name,
 * the email and the CSRF token have to come from the session at render time, and a Custom module's
 * body is stored text. Labels are Joomla's own core strings (JLOGIN, JLOGOUT, COM_USERS_PROFILE), so
 * the control follows the site language without new keys to maintain.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$app  = Factory::getApplication();
$user = $app->getIdentity();

// No bar for a guest — the row collapses and the page starts at the topbar, exactly as before.
if (!$user || $user->guest) {
    return;
}

$name = trim((string) $user->name) !== '' ? (string) $user->name : (string) $user->username;

/* One or two initials, first letter of the first and last word. mb_* so RU names survive. */
$words   = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY) ?: [];
$initial = '';

if ($words) {
    $initial = mb_strtoupper(mb_substr($words[0], 0, 1, 'UTF-8'), 'UTF-8');

    if (count($words) > 1) {
        $initial .= mb_strtoupper(mb_substr(end($words), 0, 1, 'UTF-8'), 'UTF-8');
    }
}

/* Signing out lands back where the person was: Joomla takes a menu item id as the return value and
 * resolves it per language, which a hand-built URL does not. */
$active     = $app->getMenu()->getActive();
$logoutBack = $active ? (string) $active->id : '';
?>
<div class="tb-userbar">
    <div class="tb-container tb-userbar__inner">
        <h2 class="tb-userbar__title"><?php echo htmlspecialchars((string) $module->title, ENT_QUOTES, 'UTF-8'); ?></h2>
        <details class="tb-user">
            <summary class="tb-user__toggle">
                <span class="tb-user__avatar" aria-hidden="true"><?php echo htmlspecialchars($initial, ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="tb-user__name"><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="tb-user__caret" aria-hidden="true"></span>
                <span class="visually-hidden"><?php echo Text::_('TPL_TRACY_BUSINESS_USER_MENU_ARIA'); ?></span>
            </summary>
            <div class="tb-user__panel">
                <?php if (trim((string) $user->email) !== '') : ?>
                    <p class="tb-user__email"><?php echo htmlspecialchars((string) $user->email, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
                <ul class="tb-user__list">
                    <li>
                        <a class="tb-user__item" href="<?php echo Route::_('index.php?option=com_users&view=profile'); ?>">
                            <?php echo Text::_('TPL_TRACY_BUSINESS_USER_PROFILE'); ?>
                        </a>
                    </li>
                    <li>
                        <form class="tb-user__logout" action="<?php echo Route::_('index.php?option=com_users&task=user.logout'); ?>" method="post">
                            <button type="submit" class="tb-user__item tb-user__item--logout">
                                <?php echo Text::_('TPL_TRACY_BUSINESS_USER_LOGOUT'); ?>
                            </button>
                            <input type="hidden" name="return" value="<?php echo base64_encode($logoutBack); ?>">
                            <?php echo HTMLHelper::_('form.token'); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </details>
    </div>
</div>
