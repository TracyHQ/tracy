<?php
/**
 * Tracy Business — ACM `tb-kit-newsletter-top`: the top half of the 600 px digest email — ink masthead
 * (kicker + issue), the 16:9 lead photo and the lead story with its button. The page wraps this
 * and `tb-kit-newsletter-body` in the 600 px frame via {loadposition newsletter-top}{loadposition newsletter-body}.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$media = static function (string $v): string { $v = explode('#', trim($v))[0]; if ($v === '') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $v) ? $v : \Joomla\CMS\Uri\Uri::root(true) . '/' . $v; };
$kicker = trim((string) $helper->get('kicker')); $issue = trim((string) $helper->get('issue'));
$image = $media((string) $helper->get('image')); $alt = trim((string) $helper->get('image-alt'));
$title = trim((string) $helper->get('title')); $text = trim((string) $helper->get('text'));
$bt = trim((string) $helper->get('btn-text')); $bl = $route((string) $helper->get('btn-link'));
if ($kicker === '' && $title === '') return;
?>
<div class="ja-acm acm-tb-kit-newsletter-top tb-kitnl__top" id="tb-kitnl-top-<?php echo (int) $module->id; ?>">
  <?php if ($kicker !== '' || $issue !== '') : ?>
    <div class="tb-kitnl__mast">
      <?php if ($kicker !== '') : ?><p class="tb-kitnl__kicker"><?php echo $esc($kicker); ?></p><?php endif; ?>
      <?php if ($issue !== '') : ?><p class="tb-kitnl__issue"><?php echo $esc($issue); ?></p><?php endif; ?>
    </div>
  <?php endif; ?>
  <?php if ($image !== '') : ?><figure class="tb-kitnl__photo"><img src="<?php echo $esc($image); ?>" alt="<?php echo $esc($alt); ?>" width="600" height="190" loading="lazy" decoding="async"></figure><?php endif; ?>
  <?php if ($title !== '' || $text !== '') : ?>
    <div class="tb-kitnl__lead">
      <?php if ($title !== '') : ?><h2 class="tb-kitnl__title"><?php echo $esc($title); ?></h2><?php endif; ?>
      <?php if ($text !== '') : ?><p class="tb-kitnl__text"><?php echo $esc($text); ?></p><?php endif; ?>
      <?php if ($bt !== '' && $bl !== '') : ?><a class="tb-btn tb-btn--signal tb-kitnl__btn" href="<?php echo $esc($bl); ?>"><?php echo $esc($bt); ?></a>
      <?php elseif ($bt !== '') : ?><span class="tb-btn tb-btn--signal tb-kitnl__btn" role="presentation"><?php echo $esc($bt); ?></span><?php endif; ?>
    </div>
  <?php endif; ?>
</div>
