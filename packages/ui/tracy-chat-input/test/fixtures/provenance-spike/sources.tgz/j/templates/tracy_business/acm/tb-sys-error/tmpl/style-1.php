<?php
/**
 * Tracy Business — ACM `tb-sys-error`: the 404 block rendered by templates/tracy_business/error.php from the
 * `error-page` position. Two columns: the status code in Newsreader Signal, heading, text, a REAL
 * search form (GET to the Smart Search menu item of the current language) and a back link; on the
 * right a bordered box of suggested pages. A row without a link is plain text.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : Route::_($l, false); };
$app  = Factory::getApplication();
$menu = $app->getMenu();
$lang = $app->getLanguage()->getTag();
$code = (int) ($module->ngErrorCode ?? 404);

$title = trim((string) $helper->get('title')); $text = trim((string) $helper->get('text'));
$ph = trim((string) $helper->get('placeholder')); $btn = trim((string) $helper->get('button'));
$back = trim((string) $helper->get('back')); $backLink = $route((string) $helper->get('back-link'));
$sugTitle = trim((string) $helper->get('sug-title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, $route((string) $helper->get('row-link', $i))]; }

// the home of the current language (falls back to the site default) — never a hard-coded path
if ($backLink === '' && $back !== '') {
    $home = $menu->getDefault($lang) ?: $menu->getDefault();
    $backLink = $home ? Route::_('index.php?Itemid=' . (int) $home->id, false) : Uri::root(true) . '/';
}

// the Smart Search menu item: the first published com_finder search item, language-neutral or current
$searchItem = null;
foreach ($menu->getItems(['component', 'language'], ['com_finder', '*'], false) ?: [] as $it) { if (($it->query['view'] ?? '') === 'search') { $searchItem = $it; break; } }
if (!$searchItem) foreach ($menu->getItems(['component', 'language'], ['com_finder', $lang], false) ?: [] as $it) { if (($it->query['view'] ?? '') === 'search') { $searchItem = $it; break; } }
$searchAction = $searchItem ? Route::_('index.php?option=com_finder&view=search&Itemid=' . (int) $searchItem->id, false) : '';
$inputId = 'tb-404-q-' . (int) $module->id;
?>
<div class="ja-acm acm-tb-sys-error tb-404" id="tb-404-<?php echo (int) $module->id; ?>">
  <div class="tb-404__main">
    <p class="tb-404__code" aria-hidden="true"><?php echo $code; ?></p>
    <h1 class="tb-404__title"><?php echo $esc($title !== '' ? $title : (string) $code); ?></h1>
    <?php if ($text !== '') : ?><p class="tb-404__text"><?php echo $esc($text); ?></p><?php endif; ?>
    <?php if ($searchAction !== '') : ?>
      <form class="tb-404__search" action="<?php echo $esc($searchAction); ?>" method="get" role="search">
        <label for="<?php echo $inputId; ?>" class="visually-hidden"><?php echo $esc($btn !== '' ? $btn : 'Search'); ?></label>
        <input type="search" name="q" id="<?php echo $inputId; ?>" class="tb-404__input" placeholder="<?php echo $esc($ph); ?>" autocomplete="off">
        <button type="submit" class="tb-btn tb-btn--ink"><?php echo $esc($btn !== '' ? $btn : 'Search'); ?></button>
      </form>
    <?php endif; ?>
    <?php if ($back !== '' && $backLink !== '') : ?><p class="tb-404__back"><a class="tb-textlink" href="<?php echo $esc($backLink); ?>"><?php echo $esc($back); ?></a></p><?php endif; ?>
  </div>
  <?php if ($rows) : ?>
    <aside class="tb-404__aside">
      <?php if ($sugTitle !== '') : ?><p class="tb-404__aside-title"><?php echo $esc($sugTitle); ?></p><?php endif; ?>
      <ul class="tb-404__list">
        <?php foreach ($rows as [$t, $l]) : ?>
          <li><?php if ($l !== '') : ?><a class="tb-404__row" href="<?php echo $esc($l); ?>"><span><?php echo $esc($t); ?></span><span class="tb-404__arrow" aria-hidden="true">→</span></a><?php else : ?><span class="tb-404__row"><span><?php echo $esc($t); ?></span></span><?php endif; ?></li>
        <?php endforeach; ?>
      </ul>
    </aside>
  <?php endif; ?>
</div>
