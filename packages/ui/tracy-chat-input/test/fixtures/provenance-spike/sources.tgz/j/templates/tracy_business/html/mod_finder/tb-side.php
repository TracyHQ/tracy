<?php

/**
 * Tracy Business — mod_finder, layout `tb-side`: the "Search" box in the News sidebar.
 * A real Smart Search form (com_finder); box label = module title, placeholder from the module
 * param `ng_placeholder` (set per language by tools/j/build-news.php).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$app->getLanguage()->load('com_finder', JPATH_SITE);
$finderHelper = $app->bootModule('mod_finder', 'site')->getHelper('FinderHelper');
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$q   = $esc($app->getInput()->get('q', '', 'string'));
$id  = 'mod-finder-searchword' . (int) $module->id;
$lbl = trim((string) $module->title) !== '' ? $module->title : Text::_('JSEARCH_FILTER_SUBMIT');
?>
<search class="tb-sidebox tb-sidebox--paper tb-sidesearch-box">
    <?php if ($module->showtitle && trim((string) $module->title) !== '') : ?>
        <p class="tb-sidebox__label"><?php echo $esc($module->title); ?></p>
    <?php endif; ?>
    <form class="mod-finder js-finder-searchform tb-sidesearch" action="<?php echo Route::_($route); ?>" method="get" role="search">
        <label for="<?php echo $id; ?>" class="visually-hidden"><?php echo $esc($lbl); ?></label>
        <input type="search" name="q" id="<?php echo $id; ?>" value="<?php echo $q; ?>" placeholder="<?php echo $esc($params->get('ng_placeholder', '')); ?>" autocomplete="off">
        <button type="submit" aria-label="<?php echo $esc($lbl); ?>">⌕</button>
        <?php echo $finderHelper->getHiddenFields($route); ?>
    </form>
</search>
