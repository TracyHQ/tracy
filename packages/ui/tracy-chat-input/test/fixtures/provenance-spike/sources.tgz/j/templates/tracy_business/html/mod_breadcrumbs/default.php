<?php

/**
 * Tracy Business — breadcrumbs.
 *
 * The design's trail: a Paper-2 band under the header, `Home / Section / Page`, 13.5px, links in
 * forest, "/" separators in a light grey, the current page in ink at weight 500. No "You are here"
 * label and no home icon — the first crumb is the word "Home" (the home menu item's title), which
 * is what the design shows. Structured data (BreadcrumbList JSON-LD) is kept exactly as core
 * emits it, so search engines see the same trail the visitor does.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\WebAsset\WebAssetManager;

// Drop the duplicated home crumb multilanguage sites produce (core does the same).
for ($i = 0; $i < $count; $i++) {
    if ($i === 1 && !empty($list[$i]->link) && !empty($list[$i - 1]->link) && $list[$i]->link === $list[$i - 1]->link) {
        unset($list[$i]);
    }
}

end($list);
$lastKey  = key($list);
$showLast = $params->get('showLast', 1);

// The current page's crumb is the page's own name, not the navigation label. When the active
// menu item carries a Browser Page Title (Menus → item → Page Display), that title names the
// page ("About us" while the nav says "About"), so it replaces the last crumb — visible and in
// the JSON-LD alike. Article pages already end with the article title and are left alone.
$active = $app->getMenu()->getActive();
if ($active && $showLast && isset($list[$lastKey]) && $list[$lastKey]->name === $active->title) {
    $pageTitle = trim((string) $active->getParams()->get('page_title', ''));
    if ($pageTitle !== '') {
        $list[$lastKey]->name = htmlspecialchars($pageTitle, ENT_COMPAT, 'UTF-8');
    }
}
$esc      = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<nav class="tb-crumbs" aria-label="<?php echo $esc($module->title); ?>">
    <ol class="tb-crumbs__list" itemscope itemtype="https://schema.org/BreadcrumbList">
        <?php $pos = 0; ?>
        <?php foreach ($list as $key => $item) : ?>
            <?php if ($key !== $lastKey) : ?>
                <?php $pos++; ?>
                <li class="tb-crumbs__item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <?php if (!empty($item->link)) : ?>
                        <a class="tb-crumbs__link" href="<?php echo Route::_($item->link); ?>" itemprop="item"><span itemprop="name"><?php echo $item->name; ?></span></a>
                    <?php else : ?>
                        <span itemprop="name"><?php echo $item->name; ?></span>
                    <?php endif; ?>
                    <meta itemprop="position" content="<?php echo $pos; ?>">
                </li>
                <li class="tb-crumbs__sep" aria-hidden="true">/</li>
            <?php elseif ($showLast) : ?>
                <?php $pos++; ?>
                <li class="tb-crumbs__item tb-crumbs__item--current" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" aria-current="page">
                    <span itemprop="name"><?php echo $item->name; ?></span>
                    <meta itemprop="position" content="<?php echo $pos; ?>">
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ol>
    <?php
    // JSON-LD, verbatim from core.
    $data = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', '@id' => Uri::root() . '#/schema/BreadcrumbList/' . (int) $module->id, 'itemListElement' => []];
    $itemsCounter = 0;

    if (isset($homeCrumb)) {
        $data['itemListElement'][] = ['@type' => 'ListItem', 'position' => ++$itemsCounter, 'item' => ['@id' => Route::_($homeCrumb->link, true, Route::TLS_IGNORE, true), 'name' => $homeCrumb->name]];
    }

    foreach ($list as $key => $item) {
        if (!empty($item->link)) {
            $data['itemListElement'][] = ['@type' => 'ListItem', 'position' => ++$itemsCounter, 'item' => ['@id' => Route::_($item->link, true, Route::TLS_IGNORE, true), 'name' => $item->name]];
        } elseif ($key === $lastKey) {
            $data['itemListElement'][] = ['@type' => 'ListItem', 'position' => ++$itemsCounter, 'item' => ['name' => $item->name]];
        }
    }

    if ($itemsCounter) {
        /** @var WebAssetManager $wa */
        $wa = $app->getDocument()->getWebAssetManager();
        $wa->addInline('script', json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | (JDEBUG ? JSON_PRETTY_PRINT : 0)), ['name' => 'inline.breadcrumbs-schemaorg'], ['type' => 'application/ld+json']);
    }
    ?>
</nav>
