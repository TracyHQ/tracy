<?php

/**
 * Tracy Business — mod_finder layout "tb-page": the FILTER BY SECTION box of the search page.
 *
 * One row per top-level branch of Smart Search's own "Category" taxonomy in the current language
 * (Projects, News, Pages, Contacts …), each with the number of hits the CURRENT query has in that
 * branch and its sub-branches, plus an "All" row. Every row is a real link: it re-runs the query
 * with com_finder's `t[]` taxonomy filter (the branch node and all its descendants, which the
 * component ORs within one branch). The counts come from the component's own SearchModel, one
 * count per branch. Without a query the module renders nothing — there is nothing to count.
 *
 * Publish it in `search-page` on the Smart Search menu item; the module title is the box eyebrow.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;

$app   = Factory::getApplication();
$input = $app->getInput();
$q     = trim($input->getString('q', ''));

if ($q === '' || $input->getCmd('option') !== 'com_finder') {
    return;
}

$db   = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
$lang = $app->getLanguage()->getTag();
$esc  = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

// top-level nodes of the "Category" branch, in this language or language-neutral
$query = $db->createQuery()
    ->select('c.id, c.title, c.lft, c.rgt')
    ->from($db->quoteName('#__finder_taxonomy', 'c'))
    ->join('INNER', $db->quoteName('#__finder_taxonomy', 'b') . ' ON b.level = 1 AND b.title = ' . $db->quote('Category') . ' AND c.lft > b.lft AND c.rgt < b.rgt')
    ->where('c.level = 2')->where('c.state = 1')
    ->whereIn('c.language', [$lang, '*'], \Joomla\Database\ParameterType::STRING)
    ->order('c.lft');
$sections = $db->setQuery($query)->loadObjectList();

if (!$sections) {
    return;
}

// descendants of each section (the component filters on exact node ids, so the branch is passed whole)
$ids = [];
foreach ($sections as $s) {
    $ids[$s->id] = ArrayHelper::toInteger($db->setQuery('SELECT id FROM ' . $db->quoteName('#__finder_taxonomy') . ' WHERE lft >= ' . (int) $s->lft . ' AND rgt <= ' . (int) $s->rgt)->loadColumn());
}

// counts: the component's model, once per branch, by swapping the `t` filter on the request
$factory = $app->bootComponent('com_finder')->getMVCFactory();
$count = static function (array $t) use ($factory, $input): int {
    $keep = $input->exists('t') ? $input->get('t', [], 'array') : null;   // null = the key was absent; restore it absent
    $input->set('t', $t);
    try {
        $model = $factory->createModel('Search', 'Site');
        $model->getState();
        return (int) $model->getTotal();
    } finally {
        $input->set('t', $keep);
    }
};
$current = ArrayHelper::toInteger($input->get('t', [], 'array'));
$totalAll = $count([]);

$link = static function (array $t) use ($route, $q): string {
    $uri = new Uri($route);   // never Uri::getInstance(): that cache hands the same mutable object to every caller of this route
    $uri->setVar('q', $q);
    if ($t) { $uri->setVar('t', $t); } else { $uri->delVar('t'); }
    return Route::_($uri->toString(['path', 'query']), false);
};
$rows = [[Text::_('TPL_TRACY_BUSINESS_ACM_FILTER_ALL'), $totalAll, $link([]), !$current]];
foreach ($sections as $s) {
    $n = $count($ids[$s->id]);
    if ($n === 0) continue;
    $rows[] = [$s->title, $n, $link($ids[$s->id]), $current && \in_array((int) $s->id, $current, true)];
}
?>
<div class="mod-finder tb-sysbox tb-filterbox">
    <?php if ($module->showtitle) : ?><p class="tb-sysbox__eyebrow"><?php echo $esc($module->title); ?></p><?php endif; ?>
    <ul class="tb-filterbox__list">
        <?php foreach ($rows as [$label, $n, $href, $active]) : ?>
            <li><a class="tb-filterbox__item<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo $esc($href); ?>"<?php echo $active ? ' aria-current="true"' : ''; ?>><span class="tb-filterbox__box" aria-hidden="true"></span><?php echo $esc($label); ?> (<?php echo $n; ?>)</a></li>
        <?php endforeach; ?>
    </ul>
</div>
