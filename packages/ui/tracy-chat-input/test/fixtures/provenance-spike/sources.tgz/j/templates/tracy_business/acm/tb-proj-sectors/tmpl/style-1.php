<?php
/**
 * Tracy Business — ACM `tb-proj-sectors`: the "Sectors" column on the Projects page — a title and rows with the
 * sector name (left), its project count in forest (right) and one descriptive line under. Renders as a column
 * so it can share the paper-2 band with `tb-process` (the two modules sit side by side in `bottom-a`).
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) {
    $t = trim((string) $helper->get('row-title', $i));
    if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-count', $i)), trim((string) $helper->get('row-desc', $i)), $route((string) $helper->get('row-link', $i))];
}
if (!$rows) return;
$id = 'tb-proj-sectors-' . (int) $module->id;
?>
<div class="ja-acm acm-tb-proj-sectors tb-proj-sectors" id="<?php echo $id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-section__title tb-proj-sectors__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <ul class="tb-proj-sectors__list">
    <?php foreach ($rows as [$t, $n, $d, $l]) : ?>
      <li class="tb-proj-sectors__row">
        <div class="tb-proj-sectors__head">
          <?php if ($l !== '') : ?><a class="tb-proj-sectors__name" href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><strong class="tb-proj-sectors__name"><?php echo $esc($t); ?></strong><?php endif; ?>
          <?php if ($n !== '') : ?><span class="tb-proj-sectors__count"><?php echo $esc($n); ?></span><?php endif; ?>
        </div>
        <?php if ($d !== '') : ?><p class="tb-proj-sectors__desc"><?php echo $esc($d); ?></p><?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
</div>
