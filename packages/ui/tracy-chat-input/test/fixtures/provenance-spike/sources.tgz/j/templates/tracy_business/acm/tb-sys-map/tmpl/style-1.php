<?php
/** Tracy Business — ACM `tb-sys-map`: a bordered 560×260 map frame. An embed URL renders an iframe; otherwise the image. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$image = explode('#', trim((string) $helper->get('image')))[0];
if ($image !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $image)) $image = \Joomla\CMS\Uri\Uri::root(true) . '/' . $image;
$alt = trim((string) $helper->get('image-alt')); $embed = trim((string) $helper->get('embed'));
if ($image === '' && $embed === '') return;
?>
<div class="ja-acm acm-tb-sys-map tb-map">
  <?php if ($embed !== '') : ?>
    <iframe class="tb-map__frame" src="<?php echo $esc($embed); ?>" title="<?php echo $esc($alt); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  <?php else : ?>
    <img class="tb-map__img" src="<?php echo $esc($image); ?>" alt="<?php echo $esc($alt); ?>" loading="lazy" decoding="async">
  <?php endif; ?>
</div>
