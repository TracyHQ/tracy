<?php
/**
 * Tracy Business — ACM `tb-projects`, layout `mega`: the 2×2 photo tiles inside the Resources megamenu.
 * Hover reveals a caption (title + category · year) over a bottom gradient.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__) . '/_load.php'; // not _once: the closures must exist in EVERY layout's scope
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$items = $ngLoadProjects((int) $helper->get('source-category'), max(1, (int) ($helper->get('count') ?: 4)));
if (!$items) return;
?>
<ul class="tb-mega-tiles">
  <?php foreach ($items as $p) : ?>
    <li><a href="<?php echo $esc($p['url']); ?>">
      <?php if ($p['image'] !== '') : ?><img src="<?php echo $esc($p['image']); ?>" alt="" width="400" height="250" loading="eager" decoding="async"><?php endif; ?>
      <span class="tb-mega-tiles__cap"><?php echo $esc($p['title']); ?><small><?php echo $esc($p['category']); ?> · <?php echo $esc($p['year']); ?></small></span>
    </a></li>
  <?php endforeach; ?>
</ul>
