/**
 * Tracy Business — article page: copy-link share button and the "In this article" active state.
 * Loaded by html/com_content/article/tb-article.php through the web asset manager
 * (only on articles that use that layout).
 */
(function () {
  'use strict';

  // ⧉ copy link — the button holds the canonical URL in data-url
  document.querySelectorAll('.js-tb-copy').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var url = btn.getAttribute('data-url') || window.location.href;
      var done = function () {
        btn.classList.add('is-done');
        window.setTimeout(function () { btn.classList.remove('is-done'); }, 1500);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(done, function () {});
      } else {
        var ta = document.createElement('textarea');
        ta.value = url;
        ta.setAttribute('readonly', '');
        ta.style.position = 'absolute';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); done(); } catch (e) { /* no clipboard: nothing to report */ }
        document.body.removeChild(ta);
      }
    });
  });

  // TOC: the heading nearest the top of the viewport owns the Signal bar
  var links = Array.prototype.slice.call(document.querySelectorAll('.tb-article__toc-link'));
  if (!links.length) return;
  var targets = links.map(function (a) {
    var id = (a.getAttribute('href') || '').replace(/^#/, '');
    return id ? document.getElementById(id) : null;
  });
  if (targets.some(function (t) { return !t; })) return;

  var setActive = function (i) {
    links.forEach(function (a, k) { a.classList.toggle('is-active', k === i); });
  };
  var update = function () {
    var line = 140; // below the sticky header, matches scroll-margin-top on the headings
    var current = 0;
    for (var i = 0; i < targets.length; i++) {
      if (targets[i].getBoundingClientRect().top <= line) current = i;
    }
    setActive(current);
  };
  var ticking = false;
  window.addEventListener('scroll', function () {
    if (ticking) return;
    ticking = true;
    window.requestAnimationFrame(function () { update(); ticking = false; });
  }, { passive: true });
  update();
})();
