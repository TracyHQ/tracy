<?php
/**
 * Tracy Business — ACM `tb-kit-signup`: the Forest "subscribe" box (Newsletter sidebar) and the Ink
 * "call me back" box (Form sidebar) — same shape, one tone switch. It is a presentation sample:
 * no <form>, the field is disabled and the button is type="button", so nothing can be submitted.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$tone = (string) $helper->get('tone') === 'ink' ? 'ink' : 'forest';
$title = trim((string) $helper->get('title')); $text = trim((string) $helper->get('text'));
$ph = trim((string) $helper->get('placeholder')); $bt = trim((string) $helper->get('btn-text')); $note = trim((string) $helper->get('note'));
if ($title === '') return;
$id = 'tb-kitsignup-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-signup tb-kitside tb-kitsignup tb-kitsignup--<?php echo $tone; ?>" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <h2 class="tb-kitsignup__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
  <?php if ($text !== '') : ?><p class="tb-kitsignup__text"><?php echo $esc($text); ?></p><?php endif; ?>
  <?php if ($ph !== '') : ?><input class="tb-kitsignup__field" type="text" placeholder="<?php echo $esc($ph); ?>" aria-label="<?php echo $esc($ph); ?>" disabled><?php endif; ?>
  <?php if ($bt !== '') : ?><button class="tb-btn tb-btn--signal tb-kitsignup__btn" type="button" disabled><?php echo $esc($bt); ?></button><?php endif; ?>
  <?php if ($note !== '') : ?><p class="tb-kitsignup__note"><?php echo $esc($note); ?></p><?php endif; ?>
</section>
