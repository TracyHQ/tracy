<?php
/** Tracy Business — ACM `tb-process`: "How the work runs" — a title and numbered steps (01, 02 …) in signal Newsreader numerals. Renders as a column so two of them can sit side by side in a 2-column row. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$title = trim((string) $helper->get('title')); $intro = trim((string) $helper->get('intro'));
$steps = [];
for ($i = 0, $n = (int) $helper->getRows('step-title'); $i < $n; $i++) { $t = trim((string) $helper->get('step-title', $i)); if ($t !== '') $steps[] = [$t, trim((string) $helper->get('step-desc', $i))]; }
if (!$steps) return;
$id = 'tb-process-' . (int) $module->id;
?>
<div class="ja-acm acm-tb-process tb-process" id="<?php echo $id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-section__title tb-process__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <?php if ($intro !== '') : ?><p class="tb-process__intro"><?php echo $esc($intro); ?></p><?php endif; ?>
  <ol class="tb-process__list">
    <?php foreach ($steps as $i => [$t, $d]) : ?>
      <li class="tb-process__step"><span class="tb-process__num" aria-hidden="true"><?php echo str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT); ?></span><div><strong class="tb-process__step-title"><?php echo $esc($t); ?></strong><?php if ($d !== '') : ?><p class="tb-process__step-desc"><?php echo $esc($d); ?></p><?php endif; ?></div></li>
    <?php endforeach; ?>
  </ol>
</div>
