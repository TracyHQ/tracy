<?php
/** Tracy Business — ACM `tb-cta-band`: the forest band with a Newsreader question, one line, one signal button. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$link = trim((string) $helper->get('btn-link'));
if ($link !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $link)) $link = \Joomla\CMS\Router\Route::_($link);
$text = trim((string) $helper->get('btn-text'));
$id = 'tb-cta-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-cta-band tb-ctaband" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-ctaband__inner">
    <div>
      <h2 class="tb-ctaband__title" id="<?php echo $id; ?>-title"><?php echo $esc((string) $helper->get('title')); ?></h2>
      <?php if (trim((string) $helper->get('desc')) !== '') : ?><p class="tb-ctaband__desc"><?php echo $esc((string) $helper->get('desc')); ?></p><?php endif; ?>
    </div>
    <?php if ($text !== '' && $link !== '') : ?><a class="tb-btn tb-btn--signal" href="<?php echo $esc($link); ?>"><?php echo $esc($text); ?></a><?php endif; ?>
  </div>
</section>
