jQuery(document).ready(function() {
    jQuery(document).on("scroll", onScroll);
    onepageNavLinks = jQuery('.onepage .t4-navbar .nav-link');

    function onScroll(event){
        var scrollPos = jQuery(document).scrollTop();
        onepageNavLinks.each(function () {
            var currLink = jQuery(this);
            var refElement = jQuery(currLink.attr("href"));
            if (refElement.position().top <= scrollPos /* && refElement.position().top + refElement.height() > scrollPos*/ ) {
                onepageNavLinks.removeClass("active");
                currLink.addClass("active");
            }
            else{
                currLink.removeClass("active");
            }
        });
    }
})

// Keep T4's editable menu markup; provide one input model for mouse, touch and keyboard.
window.addEventListener('load', function () {
  var header = document.querySelector('#t4-header');
  if (!header) return;
  var items = Array.from(header.querySelectorAll('.navbar-nav > li.dropdown'));
  var active = null, hovered = false, closeTimer, focusFrame;
  function trigger(item) { return item.querySelector(':scope > .dropdown-toggle'); }
  function panel(item) { return item.querySelector(':scope > .dropdown-menu'); }
  function close() {
    clearTimeout(closeTimer);
    cancelAnimationFrame(focusFrame);
    items.forEach(function (item) {
      item.classList.remove('show', 'animating');
      if (panel(item)) { panel(item).classList.remove('show'); panel(item).inert = true; }
      if (trigger(item)) trigger(item).setAttribute('aria-expanded', 'false');
    });
    document.body.classList.remove('tracy-menu-open');
    active = null;
  }
  function open(item, fromPointer) {
    if (!window.matchMedia('(min-width: 992px)').matches) return;
    clearTimeout(closeTimer);
    if (active === item) { hovered = Boolean(fromPointer); return; }
    close(); active = item; hovered = Boolean(fromPointer);
    panel(item).inert = false;
    item.classList.add('show', 'animating'); panel(item).classList.add('show');
    trigger(item).setAttribute('aria-expanded', 'true');
    document.body.classList.toggle('tracy-menu-open', item.classList.contains('mega') && !item.classList.contains('tracy-menu-compact'));
  }
  items.forEach(function (item, index) {
    var button = trigger(item), menu = panel(item);
    if (!button || !menu) return;
    if (!menu.querySelector('.tracy-menu-feature, .tracy-menu-team') && menu.querySelectorAll('a[href]').length <= 4) item.classList.add('tracy-menu-compact');
    // Remove only T4's handlers for these top-level disclosures, not its nested menus.
    jQuery(item).off('mouseenter mouseleave');
    jQuery(button).off('touchstart');
    menu.id = menu.id || 'tracy-menu-' + index;
    button.setAttribute('aria-controls', menu.id);
    button.setAttribute('aria-expanded', 'false');
    menu.inert = true;
    item.addEventListener('pointerenter', function (event) {
      if (event.pointerType !== 'touch') open(item, true);
    });
    item.addEventListener('pointerleave', function () {
      if (!hovered || item.contains(document.activeElement)) return;
      clearTimeout(closeTimer); closeTimer = setTimeout(close, 140);
    });
    menu.addEventListener('pointerenter', function () { clearTimeout(closeTimer); });
    button.addEventListener('click', function (event) {
      if (!item.classList.contains('mega') || button.getAttribute('href') && !/^(javascript:|#)/.test(button.getAttribute('href'))) return;
      event.preventDefault(); active === item && !hovered ? close() : open(item);
    });
    button.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' && (!item.classList.contains('mega') || button.getAttribute('href') && !/^(javascript:|#)/.test(button.getAttribute('href')))) return;
      if (event.key === ' ' || event.key === 'ArrowDown' || event.key === 'Enter') {
        event.preventDefault(); open(item);
        if (event.key === 'ArrowDown') {
          focusFrame = requestAnimationFrame(function () {
            if (active !== item) return;
            var first = menu.querySelector('a[href]'); if (first) first.focus();
          });
        }
      }
    });
  });
  document.body.classList.add('tracy-menu-ready');
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && active) {
      var button = trigger(active); close(); button.focus(); event.preventDefault();
    }
  });
  document.addEventListener('pointerdown', function (event) { if (!header.contains(event.target)) close(); });
  header.addEventListener('focusout', function () {
    setTimeout(function () { if (active && !active.contains(document.activeElement)) close(); }, 0);
  });
  window.matchMedia('(min-width: 992px)').addEventListener('change', function () {
    close();
    var drawerClose = document.querySelector('.t4-offcanvas.is-open .js-offcanvas-close');
    if (drawerClose) drawerClose.click();
  });

  var drawer = document.querySelector('.t4-offcanvas');
  if (!drawer) return;
  drawer.querySelectorAll('.sub-menu-back,.sub-menu-toggle').forEach(function (control) {
    control.setAttribute('role', 'button'); control.tabIndex = 0;
    if (control.classList.contains('sub-menu-toggle')) {
      var label = control.parentElement.querySelector('.dropdown-toggle');
      control.setAttribute('aria-label', label ? 'Open ' + label.textContent.trim() + ' submenu' : 'Open submenu');
    }
  });
  var drawerFocusTimer;
  drawer.addEventListener('click', function (event) {
    clearTimeout(drawerFocusTimer);
    var back = event.target.closest('.sub-menu-back');
    var opener = event.target.closest('.sub-menu-toggle,.separator.dropdown-toggle,.nav-header.dropdown-toggle');
    var item = back ? back.closest('li.nav-item') : opener && opener.parentElement;
    if (!item) return;
    var label = item.querySelector(':scope > .dropdown-toggle');
    if (label) label.setAttribute('aria-expanded', back ? 'false' : 'true');
    if (event.detail === 0) {
      var destination = back ? label : item.querySelector('.sub-menu-back');
      var origin = document.activeElement;
      var delay = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 20 : 320;
      drawerFocusTimer = setTimeout(function () {
        if (destination && drawer.classList.contains('is-open') && (document.activeElement === origin || document.activeElement === document.body)) destination.focus();
      }, delay);
    }
  });
  drawer.addEventListener('keydown', function (event) {
    if (!drawer.classList.contains('is-open')) return;
    if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.sub-menu-back,.sub-menu-toggle')) {
      event.preventDefault(); event.target.click(); return;
    }
    // T4's visibility test includes translated parent links. Tab only through the active level.
    if (event.key === 'Tab') {
      var bounds = drawer.getBoundingClientRect();
      var focusable = Array.from(drawer.querySelectorAll('a[href],button,[tabindex="0"],input,select,textarea')).filter(function (el) {
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility === 'visible' && r.left >= bounds.left - 1 && r.right <= bounds.right + 1 && !el.disabled;
      });
      if (!focusable.length) return;
      event.preventDefault(); event.stopImmediatePropagation();
      var index = focusable.indexOf(document.activeElement);
      focusable[(index + (event.shiftKey ? -1 : 1) + focusable.length) % focusable.length].focus();
    }
  }, true);
});
