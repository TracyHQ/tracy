<?php

/**
 * Tracy Business — plg_content_pagenavigation, template override (used by the news article layout).
 *
 * Two boxes side by side: "← Previous" / "Next →" label + the neighbouring article's title.
 * Labels come from the menu item params `ng_prev_label` / `ng_next_label` (set per language by
 * tools/j/build-news.php); the core JPREV / JNEXT strings are the fallback.
 * The plugin computes $row->prev / $row->next (routes) and $rows[$location ± 1] (titles).
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$esc       = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$prevLabel = trim((string) $params->get('ng_prev_label', '')) ?: Text::_('JPREV');
$nextLabel = trim((string) $params->get('ng_next_label', '')) ?: Text::_('JNEXT');
$single    = !($row->prev && $row->next);
?>
<nav class="tb-pagenav<?php echo $single ? ' tb-pagenav--single' : ''; ?>" aria-label="<?php echo $esc(Text::_('PLG_PAGENAVIGATION_ARIA_LABEL')); ?>">
    <?php if ($row->prev) : ?>
        <a class="tb-pagenav__link tb-pagenav__link--prev" href="<?php echo $esc(Route::_($row->prev)); ?>" rel="prev">
            <p class="tb-pagenav__label"><?php echo $esc($prevLabel); ?></p>
            <p class="tb-pagenav__title"><?php echo $esc($rows[$location - 1]->title); ?></p>
        </a>
    <?php endif; ?>
    <?php if ($row->next) : ?>
        <a class="tb-pagenav__link tb-pagenav__link--next" href="<?php echo $esc(Route::_($row->next)); ?>" rel="next">
            <p class="tb-pagenav__label"><?php echo $esc($nextLabel); ?></p>
            <p class="tb-pagenav__title"><?php echo $esc($rows[$location + 1]->title); ?></p>
        </a>
    <?php endif; ?>
</nav>
