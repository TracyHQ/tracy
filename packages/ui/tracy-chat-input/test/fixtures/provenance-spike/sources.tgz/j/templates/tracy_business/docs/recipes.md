# Recipes — how a change is made on this site

Every recipe has a **Door** path (the Claude Cowork API — `cowork-api.md`, the way an agent
works) and an **Admin** path (the same thing by hand). Both end with the same checks
(`checks.md`). Ids for existing items: `site-map.md`. There is no SQL path.

## 1. Add a static page (like About, Services, Careers)

A static page = **one article per language** + **menu items** (associated) + **ACM modules** in a
position named `<page>-page`, loaded by `{loadposition}` in the article.

Admin:
0. **First declare the positions** in `templateDetails.xml` — `<position><slug>-page</position>`
   (and `-split`, `-end` if used) — otherwise the Module Manager cannot offer them and you will
   type them by hand into a field that does not autocomplete. Clear cache once after saving.
1. Content → Articles → New, language `en-GB`, category *Pages* (see `site-map.md` for its id).
   *Title* = the H1. *Intro text* = the lede (`<p>…</p>`). *Full text* = `{loadposition <slug>-page}`.
   Repeat for `ru-RU`; then open one of them → **Associations** tab → pick the other.
2. Menus → *Northgate — Main menu (en)* → New → Articles › Single Article → choose the EN article,
   alias = URL slug, template style **Northgate — Inner** (default). Set *Page Display → Browser Page
   Title* if the breadcrumb label must differ from the menu title. Repeat in the RU menu, associate.
   A page that must not appear in the nav still needs a menu item (it gives the URL, the style, the
   breadcrumb and the association): put it in the hidden menu `tb-kit-<lang>` — do not use
   *Display in menu: No* on the main menu, it leaves a hole in the nav order.
3. Content → Site Modules → New → **JA ACM** → block from `blocks.md` (e.g. `tb-stats-strip`),
   position `<slug>-page` (type the new name — positions are free text), language, *Menu Assignment:
   only on the page's menu item*, title `[Tracy Business] <Page> - <Section> (en)`. One module per
   section, top to bottom; the position's **Ordering** is the vertical order. Repeat for RU.
4. Two-column rows: put the two blocks in `<slug>-page-split`; blocks after a full-width break in
   `<slug>-page-end`; the article's full text then reads
   `{loadposition <slug>-page}{loadposition <slug>-page-split}{loadposition <slug>-page-end}`.
5. Clear cache. Run the audit (`checks.md`) — the new page is crawled once its menu item is
   published, and the audit's `langSwitchBroken` catches a missing association.

Door: exactly the worked example in `cowork-api.md` §5 — `article` ×2 → `articleAssociation` →
`menuItem` ×2 (parent = the About items, `template_style_id` 120) → `menuAssociation` → `module`
per section (copy `params` from a sibling of the same block via `content.get`) → `moduleAssignment`
with the page's menu id; all under one `apply_id`. Position declaration in `templateDetails.xml`
stays a file edit.

## 2. Add a project (Projects grid + detail page)

Admin: Content → Articles → New in category **Projects** (EN) / **Проекты** (RU). *Images and
Links → Intro image* = the 16:9 card image (`images/northgate/…`); *Options → Layout* =
`tb-project`; fill the custom **Fields** tab (client, location, area, year, sector, status —
the detail page prints exactly these); *Tags* = the sector chip; associate EN↔RU. The Projects grid,
the megamenu tile and the Home "selected projects" block read from the category — nothing else to
wire. If a fact (area, year…) is unknown, leave the field empty: the row is omitted, not faked.

Door: `content.update` kind `article`, `catid` = Projects (EN 254… see `site-map.md`),
`attribs` = `"{\"article_layout\":\"tracy_business:tb-project\"}"`, `images` JSON with
`image_intro`, `tags` = [sector tag id]; then `articleAssociation`. Custom field values have no
door action yet — fill the **Fields** tab in Admin after the article exists.

## 3. Add a news article

Admin: Content → Articles → New in **News** (EN) / **Новости** (RU); intro image 16:9, *Layout* =
`tb-article`, *Read more* split (intro = teaser), tags, real publish date, author; associate.
The article layout builds the table of contents from the H2s in the full text and the copy/share
buttons from the page URL — write real H2s. Related articles come from the same category.
Door: as §2 with `catid` = News, `attribs` `article_layout` = `tracy_business:tb-article`,
`publish_up` the real date, `created_by_alias` for the author name.

## 4. Change the topbar, header CTA, footer, copyright

Door: `content.get` the module (ids in `inventory.md`), edit `content` (mod_custom) or `params`
(ACM), `content.update` under an `apply_id`. All are modules, per language (`inventory.md` → positions `topbar-l`, `topbar-r`, `header-cta`,
`footer-a…d`, `copyright`). Hotline/e-mail/address = `mod_custom` in `topbar-l` and the
`tb-footer-contact` block in `footer-d`. Footer link columns = `mod_menu` on the `tb-footer-*`
menus. Site name / tagline / monogram = T4 style → *Site* tab (`etc/site/tracy-business.json`).

## 5. Add or rename a top-level nav item / megamenu entry

1. Menus → *Main menu (en)* and *(ru)*: add the item (associate). Order = nav order. Door:
   `menuItem` create with `menutype` `tb-main-en`/`-ru`, `parent_id` 1 for top level, then
   `menuAssociation`; reorder with `move_after` = the sibling to follow.
2. Megamenu structure is **not** in the menu: T4 style → *Navigation* → megamenu builder, or edit
   `etc/navigation/tracy-business.json` → `mega_settings` → `<menutype>` → `<item id>` (columns, widths,
   `mega-2`/`mega-3` module tiles, captions). Item **ids differ per language** — edit both; the ids
   are the `#` column of `site-map.md` (e.g. EN *Resources* #605 ↔ RU *Ресурсы* #638).
3. Only items with `megabuild` open a panel; a panel only shows **descendants** of its item.
4. Clear cache; run `mega-hover.mjs` (checks.md) — the panel must be reachable by a mouse, in both
   languages, at 1440 and 1024.

## 6. Change a design value (colour, size, spacing)

Change the **token** in `css/styles/tracy-business.css` (light block, and the dark remap if the role
flips). Do not patch a component with a literal. If the design system has no token for what you
need, the design does not have that value — ask, do not add.

## 7. Create a new ACM block

Copy the closest existing block, e.g. `acm/tb-stats-strip/` → `acm/tb-<name>/`:
`config.xml` (title), `tmpl/style-1.xml` (fields — plain English labels, `multiple="1"` fieldset for
rows), `tmpl/style-1.php` (markup from the shared classes in `design-system.md` §5; data via
`require_once dirname(__DIR__, 2) . '/data.php'`, `$helper->get('field', $i)`,
`$helper->getRows('rows')`), `index.html`. Styles go in the area's `scss/_tracy-business-<area>.scss`
with a `.tb-<name>` BEM prefix, tokens only. Add a line to `blocks.md` by regenerating. Admin picks
it up immediately as `tracy_business:tb-<name>`.

## 8. Add a language string

Template strings are `TPL_TRACY_BUSINESS_*` in `language/en-GB/en-GB.tpl_tracy_business.ini` and
`language/ru-RU/ru-RU.tpl_tracy_business.ini` **inside the template, and the copies under
`/language/<tag>/`**. The front end reads the template copy; the ACM admin form reads the
site-level copy (the addon loads from `JPATH_SITE`). Edit only one and the other side shows the raw
`TPL_…` key — so always edit both, same key, same line. Joomla core strings the site overrides (e.g. the consent checkbox text) are in
`/language/overrides/<tag>.override.ini` — Admin → System → Language Overrides.

## 9. Add or remove a site language

One command each — `languages.md`. `php templates/tracy_business/tools/add-language.php <tag>`
installs the pack if needed (12 are pre-installed, 60 are in `language-packs.json`), publishes the
content language and clones the whole English structure (categories, articles + fields + tags,
contact, six menus, 81 modules, megamenu block, template strings, associations) so the language is
live with English text and ready to translate in place. `remove-language.php <tag>` takes it back
(`--force` for a hand-built language such as ru-RU). Do not build a language by hand.

## 10. Anything that touches sending mail

`com_contact` *mailonline* is off on the build copy (no SMTP). Turning it on is a site-configuration
decision (System → Global Configuration → Mail) — do it only when told, and test with a real mailbox.
