<?php
/** Tracy Business — ACM `tb-kit-specs`: a small-caps heading and label / value rows divided by hairlines (Newsletter "Template specs"). Sidebar block. */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$title = trim((string) $helper->get('title'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('key'); $i < $n; $i++) { $k = trim((string) $helper->get('key', $i)); $v = trim((string) $helper->get('value', $i)); if ($k !== '' || $v !== '') $rows[] = [$k, $v]; }
if (!$rows) return;
$id = 'tb-kitspecs-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-specs tb-kitside tb-kitspecs" id="<?php echo $id; ?>"<?php if ($title !== '') : ?> aria-labelledby="<?php echo $id; ?>-title"<?php endif; ?>>
  <?php if ($title !== '') : ?><h2 class="tb-kitside__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <dl class="tb-kitspecs__list">
    <?php foreach ($rows as [$k, $v]) : ?><div class="tb-kitspecs__row"><dt class="tb-kitspecs__key"><?php echo $esc($k); ?></dt><dd class="tb-kitspecs__val"><?php echo $esc($v); ?></dd></div><?php endforeach; ?>
  </dl>
</section>
