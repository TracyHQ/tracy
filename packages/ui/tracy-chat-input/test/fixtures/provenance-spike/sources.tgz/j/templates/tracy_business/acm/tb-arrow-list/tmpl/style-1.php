<?php
/** Tracy Business — ACM `tb-arrow-list`: a title and rows led by a signal "→" (Accreditations, Scope of work, House rules, You may be looking for …). */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$title = trim((string) $helper->get('title')); $intro = trim((string) $helper->get('intro'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('row-title'); $i < $n; $i++) { $t = trim((string) $helper->get('row-title', $i)); if ($t !== '') $rows[] = [$t, trim((string) $helper->get('row-desc', $i)), $route((string) $helper->get('row-link', $i))]; }
if (!$rows) return;
?>
<div class="ja-acm acm-tb-arrow-list tb-arrows" id="tb-arrows-<?php echo (int) $module->id; ?>">
  <?php if ($title !== '') : ?><h2 class="tb-section__title tb-arrows__title"><?php echo $esc($title); ?></h2><?php endif; ?>
  <?php if ($intro !== '') : ?><p class="tb-arrows__intro"><?php echo $esc($intro); ?></p><?php endif; ?>
  <ul class="tb-arrows__list">
    <?php foreach ($rows as [$t, $d, $l]) : ?>
      <li class="tb-arrows__row"><span class="tb-arrows__arrow" aria-hidden="true">→</span><div><?php if ($l !== '') : ?><a class="tb-arrows__row-title" href="<?php echo $esc($l); ?>"><?php echo $esc($t); ?></a><?php else : ?><strong class="tb-arrows__row-title"><?php echo $esc($t); ?></strong><?php endif; ?><?php if ($d !== '') : ?><p class="tb-arrows__row-desc"><?php echo $esc($d); ?></p><?php endif; ?></div></li>
    <?php endforeach; ?>
  </ul>
</div>
