<?php
/** Tracy Business — ACM `tb-page-where`: two columns — H2 + paragraph + a two-column table of places (place | role) on the left, a map image on the right. About "Where we work". */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$route = static function (string $l): string { $l = trim($l); if ($l === '' || $l === '#') return ''; return preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $l) ? $l : \Joomla\CMS\Router\Route::_($l); };
$img = static function (string $raw): string { $i = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($raw); if ($i !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $i)) $i = \Joomla\CMS\Uri\Uri::root(true) . '/' . $i; return $i; };
$title = trim((string) $helper->get('title')); $text = trim((string) $helper->get('text'));
$map = $img((string) $helper->get('image')); $alt = trim((string) $helper->get('image-alt'));
$rows = [];
for ($i = 0, $n = (int) $helper->getRows('place'); $i < $n; $i++) { $p = trim((string) $helper->get('place', $i)); if ($p !== '') $rows[] = [$p, trim((string) $helper->get('role', $i))]; }
if ($title === '' && !$rows) return;
$id = 'tb-pg-where-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-page-where tb-pg-where" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-pg-where__inner">
    <div class="tb-pg-where__copy">
      <h2 class="tb-pg-h2 tb-pg-h2--sm" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
      <?php if ($text !== '') : ?><p class="tb-pg-where__text"><?php echo $esc($text); ?></p><?php endif; ?>
      <?php if ($rows) : ?>
        <table class="tb-pg-places">
          <tbody><?php foreach ($rows as [$p, $r]) : ?><tr><th scope="row" class="tb-pg-places__place"><?php echo $esc($p); ?></th><td class="tb-pg-places__role"><?php echo $esc($r); ?></td></tr><?php endforeach; ?></tbody>
        </table>
      <?php endif; ?>
    </div>
    <?php if ($map !== '') : ?><figure class="tb-pg-where__map"><img src="<?php echo $esc($map); ?>" alt="<?php echo $esc($alt); ?>" loading="lazy" decoding="async"></figure><?php endif; ?>
  </div>
</section>
