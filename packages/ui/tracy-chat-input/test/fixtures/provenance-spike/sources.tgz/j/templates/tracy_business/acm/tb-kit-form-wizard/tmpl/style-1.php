<?php
/**
 * Tracy Business — ACM `tb-kit-form-wizard`: the Form page's white card — "QUOTE REQUEST — STEP 2 OF 3",
 * a three-step bar (current step underlined in signal), facility-type chips, area, a region
 * select, planned start, a two-handle budget range, three checkboxes and Back / Next.
 *
 * This is a component library page, not a form: there is no <form> element and no action, every
 * control is disabled, and the buttons are type="button". A real multi-step form is an extension.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$g = static fn (string $k) => trim((string) $helper->get($k));
$list = static function (string $k) use ($helper): array { $out = []; for ($i = 0, $n = (int) $helper->getRows($k); $i < $n; $i++) { $v = trim((string) $helper->get($k, $i)); if ($v !== '') $out[] = $v; } return $out; };
$steps = $list('step'); $chips = $list('chip'); $regions = $list('region');
$checks = [];
for ($i = 0, $n = (int) $helper->getRows('check'); $i < $n; $i++) { $c = trim((string) $helper->get('check', $i)); if ($c !== '') $checks[] = [$c, (string) $helper->get('checked', $i) === '1']; }
$cur = max(1, (int) ($g('current-step') ?: 2)); $active = max(1, (int) ($g('chips-active') ?: 1));
$lo = min(100, max(0, (int) ($g('budget-lo') ?: 18))); $hi = min(100, max($lo, (int) ($g('budget-hi') ?: 58)));
$title = $g('title');
if ($title === '' && !$steps && !$chips) return;
$id = 'tb-kitwiz-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-kit-form-wizard tb-kitwiz" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container">
    <div class="tb-kitwiz__card">
      <?php if ($title !== '') : ?><h2 class="tb-kitwiz__label" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2><?php endif; ?>
      <?php if ($steps) : ?>
        <ol class="tb-kitwiz__steps">
          <?php foreach ($steps as $i => $s) : ?><li class="tb-kitwiz__step<?php echo $i + 1 === $cur ? ' is-current' : ''; ?>"<?php echo $i + 1 === $cur ? ' aria-current="step"' : ''; ?>><?php echo $esc($s); ?></li><?php endforeach; ?>
        </ol>
      <?php endif; ?>
      <div class="tb-kitwiz__grid">
        <?php if ($chips) : ?>
          <div class="tb-kitwiz__field">
            <?php if ($g('chips-label') !== '') : ?><span class="tb-kitwiz__flabel"><?php echo $esc($g('chips-label')); ?></span><?php endif; ?>
            <div class="tb-kitwiz__chips"><?php foreach ($chips as $i => $c) : ?><span class="tb-kitwiz__chip<?php echo $i + 1 === $active ? ' is-active' : ''; ?>"><?php echo $esc($c); ?></span><?php endforeach; ?></div>
          </div>
        <?php endif; ?>
        <?php if ($g('area-label') !== '') : ?>
          <div class="tb-kitwiz__field">
            <label class="tb-kitwiz__flabel" for="<?php echo $id; ?>-area"><?php echo $esc($g('area-label')); ?></label>
            <input class="tb-kitwiz__input" id="<?php echo $id; ?>-area" type="text" placeholder="<?php echo $esc($g('area-value')); ?>" disabled>
          </div>
        <?php endif; ?>
        <?php if ($g('region-label') !== '' && $regions) : ?>
          <div class="tb-kitwiz__field">
            <label class="tb-kitwiz__flabel" for="<?php echo $id; ?>-region"><?php echo $esc($g('region-label')); ?></label>
            <span class="tb-kitwiz__select"><select class="tb-kitwiz__input" id="<?php echo $id; ?>-region" disabled><?php foreach ($regions as $r) : ?><option><?php echo $esc($r); ?></option><?php endforeach; ?></select></span>
          </div>
        <?php endif; ?>
        <?php if ($g('start-label') !== '') : ?>
          <div class="tb-kitwiz__field">
            <label class="tb-kitwiz__flabel" for="<?php echo $id; ?>-start"><?php echo $esc($g('start-label')); ?></label>
            <input class="tb-kitwiz__input" id="<?php echo $id; ?>-start" type="text" placeholder="<?php echo $esc($g('start-value')); ?>" disabled>
          </div>
        <?php endif; ?>
      </div>
      <?php if ($g('budget-label') !== '') : ?>
        <div class="tb-kitwiz__budget">
          <span class="tb-kitwiz__flabel"><?php echo $esc($g('budget-label')); ?><?php if ($g('budget-value') !== '') : ?> · <?php echo $esc($g('budget-value')); ?><?php endif; ?></span>
          <div class="tb-kitwiz__range" role="img" aria-label="<?php echo $esc(trim($g('budget-label') . ' ' . $g('budget-value'))); ?>">
            <span class="tb-kitwiz__range-fill" style="left:<?php echo $lo; ?>%;right:<?php echo 100 - $hi; ?>%"></span>
            <span class="tb-kitwiz__range-handle" style="left:<?php echo $lo; ?>%"></span>
            <span class="tb-kitwiz__range-handle" style="left:<?php echo $hi; ?>%"></span>
          </div>
        </div>
      <?php endif; ?>
      <?php if ($checks) : ?>
        <div class="tb-kitwiz__extras">
          <?php if ($g('extras-title') !== '') : ?><p class="tb-kitwiz__label"><?php echo $esc($g('extras-title')); ?></p><?php endif; ?>
          <ul class="tb-kitwiz__checks">
            <?php foreach ($checks as $i => [$c, $on]) : ?><li><label class="tb-kitwiz__check"><input type="checkbox"<?php echo $on ? ' checked' : ''; ?> disabled><span class="tb-kitwiz__box" aria-hidden="true"></span><?php echo $esc($c); ?></label></li><?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
      <?php if ($g('back-text') !== '' || $g('next-text') !== '') : ?>
        <div class="tb-kitwiz__actions">
          <?php if ($g('back-text') !== '') : ?><button class="tb-btn tb-btn--outline tb-kitwiz__btn" type="button" disabled><?php echo $esc($g('back-text')); ?></button><?php endif; ?>
          <?php if ($g('next-text') !== '') : ?><button class="tb-btn tb-btn--signal tb-kitwiz__btn" type="button" disabled><?php echo $esc($g('next-text')); ?></button><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
    <?php if ($g('note') !== '') : ?><p class="tb-kitwiz__note"><?php echo $esc($g('note')); ?></p><?php endif; ?>
  </div>
</section>
