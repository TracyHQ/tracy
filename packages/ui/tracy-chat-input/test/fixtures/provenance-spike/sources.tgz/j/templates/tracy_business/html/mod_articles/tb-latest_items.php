<?php

/**
 * Tracy Business — mod_articles, `tb-latest_items`: thumbnail (intro image) · title · date.
 * The date uses the template's TPL_TRACY_BUSINESS_DATE_FORMAT, not the module's date format field.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$esc   = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dateF = Text::_('TPL_TRACY_BUSINESS_DATE_FORMAT');
?>
<ul class="tb-sidelatest">
    <?php foreach ($items as $item) : ?>
        <?php
        $src = (string) ($item->imageSrc ?? '');
        if ($src !== '' && !preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $src)) {
            $src = Uri::root(true) . '/' . $src;
        }
        $when = $item->publish_up ?: $item->created;
        ?>
        <li>
            <a class="tb-sidelatest__item<?php echo $src === '' ? ' tb-sidelatest__item--noimg' : ''; ?>" href="<?php echo $esc($item->link); ?>">
                <?php if ($src !== '') : ?><span class="tb-sidelatest__thumb"><img src="<?php echo $esc($src); ?>" alt="" width="192" height="136" loading="lazy" decoding="async"></span><?php endif; ?>
                <span>
                    <span class="tb-sidelatest__title"><?php echo $esc($item->title); ?></span>
                    <span class="tb-sidelatest__date"><time datetime="<?php echo $esc(HTMLHelper::_('date', $when, 'Y-m-d')); ?>"><?php echo $esc(HTMLHelper::_('date', $when, $dateF)); ?></time></span>
                </span>
            </a>
        </li>
    <?php endforeach; ?>
</ul>
