<?php

/**
 * Tracy Business — light/dark toggle.
 *
 * An element rather than markup inside the header block: T4 blocks are echoed as plain strings, so
 * PHP inside them never runs and a label written there could never be translated. The element is a
 * real PHP layout, so the label goes through Text::_() and follows the site language.
 *
 * The behaviour itself lives in js/darkmode.js and the first paint in theme-resolve.php; this file
 * only renders the control.
 *
 * @package northgate
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
?>
<button type="button" class="tb-theme-toggle" data-tracy-theme-toggle aria-pressed="false"
        aria-label="<?php echo htmlspecialchars(Text::_('TPL_TRACY_BUSINESS_THEME_TOGGLE_ARIA'), ENT_QUOTES, 'UTF-8'); ?>">
    <span class="tb-theme-toggle__icon" aria-hidden="true"></span>
    <span class="tb-theme-toggle__label tb-theme-toggle__label--to-dark"><?php echo Text::_('TPL_TRACY_BUSINESS_THEME_DARK'); ?></span>
    <span class="tb-theme-toggle__label tb-theme-toggle__label--to-light"><?php echo Text::_('TPL_TRACY_BUSINESS_THEME_LIGHT'); ?></span>
</button>
