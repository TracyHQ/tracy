<?php
/**
 * Tracy Business — ACM `tb-hero`, style 1: the ink masthead.
 *
 * Reference: Home.html hero region — eyebrow with a signal dot, a Newsreader headline whose last
 * phrase is italic signal, a lead, two buttons (signal + outline-light), a 4:5 photo on the right,
 * and the four-cell stats strip under it. Every string, link, image and stat is an admin field;
 * the stats are a repeatable fieldset so the owner adds or removes cells without code.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);

$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$url = static function (string $link): string {
    $link = trim($link);
    if ($link === '' || $link === '#') return '';
    if (preg_match('~^(?:[a-z][a-z0-9+.-]*:|/|#)~i', $link)) return $link;
    return \Joomla\CMS\Router\Route::_($link);
};
$media = static function (string $value): string {
    $value = explode('#', trim($value))[0];
    if ($value === '') return '';
    if (!preg_match('~^(?:[a-z][a-z0-9+.-]*:|/)~i', $value)) $value = \Joomla\CMS\Uri\Uri::root(true) . '/' . $value;
    return $value;
};

$eyebrow  = trim((string) $helper->get('eyebrow'));
$title    = trim((string) $helper->get('title'));
$accent   = trim((string) $helper->get('title-accent'));
$lead     = trim((string) $helper->get('lead'));
$btn1Text = trim((string) $helper->get('btn-1-text')); $btn1Link = $url((string) $helper->get('btn-1-link'));
$btn2Text = trim((string) $helper->get('btn-2-text')); $btn2Link = $url((string) $helper->get('btn-2-link'));
$image    = $media((string) $helper->get('image'));
$imageAlt = trim((string) $helper->get('image-alt'));

$stats = [];
for ($i = 0, $n = (int) $helper->getRows('stat-value'); $i < $n; $i++) {
    $v = trim((string) $helper->get('stat-value', $i));
    $l = trim((string) $helper->get('stat-label', $i));
    if ($v !== '' || $l !== '') $stats[] = [$v, $l];
}

$id = 'tb-hero-' . (int) $module->id;
?>
<section class="ja-acm acm-tb-hero tb-hero" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container tb-hero__grid">
    <div class="tb-hero__copy">
      <?php if ($eyebrow !== '') : ?>
        <p class="tb-hero__eyebrow"><span class="tb-hero__dot" aria-hidden="true"></span><?php echo $esc($eyebrow); ?></p>
      <?php endif; ?>
      <h1 class="tb-hero__title" id="<?php echo $id; ?>-title">
        <?php echo $esc($title); ?>
        <?php /* the design breaks the line before the italic phrase */ ?>
        <?php if ($accent !== '') : ?><br><em class="tb-hero__accent"><?php echo $esc($accent); ?></em><?php endif; ?>
      </h1>
      <?php if ($lead !== '') : ?><p class="tb-hero__lead"><?php echo $esc($lead); ?></p><?php endif; ?>
      <?php if (($btn1Text !== '' && $btn1Link !== '') || ($btn2Text !== '' && $btn2Link !== '')) : ?>
        <div class="tb-hero__actions">
          <?php if ($btn1Text !== '' && $btn1Link !== '') : ?><a class="tb-btn tb-btn--signal" href="<?php echo $esc($btn1Link); ?>"><?php echo $esc($btn1Text); ?></a><?php endif; ?>
          <?php if ($btn2Text !== '' && $btn2Link !== '') : ?><a class="tb-btn tb-btn--outline-light" href="<?php echo $esc($btn2Link); ?>"><?php echo $esc($btn2Text); ?></a><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
    <?php if ($image !== '') : ?>
      <figure class="tb-hero__visual"><img src="<?php echo $esc($image); ?>" alt="<?php echo $esc($imageAlt); ?>" width="1024" height="1280" fetchpriority="high" decoding="async"></figure>
    <?php endif; ?>
  </div>
  <?php if ($stats) : ?>
    <div class="tb-container">
      <dl class="tb-hero__stats">
        <?php foreach ($stats as [$v, $l]) : ?>
          <div class="tb-hero__stat"><dt class="tb-hero__stat-value"><?php echo $esc($v); ?></dt><dd class="tb-hero__stat-label"><?php echo $esc($l); ?></dd></div>
        <?php endforeach; ?>
      </dl>
    </div>
  <?php endif; ?>
</section>
