<?php
/**
 * Tracy Business — ACM `tb-projects`, style 1: "Selected projects" on the paper-2 band.
 * Title, category filter chips (the sub-categories of the source category, each a real category
 * route), an "All projects →" link to the category, then one featured card (tall photo, first
 * article) and the rest as photo-topped cards. Tag line = category · year, read from the article.
 */
defined('_JEXEC') or die;
require_once dirname(__DIR__, 2) . '/data.php';
require dirname(__DIR__) . '/_load.php'; // not _once: the closures must exist in EVERY layout's scope
if (!($helper instanceof TracyAcmData)) $helper = new TracyAcmData($helper, (string) $module->params);
$esc = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

$title    = trim((string) $helper->get('title'));
$catId    = (int) $helper->get('source-category');
$count    = max(1, (int) ($helper->get('count') ?: 3));
$filters  = (string) $helper->get('show-filters') !== '0';
$allText  = trim((string) $helper->get('all-text'));
$caseText = trim((string) $helper->get('case-text'));
$items    = $ngLoadProjects($catId, $count, $ngSelectedIds($module, 'tb-projects', 'selected'));
if (!$items) return;
$allUrl = $catId ? $ngCategoryUrl($catId) : '';
$children = $filters && $catId ? $ngChildCategories($catId) : [];
$id = 'tb-projects-' . (int) $module->id;
$featured = array_shift($items);
?>
<section class="ja-acm acm-tb-projects tb-section tb-projects" id="<?php echo $id; ?>" aria-labelledby="<?php echo $id; ?>-title">
  <div class="tb-container">
    <header class="tb-section__head">
      <h2 class="tb-section__title" id="<?php echo $id; ?>-title"><?php echo $esc($title); ?></h2>
      <div class="tb-projects__tools">
        <?php if ($children) : ?>
          <nav class="tb-chips" aria-label="<?php echo $esc($title); ?>">
            <a class="tb-chip is-active" href="<?php echo $esc($allUrl); ?>" aria-current="true"><?php echo \Joomla\CMS\Language\Text::_('TPL_TRACY_BUSINESS_ACM_FILTER_ALL'); ?></a>
            <?php foreach ($children as $c) : ?><a class="tb-chip" href="<?php echo $esc($ngCategoryUrl((int) $c['id'])); ?>"><?php echo $esc($c['title']); ?></a><?php endforeach; ?>
          </nav>
        <?php endif; ?>
        <?php if ($allText !== '' && $allUrl !== '') : ?><a class="tb-textlink" href="<?php echo $esc($allUrl); ?>"><?php echo $esc($allText); ?></a><?php endif; ?>
      </div>
    </header>
    <div class="tb-projects__grid">
      <article class="tb-pcard tb-pcard--featured">
        <?php if ($featured['image'] !== '') : ?><a class="tb-pcard__media" href="<?php echo $esc($featured['url']); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($featured['image']); ?>" alt="" width="800" height="500" loading="lazy" decoding="async"></a><?php endif; ?>
        <div class="tb-pcard__body">
          <p class="tb-pcard__tag"><?php echo $esc($featured['category']); ?> · <?php echo $esc($featured['year']); ?></p>
          <h3 class="tb-pcard__title"><a href="<?php echo $esc($featured['url']); ?>"><?php echo $esc($featured['title']); ?></a></h3>
          <?php if ($featured['intro'] !== '') : ?><p class="tb-pcard__desc"><?php echo $esc($featured['intro']); ?></p><?php endif; ?>
          <?php if ($caseText !== '') : ?><a class="tb-textlink tb-textlink--sm" href="<?php echo $esc($featured['url']); ?>"><?php echo $esc($caseText); ?></a><?php endif; ?>
        </div>
      </article>
      <?php foreach ($items as $p) : ?>
        <article class="tb-pcard">
          <?php if ($p['image'] !== '') : ?><a class="tb-pcard__media" href="<?php echo $esc($p['url']); ?>" tabindex="-1" aria-hidden="true"><img src="<?php echo $esc($p['image']); ?>" alt="" width="800" height="600" loading="lazy" decoding="async"></a><?php endif; ?>
          <div class="tb-pcard__body">
            <p class="tb-pcard__tag"><?php echo $esc($p['category']); ?> · <?php echo $esc($p['year']); ?></p>
            <h3 class="tb-pcard__title"><a href="<?php echo $esc($p['url']); ?>"><?php echo $esc($p['title']); ?></a></h3>
            <?php if ($p['intro'] !== '') : ?><p class="tb-pcard__desc"><?php echo $esc($p['intro']); ?></p><?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
