<?php
/**
 * Add a site language to this Joomla site by cloning the English structure.
 *
 *   php templates/tracy_business/tools/add-language.php <tag> [--from en-GB] [--sef xx] [--dry-run]
 *   e.g. php templates/tracy_business/tools/add-language.php ko-KR
 *
 * Run from the webroot with PHP CLI. What it does, in order:
 *   1. installs the official language pack if it is missing (docs/language-packs.json → Joomla 6,
 *      then 5, then 4 — older packs install fine; strings they lack fall back to English);
 *   2. makes sure the content language exists and is published (sef = the lowercase 639-1 code);
 *   3. clones from the source language: content + contact categories, tags, articles (with custom
 *      field values and tags), contacts, the six `tb-*-<sef>` menus with every item (home included,
 *      links remapped), every module (menu assignment and inner ids remapped), the T4 megamenu
 *      settings for the new main menu, and the template language file + override file;
 *   4. creates the EN↔new associations for categories, articles, contacts and menu items;
 *   5. clears the T4 cache.
 * Everything it creates carries note `lang:<tag>` so `remove-language.php <tag>` can take it back.
 * The new language goes live at once with ENGLISH text — that is the point: the structure is
 * complete and every item is ready to be translated in place (admin or the Cowork door).
 *
 * Refuses: an unknown tag, a language that already has content, and cloning FROM a language that
 * is not on the site.
 */
declare(strict_types=1);
const _JEXEC = 1;
$webroot = dirname(__DIR__, 3);
define('JPATH_BASE', $webroot);
require_once JPATH_BASE . '/includes/defines.php';
require_once JPATH_BASE . '/includes/framework.php';

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerHelper;
use Joomla\CMS\Table\Table;

// ---------------------------------------------------------------- boot (CLI, admin identity)
$container = Factory::getContainer();
foreach (['session', 'JSession', \Joomla\CMS\Session\Session::class, \Joomla\Session\Session::class, \Joomla\Session\SessionInterface::class] as $alias) { $container->alias($alias, 'session.cli'); }
$app = $container->get(\Joomla\Console\Application::class);
Factory::$application = $app;
$app->createExtensionNamespaceMap();
(function () { $this->populateHttpHost(); })->call($app);
\Joomla\CMS\Plugin\PluginHelper::importPlugin('system', null, true, $app->getDispatcher());
$db = $container->get(\Joomla\Database\DatabaseInterface::class);
$adminId = (int) $db->setQuery("SELECT MIN(u.id) FROM #__users u JOIN #__user_usergroup_map m ON m.user_id = u.id WHERE m.group_id = 8")->loadResult();
$app->loadIdentity($container->get(\Joomla\CMS\User\UserFactoryInterface::class)->loadUserById($adminId));
Factory::getLanguage()->load('joomla', JPATH_ADMINISTRATOR);

// ---------------------------------------------------------------- arguments
$args = array_slice($argv, 1);
$opt = static function (string $name, $default = null) use (&$args) { $i = array_search($name, $args, true); if ($i === false) { return $default; } $v = $args[$i + 1] ?? true; array_splice($args, $i, $v === true ? 1 : 2); return $v; };
$dry = (bool) $opt('--dry-run', false);
$from = (string) $opt('--from', 'en-GB');
$sefOpt = $opt('--sef');
$tag = $args[0] ?? '';
$log = static function (string $m): void { fwrite(STDOUT, $m . "\n"); };
$fail = static function (string $m): never { fwrite(STDERR, "add-language: $m\n"); exit(1); };
if (!preg_match('/^[a-z]{2,3}-[A-Z]{2}$/', $tag)) { $fail('usage: add-language.php <xx-YY> [--from en-GB] [--sef xx] [--dry-run]'); }
if ($tag === $from) { $fail('source and target are the same language'); }
$T = JPATH_BASE . '/templates/tracy_business';
$packs = json_decode((string) @file_get_contents("$T/docs/language-packs.json"), true)['packs'] ?? [];
$now = Factory::getDate()->toSql();
$note = "lang:$tag";
$sef = $sefOpt ? strtolower((string) $sefOpt) : strtolower(substr($tag, 0, strpos($tag, '-')));
$fromSef = (string) $db->setQuery("SELECT sef FROM #__languages WHERE lang_code = " . $db->quote($from))->loadResult();
if ($fromSef === '') { $fail("$from is not a content language on this site"); }
if ((int) $db->setQuery("SELECT COUNT(*) FROM #__content WHERE language = " . $db->quote($tag))->loadResult() > 0) { $fail("$tag already has articles — remove-language.php first if you want a clean clone"); }
$q = static fn (string $sql) => $db->setQuery($sql)->loadAssocList();
$quote = static fn ($v) => $db->quote((string) $v);
$log(($dry ? '[dry-run] ' : '') . "add $tag (sef /$sef/) cloned from $from (/$fromSef/)");

// ---------------------------------------------------------------- 1. language pack
$installed = (int) $db->setQuery("SELECT COUNT(*) FROM #__extensions WHERE type = 'language' AND client_id = 0 AND element = " . $quote($tag))->loadResult() > 0;
if (!$installed) {
    $pack = $packs[$tag] ?? null;
    if (!$pack) { $fail("no official Joomla language pack for $tag (docs/language-packs.json lists " . count($packs) . " tags); install one by hand first"); }
    $log("installing {$pack['name']} {$pack['version']} (Joomla {$pack['major']} pack) from {$pack['url']}");
    if (!$dry) {
        $file = InstallerHelper::downloadPackage($pack['url'], 'tracy-lang-' . $tag . '.zip');
        if ($file === false) { $fail('download failed'); }
        $path = $app->get('tmp_path') . '/' . $file;
        if ($pack['sha256'] && hash_file('sha256', $path) !== $pack['sha256']) { @unlink($path); $fail('sha256 mismatch on the downloaded pack'); }
        $unpacked = InstallerHelper::unpack($path);
        if (!$unpacked || !Installer::getInstance()->install($unpacked['dir'])) { $fail('Joomla refused the pack'); }
        InstallerHelper::cleanupInstall($path, $unpacked['extractdir']);
        $log('pack installed');
    }
} else { $log('pack already installed'); }

// ---------------------------------------------------------------- 2. content language
$langRow = $q("SELECT * FROM #__languages WHERE lang_code = " . $quote($tag))[0] ?? null;
$native = $packs[$tag]['name'] ?? $tag;
if (!$dry) {
    if ($langRow) {
        $db->setQuery("UPDATE #__languages SET published = 1, sef = " . $quote($sef) . " WHERE lang_id = " . (int) $langRow['lang_id'])->execute();
    } else {
        $ordering = (int) $db->setQuery("SELECT MAX(ordering) FROM #__languages")->loadResult() + 1;
        $db->setQuery("INSERT INTO #__languages (asset_id, lang_code, title, title_native, sef, image, description, published, access, ordering, metakey, metadesc, sitename) VALUES (0, " . $quote($tag) . ", " . $quote($native) . ", " . $quote($native) . ", " . $quote($sef) . ", " . $quote(strtolower(substr($tag, -2))) . ", '', 1, 1, $ordering, '', '', '')")->execute();
    }
}
$log("content language $tag published, sef /$sef/");

// ---------------------------------------------------------------- helpers
$assocKey = static function (string $context, array $ids) use ($db): void {
    // Joomla groups associations by a shared key; join the source's existing group, do not replace it.
    $members = [];
    foreach ($ids as $id) {
        $key = $db->setQuery("SELECT `key` FROM #__associations WHERE context = " . $db->quote($context) . " AND id = " . (int) $id)->loadResult();
        if ($key) { foreach ($db->setQuery("SELECT id FROM #__associations WHERE context = " . $db->quote($context) . " AND `key` = " . $db->quote($key))->loadColumn() as $m) { $members[(int) $m] = true; } }
        $members[(int) $id] = true;
    }
    $table = ['com_content.item' => '#__content', 'com_categories.item' => '#__categories', 'com_menus.item' => '#__menu', 'com_contact.item' => '#__contact_details'][$context];
    $byLang = [];
    foreach (array_keys($members) as $m) { $l = (string) $db->setQuery("SELECT language FROM $table WHERE id = $m")->loadResult(); if ($l !== '' && $l !== '*') { $byLang[$l] = $m; } }
    if (count($byLang) < 2) { return; }
    ksort($byLang);
    $key = md5(json_encode($byLang));
    foreach ($byLang as $m) {
        $db->setQuery("DELETE FROM #__associations WHERE context = " . $db->quote($context) . " AND id = $m")->execute();
        $db->setQuery("INSERT INTO #__associations (id, context, `key`) VALUES ($m, " . $db->quote($context) . ", " . $db->quote($key) . ")")->execute();
    }
};
$catMap = []; $artMap = []; $tagMap = []; $contactMap = []; $menuMap = []; $modMap = []; $menutypeMap = [];
$remapLink = static function (string $link) use (&$artMap, &$catMap, &$contactMap): string {
    return preg_replace_callback('/(option=(com_content|com_contact)&(?:[^&]*&)*?(?:view=(article|category|featured|contact)&)?(?:[^&]*&)*?id=)(\d+)/', static function ($m) use (&$artMap, &$catMap, &$contactMap) {
        $id = (int) $m[4]; $view = $m[3];
        if ($m[2] === 'com_contact') { return $m[1] . ($contactMap[$id] ?? $id); }
        if ($view === 'category') { return $m[1] . ($catMap[$id] ?? $id); }
        return $m[1] . ($artMap[$id] ?? $id);
    }, $link) ?? $link;
};

// ---------------------------------------------------------------- 3a. categories (content + contact), tree order
$cats = $q("SELECT * FROM #__categories WHERE language = " . $quote($from) . " AND extension IN ('com_content','com_contact') AND published = 1 ORDER BY lft");
foreach ($cats as $c) {
    $parent = (int) $c['parent_id'];
    $newParent = $catMap[$parent] ?? $parent; // a parent outside the clone (root, or a '*' category) stays
    $log("category {$c['path']}");
    if ($dry) { $catMap[(int) $c['id']] = -1; continue; }
    $t = Table::getInstance('Category'); $t->setLocation($newParent, 'last-child');
    $data = ['title' => $c['title'], 'alias' => $c['alias'], 'extension' => $c['extension'], 'published' => 1, 'access' => (int) $c['access'], 'language' => $tag, 'note' => $note,
        'description' => $c['description'], 'params' => $c['params'], 'metadata' => $c['metadata'], 'metadesc' => $c['metadesc'], 'metakey' => $c['metakey'], 'created_user_id' => $adminId, 'created_time' => $now, 'modified_time' => $now];
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("category {$c['title']}: " . $t->getError()); }
    $catMap[(int) $c['id']] = (int) $t->id;
    $assocKey('com_categories.item', [(int) $c['id'], (int) $t->id]);
}

// ---------------------------------------------------------------- 3b. tags
foreach ($q("SELECT * FROM #__tags WHERE language = " . $quote($from) . " AND id > 1 ORDER BY lft") as $tg) {
    $log("tag {$tg['path']}");
    if ($dry) { continue; }
    $t = new \Joomla\Component\Tags\Administrator\Table\TagTable($db); $t->setLocation($tagMap[(int) $tg['parent_id']] ?? (int) $tg['parent_id'], 'last-child');
    // tag aliases are unique across the whole table (COM_TAGS_ERROR_UNIQUE_ALIAS), so the clone takes a language suffix
    $data = ['title' => $tg['title'], 'alias' => $tg['alias'] . '-' . $sef, 'published' => 1, 'access' => (int) $tg['access'], 'language' => $tag, 'note' => $note, 'description' => $tg['description'], 'params' => $tg['params'], 'metadata' => $tg['metadata'], 'created_user_id' => $adminId, 'created_time' => $now, 'modified_time' => $now, 'images' => $tg['images'] ?: '{}', 'urls' => $tg['urls'] ?: '{}', 'metadesc' => '', 'metakey' => ''];
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("tag {$tg['title']}: " . $t->getError()); }
    $tagMap[(int) $tg['id']] = (int) $t->id;
}

// ---------------------------------------------------------------- 3c. articles (+ field values, tags, featured)
$arts = $q("SELECT * FROM #__content WHERE language = " . $quote($from) . " AND state = 1 ORDER BY catid, ordering, id");
foreach ($arts as $a) {
    $log("article {$a['alias']}");
    if ($dry) { continue; }
    $t = Table::getInstance('Content');
    $data = $a; unset($data['id'], $data['asset_id'], $data['checked_out'], $data['checked_out_time'], $data['hits'], $data['version']);
    $data['language'] = $tag; $data['note'] = $note; $data['catid'] = $catMap[(int) $a['catid']] ?? (int) $a['catid']; $data['modified'] = $now; $data['created_by'] = $adminId; $data['modified_by'] = $adminId;
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("article {$a['title']}: " . $t->getError()); }
    $new = (int) $t->id; $artMap[(int) $a['id']] = $new;
    if ((int) $a['featured'] === 1) { $db->setQuery("INSERT IGNORE INTO #__content_frontpage (content_id, ordering) SELECT $new, ordering FROM #__content_frontpage WHERE content_id = " . (int) $a['id'])->execute(); }
    $db->setQuery("INSERT INTO #__fields_values (field_id, item_id, value) SELECT field_id, $new, value FROM #__fields_values WHERE item_id = " . (int) $a['id'])->execute();
    foreach ($db->setQuery("SELECT tag_id FROM #__contentitem_tag_map WHERE type_alias = 'com_content.article' AND content_item_id = " . (int) $a['id'])->loadColumn() as $tid) {
        $nt = $tagMap[(int) $tid] ?? null; if (!$nt) { continue; }
        $db->setQuery("INSERT INTO #__contentitem_tag_map (type_alias, core_content_id, content_item_id, tag_id, tag_date, type_id) SELECT 'com_content.article', 0, $new, $nt, " . $quote($now) . ", type_id FROM #__contentitem_tag_map WHERE content_item_id = " . (int) $a['id'] . " AND tag_id = " . (int) $tid . " LIMIT 1")->execute();
    }
    $assocKey('com_content.item', [(int) $a['id'], $new]);
}
if (!$dry && $tagMap) {
    // Joomla keeps a UCM row per tagged item; the front end tolerates its absence, the admin Tags list does not count it. Cheap to add.
    $db->setQuery("UPDATE #__contentitem_tag_map m JOIN #__ucm_content u ON u.core_content_item_id = m.content_item_id AND u.core_type_alias = 'com_content.article' SET m.core_content_id = u.core_content_id WHERE m.core_content_id = 0")->execute();
}

// ---------------------------------------------------------------- 3d. contacts
foreach ($q("SELECT * FROM #__contact_details WHERE language = " . $quote($from) . " AND published = 1") as $c) {
    $log("contact {$c['alias']}");
    if ($dry) { continue; }
    $t = new \Joomla\Component\Contact\Administrator\Table\ContactTable($db);
    $data = $c; unset($data['id'], $data['asset_id'], $data['checked_out'], $data['checked_out_time'], $data['hits'], $data['version']);
    $data['language'] = $tag; $data['misc'] = $note; $data['catid'] = $catMap[(int) $c['catid']] ?? (int) $c['catid']; $data['modified'] = $now; $data['created_by'] = $adminId;
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("contact {$c['name']}: " . $t->getError()); }
    $contactMap[(int) $c['id']] = (int) $t->id;
    $assocKey('com_contact.item', [(int) $c['id'], (int) $t->id]);
}

// ---------------------------------------------------------------- 3e. menus (types, then items in tree order)
foreach ($q("SELECT * FROM #__menu_types WHERE menutype LIKE " . $quote('%-' . $fromSef)) as $mt) {
    $newType = preg_replace('/-' . preg_quote($fromSef, '/') . '$/', '-' . $sef, $mt['menutype']);
    $menutypeMap[$mt['menutype']] = $newType;
    $title = preg_replace('/\(' . preg_quote($fromSef, '/') . '\)$/', "($sef)", $mt['title']);
    $log("menu $newType");
    if ($dry) { continue; }
    if (!$db->setQuery("SELECT id FROM #__menu_types WHERE menutype = " . $quote($newType))->loadResult()) {
        $db->setQuery("INSERT INTO #__menu_types (asset_id, menutype, title, description, client_id) VALUES (0, " . $quote($newType) . ", " . $quote($title) . ", " . $quote("cloned from {$mt['menutype']} by add-language") . ", 0)")->execute();
    }
}
$items = $q("SELECT * FROM #__menu WHERE client_id = 0 AND language = " . $quote($from) . " AND published = 1 AND menutype IN (" . implode(',', array_map($quote, array_keys($menutypeMap) ?: ['-'])) . ") ORDER BY lft");
foreach ($items as $it) {
    $log("menu item {$it['menutype']} / {$it['path']}");
    if ($dry) { continue; }
    $params = json_decode($it['params'] ?: '{}', true) ?: [];
    $t = Table::getInstance('Menu');
    $parent = (int) $it['parent_id']; $newParent = $parent > 1 ? ($menuMap[$parent] ?? $parent) : 1;
    $t->setLocation($newParent, 'last-child');
    $data = ['menutype' => $menutypeMap[$it['menutype']], 'title' => $it['title'], 'alias' => $it['alias'], 'note' => $note, 'path' => '', 'link' => $remapLink($it['link']), 'type' => $it['type'],
        'published' => 1, 'component_id' => (int) $it['component_id'], 'browserNav' => (int) $it['browserNav'], 'access' => (int) $it['access'], 'img' => $it['img'], 'template_style_id' => (int) $it['template_style_id'],
        'params' => json_encode($params), 'home' => (int) $it['home'], 'language' => $tag, 'client_id' => 0, 'level' => (int) $it['level']];
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("menu item {$it['title']}: " . $t->getError()); }
    $t->rebuildPath($t->id);
    $menuMap[(int) $it['id']] = (int) $t->id;
    $assocKey('com_menus.item', [(int) $it['id'], (int) $t->id]);
}
// second pass: alias items point at items of OTHER menus (Resources → the hidden kit menu), which
// may have been cloned after them — resolve every aliasoptions now that the whole map exists
foreach ($items as $it) {
    $params = json_decode($it['params'] ?: '{}', true) ?: [];
    if (empty($params['aliasoptions']) || empty($menuMap[(int) $it['id']])) { continue; }
    $target = $menuMap[(int) $params['aliasoptions']] ?? null; if (!$target) { continue; }
    $params['aliasoptions'] = (string) $target;
    $db->setQuery("UPDATE #__menu SET params = " . $quote(json_encode($params)) . " WHERE id = " . (int) $menuMap[(int) $it['id']])->execute();
}

// ---------------------------------------------------------------- 3f. modules (+ assignment), ids inside params remapped
$mods = $q("SELECT * FROM #__modules WHERE client_id = 0 AND language = " . $quote($from) . " AND published = 1 ORDER BY position, ordering");
foreach ($mods as $m) {
    $log("module {$m['position']} / {$m['title']}");
    if ($dry) { continue; }
    $params = (string) $m['params'];
    $params = preg_replace_callback('/Itemid=(\d+)/', static fn ($x) => 'Itemid=' . ($menuMap[(int) $x[1]] ?? $x[1]), $params);
    foreach ($menutypeMap as $old => $new) { $params = str_replace('"' . $old . '"', '"' . $new . '"', $params); }
    $p = json_decode($params, true);
    if (is_array($p)) {
        foreach (['catid', 'category', 'parent'] as $k) {
            if (isset($p[$k])) { $p[$k] = is_array($p[$k]) ? array_map(static fn ($v) => (string) ($catMap[(int) $v] ?? $v), $p[$k]) : (string) ($catMap[(int) $p[$k]] ?? $p[$k]); }
        }
        $params = json_encode($p);
    }
    $t = Table::getInstance('Module');
    $title = preg_replace('/\(' . preg_quote($fromSef, '/') . '\)$/', "($sef)", $m['title']);
    $data = ['title' => $title, 'note' => $note, 'content' => $m['content'], 'ordering' => (int) $m['ordering'], 'position' => $m['position'], 'published' => 1, 'module' => $m['module'], 'access' => (int) $m['access'],
        'showtitle' => (int) $m['showtitle'], 'params' => $params, 'client_id' => 0, 'language' => $tag, 'publish_up' => null, 'publish_down' => null];
    if (!$t->bind($data) || !$t->check() || !$t->store()) { $fail("module {$m['title']}: " . $t->getError()); }
    $modMap[(int) $m['id']] = (int) $t->id;
    foreach ($db->setQuery("SELECT menuid FROM #__modules_menu WHERE moduleid = " . (int) $m['id'])->loadColumn() as $mid) {
        $mid = (int) $mid; $target = $mid === 0 ? 0 : ($mid > 0 ? ($menuMap[$mid] ?? null) : -($menuMap[-$mid] ?? 0));
        if ($target === null) { continue; } // assigned to a page of another language: not ours
        $db->setQuery("INSERT INTO #__modules_menu (moduleid, menuid) VALUES (" . (int) $t->id . ", $target)")->execute();
    }
}

// ---------------------------------------------------------------- 3g. megamenu settings, template strings, overrides
if (!$dry) {
    $navFile = "$T/etc/navigation/tracy-business.json";
    $nav = json_decode((string) file_get_contents($navFile), true);
    $mega = json_decode((string) ($nav['mega_settings'] ?? '{}'), true) ?: [];
    $srcType = "tb-main-$fromSef"; $dstType = "tb-main-$sef";
    if (isset($mega[$srcType])) {
        $block = [];
        foreach ($mega[$srcType] as $itemId => $conf) {
            $newId = $menuMap[(int) $itemId] ?? null; if (!$newId) { continue; }
            $json = json_encode($conf);
            $json = preg_replace_callback('/"items":"([\d,]+)"/', static fn ($x) => '"items":"' . implode(',', array_map(static fn ($i) => $menuMap[(int) $i] ?? $i, explode(',', $x[1]))) . '"', $json);
            $json = preg_replace_callback('/"module_id":"(\d+)"/', static fn ($x) => '"module_id":"' . ($modMap[(int) $x[1]] ?? $x[1]) . '"', $json);
            $block[(string) $newId] = json_decode($json, true);
        }
        $mega[$dstType] = $block;
        $nav['mega_settings'] = json_encode($mega);
        file_put_contents($navFile, json_encode($nav, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $log("megamenu settings: $dstType (" . count($block) . " items)");
    }
    foreach (["$T/language", JPATH_BASE . '/language'] as $dir) {
        @mkdir("$dir/$tag", 0755, true);
        foreach (glob("$dir/$from/$from.tpl_tracy_business*.ini") as $src) { $dst = "$dir/$tag/" . str_replace($from, $tag, basename($src)); if (!is_file($dst)) { copy($src, $dst); $log('strings: ' . substr($dst, strlen(JPATH_BASE) + 1)); } }
    }
    $ovr = JPATH_BASE . "/language/overrides/$from.override.ini"; $ovrDst = JPATH_BASE . "/language/overrides/$tag.override.ini";
    if (is_file($ovr) && !is_file($ovrDst)) { copy($ovr, $ovrDst); $log("overrides: language/overrides/$tag.override.ini"); }
    Table::getInstance('Category')->rebuild(); Table::getInstance('Menu')->rebuild();
    foreach (glob(JPATH_BASE . '/media/t4/optimize/*/*') as $f) { @unlink($f); }
    $log('T4 cache cleared');
}

$log(sprintf("%s%s: %d categories, %d tags, %d articles, %d contacts, %d menus / %d items, %d modules — note `%s`. Site serves /%s/ with %s text; translate in place.",
    $dry ? '[dry-run] ' : '', $tag, count($catMap), count($tagMap), count($artMap), count($contactMap), count($menutypeMap), count($menuMap), count($modMap), $note, $sef, $from));
