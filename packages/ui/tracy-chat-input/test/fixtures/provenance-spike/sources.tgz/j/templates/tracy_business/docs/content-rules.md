# Content rules — what the source supplied, where it contradicts itself, what is still undecided

The site was built from the customer's design bundle (17 HTML pages, EN + RU, one image set, one
PDF set). The rule was **no invented facts**: where the source had no data, the site has an empty
valid state; where the source disagreed with itself, each page keeps its own figure. Do not
"fix" any item below by choosing a value — every one is a decision for the content owner.

## Open decisions (owner must choose)

| Where | What the source says | What the site does | Decision needed |
|---|---|---|---|
| Copyright line (EN/RU) | "Template running on **Joomla 5**" | kept verbatim | site is Joomla 6 — change the line? |
| Marketing Kit, Newsletter, Email, Form, Slide, Style guide, Free float | 7 RU labels **left in English** in the RU design — the menu titles / H1s of the marketing-kit pages (`site-map.md` → `tb-kit-ru`, and `tb-main-ru` → Resources) plus the free-float note | kept as the design has them | translate? |
| Elektra project | Home: 24 days early / 14 months; Projects: 19 days / 19 months | each page shows its own figure | which is right |
| News page counter | "48 articles" | shows the real count (9) | — |
| Careers | "19 open roles" but 6 positions listed | shows the real count | — |
| News filter chips | chip "Careers" with no article behind it | chip omitted | add content or drop chip |
| Fire safety standard | EN "to NFPA standards" vs RU «по СП 484 и ГОСТ» | each language keeps its own | real fact — which applies |
| Images | the RU-labelled map and 8 RU slide thumbnails are used for EN too | kept | EN assets? |
| Leadership | no portraits supplied | text rows, no image frame | photos? |
| Client logos (EN) | none supplied | text list | logos? |
| Brand assets ZIP, 4 IR PDFs, 2 Downloads files | files do not exist | names shown as text, **no link** | supply files |
| Social links | no URLs in the source | chips are text; fill the Link field in `tb-sys-social` to make them links | URLs |
| IR share statistics | static numbers in the design | static | live MOEX feed? |
| Newsletter / IR subscribe | design sample | static, disabled inputs | integrate a real mailing extension (e.g. AcyMailing) or keep as sample |
| Terms, Privacy | no text in the source | articles exist, body empty | supply text (paste into the two articles) |
| 404 page nav | design highlights "Resources" | Joomla has no active item on a 404 → "Home" | platform limit; accept |
| Slide page sidebar | beside "Ready-made decks" only | beside the whole component (`sidebar-r`) | accept, or move the three modules into `slide-page-end` |
| Contact form mail | — | `mailonline = 0`, submit shows Joomla's "mail disabled" notice | enable mail on the live server |

## Things that look wrong but are the source

- Newsreader only in content headings, Archivo everywhere in the chrome — measured, intentional.
- The footer logo box is Signal orange while the header's is Forest green — intentional.
- Paper 2 (`#EDEAE2`) never appears in the chrome; the crumb band is its first use.
- Two of the design's four "pages" (Form, Email) show sample UI that submits nothing. They are
  documentation pages and are built as such.

## Where the raw source lives (build machine only)

`spec/source-data.json` (the design's own JS content objects, EN/RU/PJ/AB/SV/CAR/IR/RES),
`spec/content-en-ru.md`, `spec/page-sections.md`, `spec/chrome-measurements.md`, rendered source
pages under `render/`. Not shipped with the site.
