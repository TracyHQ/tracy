<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_news
 *
 * @copyright   (C) 2010 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Layout\LayoutHelper;
?>
<?php if ($params->get('item_title')) : ?>
    <?php $item_heading = $params->get('item_heading', 'h4'); ?>
    <<?php echo $item_heading; ?> class="newsflash-title">
    <?php if ($item->link !== '' && $params->get('link_titles')) : ?>
        <a href="<?php echo $item->link; ?>">
            <?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
        </a>
    <?php else : ?>
        <?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
    <?php endif; ?>
    </<?php echo $item_heading; ?>>
<?php endif; ?>

<?php if ($params->get('img_intro_full') !== 'none' && !empty($item->imageSrc)) : ?>
    <figure class="newsflash-image">
        <?php echo LayoutHelper::render(
            'joomla.html.image',
            [
                'src' => $item->imageSrc,
                'alt' => $item->imageAlt,
            ]
        ); ?>
        <?php if (!empty($item->imageCaption)) : ?>
            <figcaption>
                <?php echo htmlspecialchars($item->imageCaption, ENT_QUOTES, 'UTF-8'); ?>
            </figcaption>
        <?php endif; ?>
    </figure>
<?php endif; ?>

<?php if (!$params->get('intro_only')) : ?>
    <?php echo $item->afterDisplayTitle; ?>
<?php endif; ?>

<?php echo $item->beforeDisplayContent; ?>

<?php if ($params->get('show_introtext', 1)) : ?>
    <?php echo $item->introtext; ?>
<?php endif; ?>

<?php echo $item->afterDisplayContent; ?>

<?php if (isset($item->link) && $item->readmore != 0 && $params->get('readmore')) : ?>
    <?php // Overwrite global article setting if needed ?>
    <?php if ($params->get('readmore_title', '') !== '') : ?>
        <?php $item->params->set('show_readmore_title', $params->get('readmore_title')); ?>
    <?php endif; ?>
    <?php echo LayoutHelper::render('joomla.content.readmore', ['item' => $item, 'params' => $item->params, 'link' => $item->link]); ?>
<?php endif; ?>
